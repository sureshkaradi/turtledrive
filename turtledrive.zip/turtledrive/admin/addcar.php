<html>
<head>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="febe/style.css" type="text/css" media="screen" charset="utf-8">
 <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
<script src="argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>	
<!--sa poip up-->
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
</head>
<body>
<?php include_once("admin_header.php");?>

<div class="container">
  <div class="row">
            <div class="col-lg-8">

    <form class="well form-horizontal" id="form" name="form" action="caradd.php" method="post"  onsubmit="return validateForm()">
      <fieldset>

<!-- Form Name -->
<div class="alert alert-success" role="alert" id="success_message"> <i class="glyphicon glyphicon-info-sign"></i>
 CAR INFORMATION</div>
                <div class="form-group"> 
  
  <label class="col-md-2 control-label">Location</label>
    <div class="col-md-4 selectContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    <select name="location" class="form-control selectpicker" >
      <option value=""></option>
            <?php
include('../storescripts/connect_to_mysql.php');// connection to database 
$q=mysql_query("select * from products ");
while($n=mysql_fetch_array($q)){
echo "<option value=".$n['category'].">".$n['category']."</option>";
}
?>
    </select>
  </div>
</div>
</div>
         <div class="form-group"> 
 
              <label class="col-md-2 control-label">school name</label>
                <div class="col-md-4 selectContainer">
                  <div class="input-group">

                    <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                      <input name="sname" placeholder="enter school name" id="dob" class="form-control"  type="text">
      
   
                    </div>
                 </div>
               </div> 
               <div class="form-group">
                <label class="col-md-2 control-label">Car Name</label>
                  <div class="col-md-4 selectContainer">
                    <div class="input-group">
                      <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                       <select name="cname" class="form-control selectpicker" >
                       <option value="" ></option>
      
                           <?php
                          include('../storescripts/connect_to_mysql.php');// connection to database 
                          $q=mysql_query("select * from car_names ");
                           while($n=mysql_fetch_array($q)){
                           echo "<option value=".$n['car_name'].">".$n['car_name']."</option>";
                             }
                           ?>
       
      
                        </select>
                     </div>
                  </div>
              </div>
               <div class="form-group"> 
 
              <label class="col-md-2 control-label">school address</label>
                <div class="col-md-4 selectContainer">
                  <div class="input-group">

                    <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                      <input name="sadd" placeholder="enter school address" id="dob" class="form-control"  type="text">
      
   
                    </div>
                 </div>
               </div> 
                <div class="form-group"> 
 
              <label class="col-md-2 control-label">No Of Classes</label>
                <div class="col-md-4 selectContainer">
                  <div class="input-group">

                    <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                      <input name="sclass" placeholder="No Of Classes" id="dob" class="form-control"  type="text">
      
   
                    </div>
                 </div>
               </div> 
               <div class="form-group"> 
 
                <label class="col-md-2 control-label">Car Price</label>
                 <div class="col-md-4 selectContainer">
                  <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                    <input name="price" placeholder="enter price" id="dob" class="form-control"  type="text">
      
                  </div>
                </div>
                </div>
                        
                     <div class="form-group">
  
                       <label class="col-md-2 control-label"></label>
                           <div class="col-md-4-selectContainer">
                           <button type="submit" class="btn btn-warning" >ADD CAR<span class="glyphicon glyphicon-credit-card"></span></button></br>
                 
                         </div>
                       </div>

         </fieldset>
      </form>
    </div>
  </div>
 </div>   






  




  

<?php include_once("admin_footer.php");?>
</body>
</html>