

  <?php

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("projectx", $con);


$sql= "INSERT INTO products (id, product_name, price, details, contact_details, category, subcategory, 	adderss, class_trail)
VALUES ('', '$_POST[name]',  '$_POST[price]', '$_POST[details]', '$_POST[c_details]', '$_POST[area]', 
  '$_POST[s_type]', '$_POST[address]', '$_POST[trail]')";

 if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }

 header("location: school.php");
mysql_close($con)
?>