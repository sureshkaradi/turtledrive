
<script type="text/javascript">
function validateForm()
{
var a=document.forms["addroom"]["name"].value;
if (a==null || a=="")
  {
  alert("Pls. Enter the school name");
  return false;
  }
var b=document.forms["addroom"]["price"].value;
if (b==null || b=="")
  {
  alert("Pls. Enter price");
  return false;
  }
 var c=document.forms["addroom"]["details"].value;
if (c==null || c=="")
  {
  alert("Pls. enter the details");
  return false;
  }
var d=document.forms["addroom"]["c_details"].value;
if (d==null || d=="")
  {
  alert("Pls Enter the contact details");
  return false;
  }
}
</script>

<style type="text/css">
<!--
.ed{
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
margin-bottom: 4px;
}
#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
background-color:#00CCFF;
height: 34px;
}
-->
</style>

<form action="addexec.php" method="post">
	school name:<br><input type="text" name="name" class="ed"><br>
	default car price:<br><input type="text" name="price" class="ed"><br>
	details:<br><input type="text" name="details" class="ed"><br>
	contact_details:<br><textarea row="3" name="c_details" class="ed"></textarea><br>
  area:<br><input type="text" name="area" class="ed"><br>
  service Type:<br><input type="text" name="s_type" class="ed"><br>
  address:<br><textarea  row="3" name="address" class="ed"></textarea><br>
  class trail:<br><input type="text" name="trail" class="ed"><br>
	
	<input type="submit" value="Save" id="button1">
</form>
