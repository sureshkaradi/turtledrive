	<div id="footer" class="radius-bottom">
					2011-12 ©
					<a class="afooter-link" href="">skylabs</a>
					by
					<a class="afooter-link" href="">Turtle Drive</a>
				</div>
				<div class="clearfix"></div>
			</div>
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	</div>