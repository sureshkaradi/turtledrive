  <?php

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("projectx", $con);


$sql= "INSERT INTO cars ( product_name, car_name, car_price, category, address, class)
VALUES ('$_POST[sname]',  '$_POST[cname]', '$_POST[price]', '$_POST[location]', '$_POST[sadd]', '$_POST[sclass]')";

 if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }

 header("location: cars.php");
mysql_close($con)
?>