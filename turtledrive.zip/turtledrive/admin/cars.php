<html>
<head>
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="febe/style.css" type="text/css" media="screen" charset="utf-8">
<script src="argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
<script src="js/application.js" type="text/javascript" charset="utf-8"></script>	
<!--sa poip up-->
<link href="src/facebox.css" media="screen" rel="stylesheet" type="text/css" />
</head>
<body>
<?php include_once("admin_header.php");?>
<div class="container">
  <div class="row">
            <div class="col-lg-8">
            	<div id="content" class="clearfix">
					<label for="filter">Filter</label> <input type="text" name="filter" value="" id="filter" />
					<a rel="facebox" href="addcar.php">ADD NEW CARS TO THE SCHOOL</a>
					
					<table cellpadding="1" cellspacing="1" id="resultTable">
						<thead>
							<tr>
								<th  style="border-left: 1px solid #C1DAD7"> school name </th>
								<th> car name</th>
								<th>price </th>
							
							    <th>area  </th>
								<th>review  </th>
								
								<th> Action </th>
							</tr>
						</thead>
						<tbody>
						<?php
							include('../storescripts/connect_to_mysql.php');
							$result = mysql_query("SELECT * FROM cars");
							while($row = mysql_fetch_array($result))
								{
									echo '<tr class="record">';
									echo '<td style="border-left: 1px solid #C1DAD7;">'.$row['product_name'].'</td>';
									echo '<td><div align="left">'.$row['car_name'].'</div></td>';
									echo '<td><div align="left">'.$row['car_price'].'</div></td>';
									echo '<td><div align="left">'.$row['category'].'</div></td>';
									echo '<td><div align="left">'.$row['review'].'</div></td>';
									
									echo '</tr>';
								}
							?> 
						</tbody>
					</table>
				</div>
            </div>

             <div class="col-lg-4">

            </div>
   </div>
 </div>          	

<?php include_once("admin_footer.php");?>
</body>