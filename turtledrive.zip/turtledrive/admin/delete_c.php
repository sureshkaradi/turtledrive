<?php

// This is a sample code in case you wish to check the username from a mysql db table
include('../storescripts/connect_to_mysql.php');
if($_GET['b_id'])
{
$b_id=$_GET['b_id'];
 $sql = "delete from booking_info where ref_no='$b_id'";
 mysql_query("delete from customer where id='$b_id'");
 mysql_query( $sql);
}

?>