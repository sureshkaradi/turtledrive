<table cellpadding="1" cellspacing="1" id="resultTable">
						<thead>
							<tr>
								<th  style="border-left: 1px solid #C1DAD7"> reference no </th>
								<th> Firstname </th>
								<th> Lastname </th>
								<th> phone </th>
								<th> email </th>
								<th> Address </th>
								<th> school name </th>
								<th> car </th>
								<th> P_Time </th>
								<th> p_date </th>
								<th> amount </th>
								<th> Status </th>
								
							</tr>
						</thead>
						<tbody>
						<?php
							include('../storescripts/connect_to_mysql.php');
							$result = mysql_query("SELECT * FROM booking_info  ORDER BY b_id DESC");
							while($row = mysql_fetch_array($result))
								{
									echo '<tr class="record">';
									echo '<td style="border-left: 1px solid #C1DAD7;">'.$row['ref_no'].'</td>';
									echo '<td><div align="right">'.$row['f_name'].'</div></td>';
									echo '<td><div align="right">'.$row['l_name'].'</div></td>';
									echo '<td><div align="right">'.$row['phone'].'</div></td>';
									echo '<td><div align="right">'.$row['email'].'</div></td>';
									echo '<td><div align="right">'.$row['address'].'</div></td>';
									echo '<td><div align="right">'.$row['school_name'].'</div></td>';
									echo '<td><div align="right">'.$row['car'].'</div></td>';
									echo '<td><div align="right">'.$row['p_time'].'</div></td>';
									echo '<td><div align="right">'.$row['p_date'].'</div></td>';
									echo '<td><div align="right">'.$row['price'].'</div></td>';
									echo '<td><div align="right">'.$row['status'].'</div></td>';
									echo '<td><div align="center"><a rel="facebox" href="editstatus.php?b_id='.$row['b_id'].'">edit</a> |
									 <a href="#" b_id="'.$row['ref_no'].'" class="delbutton" title="Click To Delete">
									 delete</a></div></td>';

								}
								

 


                                   header("Content-type: application/vnd-ms-excel");
 
                                   header("Content-Disposition: attachment;  filename=export.xls");
 

                                       


							?> 
						</tbody>
					</table>
				</div>