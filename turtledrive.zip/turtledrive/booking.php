

<?php include_once("login/session.php");?>

<?php 
error_reporting(E_ALL);
ini_set('display_errors', '1');
?>

<?php 
// Check to see the URL variable is set and that it exists in the database
if (isset($_GET['c_id'])) {
  // Connect to the MySQL database  
    include "storescripts/connect_to_mysql.php"; 
  $c_id = preg_replace('#[^0-9]#i', '', $_GET['c_id']); 
  // Use this var to check to see if this ID exists, if yes then get the product 
  // details, if no then exit this script and give message why
  $sql = mysql_query("SELECT * FROM cars WHERE c_id='$c_id' LIMIT 1");
  $productCount = mysql_num_rows($sql); // count the output amount
    if ($productCount > 0) {
    // get all the product details
    while($row = mysql_fetch_array($sql)){ 
       $c_id=$row["c_id"];
       $product_name = $row["product_name"];
       $car_price = $row["car_price"];
       $car_name = $row["car_name"];
       $address = $row["address"];
       $tr = $row["training"];
     
     
         }
     
  } else {
    echo "That item does not exist.";
      exit();
  }
    
} else {
  echo "Data to render this page is missing.";
  exit();
}

mysql_close();
?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Turtledrive | Driving school Booking</title>
   

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link type="text/css" href="css/bootstrap.min.css" />
    <link type="text/css" href="css/bootstrap-timepicker.min.css" />
     <script type="text/javascript" src="js/jquery.min.js"></script>
     <script type="text/javascript" src="js/bootstrap.min.js"></script>
     <script type="text/javascript" src="js/bootstrap-timepicker.min.js"></script>

    <!-- Custom CSS -->
    <link href="css/1-col-portfolio.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

    <![endif]-->
<?php include_once("modules/form_valid.php");?> 

</head>

<body>
  <?php include_once("template1.php");?>  
  <hr>
<div class="container">
  <?php include_once("login/logout.php");?>
  <div class="row">
            <div class="col-lg-8">

    <form class="well form-horizontal" id="form" name="form" action="save.php" method="post"  onsubmit="return validateForm()">
<fieldset align="center">
  <input type="hidden" value="<?php echo $product_name ?>" name="s_name" />
  <input type="hidden" value="<?php echo $car_name ?>" name="car" />
  <input type="hidden" value="<?php echo $address ?>" name="s_address" />
  <input type="hidden" value="<?php echo $car_price ?>" name="price" />
  <input type="hidden" value="<?php echo $tr ?>" name="ser" />

<!-- Form Name -->
<div class="alert alert-success" role="alert" id="success_message"> <i class="glyphicon glyphicon-info-sign"></i>
 BOOKING INFORMATION</div>

<!-- Text input-->
<div class="form-group">
  <div row>
  <div class="col-md-5 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
  
  <input  name="date" placeholder="Preffered Date" id="date" class="form-control"  type="text">
    </div>
  </div>
</div>
<div class="form-group">
  
    <div class="col-md-5 inputGroupContainer">
    <div class="input-group">
     <span class="input-group-addon"><i class="glyphicon glyphicon-time"></i></span>
         <select name="time" class="form-control selectpicker" >
         <option value="Morning-regular" >Morning-regular</option>
      
        <option value="evening-regular">evening-regular</option>
        <option value="Morning-weekend">Morning-weekend</option>
        <option value="evening-weekend">evening-weekend</option>
    </select>
    </div>
  </div>
</div>
</div>
<div class="form-group">
  <div row>
   
  <div class="col-md-5 inputGroupContainer">
  <div class="input-group">
  <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
  <input  name="f_name" placeholder="Name" class="form-control"  type="text">
    </div>
  </div>
</div>

<div class="form-group"> 
  <div row>
 
    <div class="col-md-5 selectContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    <select name="gender" class="form-control selectpicker" >
      <option value="male" >male</option>
      
      <option value="female">Female</option>
       <option value="other">Other</option>
      
    </select>
  </div>
</div>
</div>
</div>
<!-- Text input-->
       <div class="form-group">
        <div row>
   
        <div class="col-md-5 inputGroupContainer">
        <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
        <input name="email" placeholder="E-Mail Address" class="form-control"  type="text">
    </div>
  </div>
</div>


<!-- Text input-->
       
<div class="form-group">
   
    <div class="col-md-5 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
  <input name="phone" placeholder="+91 9620182858" class="form-control" type="text">
    </div>
  </div>
</div>
</div>
<!-- Text input-->
      
<div class="form-group">
  <div row>
    
    <div class="col-md-5 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
  <textarea class="form-control" name="address" rows="5" placeholder="Address"></textarea>
    </div>
  </div>
</div>

<!-- Text input-->
 
<div class="form-group">
    
    <div class="col-md-5 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-home"></i></span>
  <input name="city" placeholder="city" class="form-control"  type="text">
    </div>
  </div>
</div>
</div>
<!-- Select Basic -->
<div class="form-group">
   
    
    <div class="col-md-5 inputGroupContainer">
    <div class="input-group">
        <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"></i></span>
  <input name="land" placeholder="Landmark" class="form-control"  type="text">
    </div>
</div>
</div>
                         <?php
include('storescripts/connect_to_mysql.php');// connection to database 
$q=mysql_query("select * from products WHERE school_no = '1' ");
while($n=mysql_fetch_array($q)){
   $pd = $n['p_d_service'];
echo '<h5>note: '.$pd.'</h5>';
}

?>
 <div class="form-group">
      <div class="col-md-7 selectContainer">
    <div class="input-group">
      <h4>PICK UP AND DROP SERVICES</h4>
        <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
    <select name="pd" class="form-control selectpicker" >
      <option value="no" >NO</option>
      
      <option value="yes">YES</option>

      
    </select>
  </div>
</div>    
               </div>
<!-- Text area -->
  

<!-- Success message -->


<!-- Button -->

<div class="form-group">
  <div row>
  <label class="col-md-8 control-label"></label>
  <div class="col-md-4">
      <button type="submit" class="btn btn-warning" >PAY BY CASH <span class="glyphicon glyphicon-credit-card"></span></button></br>
                 
  </div>
</div>
  
</div>
</fieldset>
</form>

             </div> 

             <div class="col-lg-4">

                             <form class="well form-horizontal" action=" " method="post"  id="contact_form">
               <fieldset>

<!-- Form Name -->
<div class="alert alert-success" role="alert" id="success_message"> <i class="glyphicon glyphicon-home"></i>
 SCHOOL DETAILS</div>
<div class="form-group">
  <table width="100%">
    <tr>

    <td width="20%" align="center"><i class="fa fa-home"></i></td>
    <td width="30%" align="left"><h5>School Name:</h5></td>
    <td width="50" align="left"><h5><?php echo $product_name; ?></h5></td>
    </tr>
     <tr>
    <td width="20%" align="center"><h5><i class="fa fa-check"></h5></i></td>
    <td width="30%" align="left"><h5>Selected Car:</h5></td>
    <td width="50" align="left"> <h5> <?php echo $car_name; ?> </h5></td>
    </tr>
     <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-map-marker"></h5></i></td>
    <td width="30%" align="left"> <h5> Address: </h5></td>
    <td width="50" align="left"> <h5>   <?php echo $address; ?> </h5> </td>
    </tr>
     <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-cog"></h5></i></td>
    <td width="30%" align="left"> <h5> service: </h5></td>
    <td width="50" align="left"> <h5>   <?php echo $tr; ?> </h5> </td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-inr"></h5></i></td>
    <td width="30%" align="left"> <h5> Price: </h5></td>
    <td width="50" align="left"> <h5>   <?php echo $car_price; ?> </h5> </td>
    </tr>

  </table>
  
   
        
</div>


</fieldset>
</form>

             </div> 
    </div>
 </div> 
 
<?php include_once("template_footer.php");?>
        <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
     <script src="js/bootstrap.min.js"></script>
      <script src="js/form.js"></script>

    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js"></script>
    `<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>

  <script>
  $(function() {
    var dates = $( "#date" ).datepicker({
      defaultDate: "+1w",
      changeMonth: true,
      numberOfMonths: 1,
      dateFormat: 'dd-mm-yy',
      onSelect: function( selectedDate ) {
        var option = this.id == "date" ? "minDate" : "maxDate",
          instance = $( this ).data( "datepicker" ),
          date = $.datepicker.parseDate(
            instance.settings.dateFormat ||
            $.datepicker._defaults.dateFormat,
            selectedDate, instance.settings );
        dates.not( this ).datepicker( "option", option, date );
      }
    });
  });
  </script>

 <script type="text/javascript">
            $('#timepicker1').timepicker();
        </script>
  

    </body>
    </html>

    