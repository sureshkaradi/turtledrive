
<?php 
// Check to see the URL variable is set and that it exists in the database
if (isset($_GET['car_name'])) {
  // Connect to the MySQL database 
    $cars = ""; 
    include "storescripts/connect_to_mysql.php";

  $c_name = $_GET['car_name'];

  $sql = mysql_query("SELECT * FROM cars WHERE car_name='$c_name' LIMIT 20");
  $productCount = mysql_num_rows($sql); // count the output amount
    if ($productCount > 0) {
    // get all the product details
    while($row = mysql_fetch_array($sql)){ 
    $car_price = $row["car_price"];
    $car_name = $row["car_name"];
    $address = $row["address"];
    $product_name = $row["product_name"];
    $category = $row["category"];
    $class = $row["class"];
    $c_id = $row["c_id"];
    $per = $row["per"];
    $review = $row["review"];
       $cars .= '<div class="team">
                  <div class="row clearfix">
                    <div class="col-md-12 col-sm-4"> 
                       <div class="single-profile-top wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
                          <div class="media">
                            <div class="pull-left">
                               <a href="#"><img class="media-object" src="inventory_images/cars/' . $car_name . '.jpg" alt=" .$car_name. "></a>
                               <h4>' . $car_name . '</h4> 
                            </div>
                        <table width="50%">
                          <tr>
                           <td width="95%">    
                             <div class="media-body">
                               <a href="schools.php?product_name=' . $product_name . '"><h4>' . $product_name . '</h4></a> 
                              
                             <ul class="social_icons">

                              <li> <div class="connect">
                                <img src="images/p.png" title="petrol">
                                </div></li> 

                               <li> <div class="connect">
                                <img src="images/m.png" title="male Instructor">
                                </div></li> 

                               <li> <div class="connect">
                                <img src="images/s.png" title="power stearing">
                                </div></li>

                                <li> <div class="connect">
                                <img src="images/d2.png" title="Pick & Drop Service Availaible">
                                </div></li>
                             </ul>
                              <p><img src="images/map.png" width="20px" height="20px">' . $address . '</p>
                             <h5>' . $class . ' days of training (1hr/day) </h5>
                            </div>
                          </td>
                          <td width="5%" align="pull-right" >
                           <div class="media-body">
                             
                             <h2><i class="fa fa-inr"></i>   ' . $car_price . '</h2>
                             <br>
                             <div class="progress">
                               <div class="progress-bar  color2" role="progressbar" aria-valuenow="40"
                               aria-valuemin="0" aria-valuemax="100" style="width: ' . $per . '%">
                                <span class="bar-width">' . $review . '</span>
                              </div>
                             </div> 
                            <h2><li class="btn"><a href="booking.php?c_id=' . $c_id . '">SELECT</a></li></h2>
                         </div>
                         </td>
                        </tr>
                       </table>
                      
                      </div><!--/.media -->
                  </div>
             </div><!--/.col-lg-4 -->
          </div> </br>';
         }
     
  } else {
    echo "That item does not exist.";
      exit();
  }
    
}
     
else {
    echo "That item does not exist.";
      exit();
   }  
?>

<style type="text/css">
.connect {
  font-size: 50px;
  height: 32px;
  width: 32px;
  margin: 5px;
  border-radius: 50%;
  line-height: 32px;
  text-align:center;
  background: orange;
  color: #c52d2f;
  border: 1px solid red;
  box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-transition: 500ms;
  -moz-transition: 500ms;
  -o-transition: 500ms;
  transition: 500ms;
  float: left;
  margin-right: 25px;
}
.connect img{
  height: 30px;
  width: 30px;
  margin: 0px;
  border-radius: 50%;
  line-height: 30px;
  text-align:center;
  background: #eee;
  color: #c52d2f;
  border: 3px solid #ffffff;
  box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-transition: 500ms;
  -moz-transition: 500ms;
  -o-transition: 500ms;
  transition: 500ms;
  float: left;
  margin-right: 25px;
}
.connect img:hover {
  background:orange;
  color: blue;
  box-shadow: inset 0 0 0 5px red;
  -webkit-box-shadow: inset 0 0 0 1px orange;
  border: 1px solid orange;
}
</style>

<?php include_once("template1.php");?>
<hr>
 <div class="container">  
        <div class="row">
           <div class="col-lg-3">
              <form class="well form-horizontal" action="car.php" method="post"  id="contact_form">
              <fieldset>
          <div class="form-group"> 
 
            
          <div class="col-md-12 selectContainer">
           <h5> LOCATION</h5>
          <div class="input-group">

          <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"></i></span>
          <select name="name" class="form-control selectpicker" >
             <?php
include('storescripts/connect_to_mysql.php');// connection to database 
$q=mysql_query("select * from products ");
while($n=mysql_fetch_array($q)){
echo "<option value=".$n['category'].">".$n['category']."</option>";
}
?>
      
           </select>
           </div>
           </div>
           </div>
           <div class="form-group"> 
 
 
          <div class="col-md-12 selectContainer">
           <h5> VEHICLE GROUP</h5> 
          <div class="input-group">
          <span class="input-group-addon"><i class="fa fa-cog"></i></span>
          <select name="car" id="filter" class="form-control selectpicker" >
           <option><?php echo  $c_name;  ?></option> 
           <?php
                          include('storescripts/connect_to_mysql.php');// connection to database 
                          $q=mysql_query("select * from car_names ");
                           while($n=mysql_fetch_array($q)){
                           echo "<option value=".$n['car_name'].">".$n['car_name']."</option>";
                             }
                           ?>
      
           </select>
           </div>
           </div>
           </div>
           <div class="form-group"> 
 
 
          <div class="col-md-12 selectContainer">
           <h5> PRICE</h5> 
          <div class="input-group">
          <span class="input-group-addon"><i class="fa fa-inr"></i></span>
          <select name="" id="filter" class="form-control selectpicker" >
            <option>2500</option>
            <option>2500-3000</option>
            <option>3000-4000</option>
            <option>4000-5000</option>
            <option>5000 Above </option>
           </select>
           </div>
           </div>
           </div>

        <div class="form-group">
         <div class="col-md-12 selectContainer">
          <div class="input-group">
           <br>
           <h5>VEHICLE TYPE </h5>

               <div>
                <input type="radio" name="filter" value="" id="filter" value="Santro">&nbsp &nbsp Power Stearing<br/>
                <input type="radio" name="filter" value="" id="filter" value="Alto">&nbsp &nbsp Manuval Stearing
                
               </div>

           </div>
           <br>
           </div>

             <div class="form-group">
                 <label class="col-md-4 control-label"></label>
                  <div class="col-md-4">
                 <button type="submit"  name="submit" class="btn btn-warning" >SEARCH <span class="glyphicon glyphicon-send"></span></button>
                 </div>
            </div>
        </fieldset>
       </form>
      
       
   </div> 
   <!-- car search-->
            <div class="col-md-8"> 
              <?php echo $cars; ?>
            </div>
        </div>
    </div>
