<?php include_once("login/session.php");?>

<?php 
// This file is www.developphp.com curriculum material
// Written by Adam Khoury January 01, 2011
// http://www.youtube.com/view_play_list?p=442E340A42191003
// Script Error Reporting
error_reporting(E_ALL);
ini_set('display_errors', '1');
?>
<?php 
// Check to see the URL variable is set and that it exists in the database
if (isset($_GET['b_id'])) {
	// Connect to the MySQL database  
    include "storescripts/connect_to_mysql.php"; 
	$b_id = preg_replace('#[^0-9]#i', '', $_GET['b_id']); 
	// Use this var to check to see if this ID exists, if yes then get the product 
	// details, if no then exit this script and give message why
	$sql = mysql_query("SELECT * FROM booking_info WHERE b_id='$b_id' LIMIT 1");
	$productCount = mysql_num_rows($sql); // count the output amount
    if ($productCount > 0) {
		// get all the product details
		while($row = mysql_fetch_array($sql)){ 
			 $ref_no = $row["ref_no"];
			 $school_name = $row["school_name"];
			$car=$row["car"];
			$s_address=$row["s_address"];
			$price=$row["price"];
			$p_date=$row["p_date"];
			$p_time=$row["p_time"];
      $ser=$row["service"];
      $pd=$row["pd"];

         }

        
		 
	} else {
		echo "That item does not exist.";
	    exit();
	}
		
} else {
	echo "Data to render this page is missing.";
	exit();
}
?>


<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Turtledrive | Driving Booking Confirm</title>
   

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/1-col-portfolio.css" rel="stylesheet">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
   <?php include_once("template1.php");?>
   <hr>
  
 <div class="container">
   <?php include_once("login/logout.php");?>
   <div class="row">

    
   	  <div class="col-lg-6">
   	  	 <form class="well form-horizontal">
   	  	 	<fieldset>
   	  	 		<div class="alert alert-success" role="alert" > <i class="glyphicon glyphicon-thumbs-up"></i>
                your Booking sucessfully compleated</div>
                <table width="100%">
    <tr>

    <td width="20%" align="center"><h3><i class="fa fa-leaf"></i></h3></td>
    <td width="50%" align="left"><h4>Booking reference no:</h4></td>
    <td width="50" align="left"><h4><?php echo $ref_no; ?></h4></td>
    </tr>
     <tr>
    <td width="20%" align="center"><h3><i class="fa fa-home"></h3></i></td>
    <td width="50%" align="left"><h4>School name:</h4></td>
    <td width="50" align="left"> <h4> <?php echo $school_name; ?> </h4></td>
    </tr>
     <tr>
    <td width="20%" align="center"><h3><i class="fa fa-map-marker"></h3></i></td>
    <td width="50%" align="left"><h4>School address:</h4></td>
    <td width="50" align="left"> <h4> <?php echo $s_address; ?> </h4></td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h3> <i class="fa fa-calendar"></h3></i></td>
    <td width="50%" align="left"> <h4>prefered date:</h4></td>
    <td width="50" align="left"> <h4> <?php echo $p_date; ?></h4> </td>
    </tr>
     <tr>
    <td width="20%" align="center"> <h3> <i class="glyphicon glyphicon-time"></h3></i></td>
    <td width="50%" align="left"> <h4>prefered time:</h4></td>
    <td width="50" align="left"> <h4><?php echo $p_time; ?></h4> </td>
    </tr>
     <tr>
    <td width="20%" align="center"> <h3> <i class="fa fa-check"></h3></i></td>
    <td width="50%" align="left"> <h4>Selected car:  </h4></td>
    <td width="50" align="left"> <h4><?php echo $car; ?></h4> </td>
    </tr>
     <tr>
    <td width="20%" align="center"> <h3> <i class="fa fa-cog"></h3></i></td>
    <td width="50%" align="left"><h4> Service Type: </h4></td>
    <td width="50" align="left"> <h4> <?php echo $ser; ?></h4> </td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h3> <i class="fa fa-home"></h3></i></td>
    <td width="50%" align="left"><h4> pick Up And Drop: </h4></td>
    <td width="50" align="left"> <h4> <?php echo $pd; ?></h4> </td>
    </tr>
      <tr>
    <td width="20%" align="center"> <h3> <i class="fa fa-inr"></h3></i></td>
    <td width="50%" align="left"><h4> Amount: </h4></td>
    <td width="50" align="left"> <h4> <?php echo $price; ?></h4> </td>
    </tr>
  </table>

            

   	  	 	</fieldset>
   	  		</form>
   	  </div>

   	   <div class="col-lg-4">
   	  	 <form class="well form-horizontal" metho="post" action="pcash.php">
   	  	 	<fieldset>
   	  	 		<div class="alert alert-success" role="alert" id="success_message"> <i class="fa fa-check"></i>
                REQUIRED DOCUMENTS</div>
                  <input type="hidden" value="<?php echo $ref_no ?>" name="rname" />
                  <h5>Proof of Age (any one) </h5>
                   <ol>
                    <li>Birth certificate </li>
                    <li>PAN Card</li>
                    <li>School leaving certificate</li>
                    <li>College certificate</li>
                   </ol>
                    <h5>Proof of Identity (any one)</h5>
                   <ol>
                    <li> Photo PAN card </li>
                    <li>Voters Identity card </li>
                    <li>Bank pass book with attested customer
photograph and signature (only from
scheduled commercial Banks)</li>
                    <li>Aadhar Card</li>
                   </ol>
                    <h5>Residential Proof (any one)</h5>
                   <ol>
                    <li>Voters Identity card </li>
                    <li>Valid Indian Passport</li>
                    <li>BPL/APL Card</li>
                    <li>Bank passbook </li>
                    <li>gas connection bill </li>
                   </ol>

                   <a href="training.php">YES I HAVE </a>
                
   	  	 	</fieldset>
   	  	 </form>	
       
   	  	  
   	  </div>

   	   <div class="col-lg-2">
        
   	  	          <form accept-charset="UTF-8" action="" method="post">
                        <input id="ratings-hidden" name="rating" type="hidden"> 
                        <textarea class="form-control animated" cols="50" id="new-review" name="comment" placeholder="Enter your review here..." rows="5"></textarea>
        
                        <div class="text-right">
                            <div class="stars starrr" data-rating="0"></div>
                            <a class="btn btn-danger btn-sm" href="#" id="close-review-box" style="display:none; margin-right: 10px;">
                            <span class="glyphicon glyphicon-remove"></span>Cancel</a>
                            <button class="btn btn-success btn-lg" type="submit">Save</button>
                        </div>
                    </form>	
   	  </div>

    </div>
  </div>    
<!-- Text i

        <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
     <script src="js/bootstrap.min.js"></script>
      <script src="js/form.js"></script>
      <script src="js/review.js"></script>

    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js"></script>
    `<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>



    </body>
    </html>
     <?php include_once("template_footer.php");?>