<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8" />
        <title>WebCodo :: Switch Products View Grid/List jQuery + Filter + Cookies</title>

        <link type="text/css" rel="stylesheet" href="css/style.css">
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script type="text/javascript" src="js/jquery.cookie.js"></script>

<script>
$(function(){
    var default_view = 'list'; // choose the view to show by default (grid/list)
    
    // check the presence of the cookie, if not create "view" cookie with the default view value
    if($.cookie('view') !== 'undefined'){
        $.cookie('view', default_view, { expires: 7, path: '/' });
    } 
    function get_grid(){
        $('.list').removeClass('list-active');
        $('.grid').addClass('grid-active');
        $('.prod-cnt').animate({opacity:0},function(){
            $('.prod-cnt').removeClass('prod-box-list');
            $('.prod-cnt').addClass('prod-box');
            $('.prod-cnt').stop().animate({opacity:1});
        });
    } // end "get_grid" function
    function get_list(){
        $('.grid').removeClass('grid-active');
        $('.list').addClass('list-active');
        $('.prod-cnt').animate({opacity:0},function(){
            $('.prod-cnt').removeClass('prod-box');
            $('.prod-cnt').addClass('prod-box-list');
            $('.prod-cnt').stop().animate({opacity:1});
        });
    } // end "get_list" function

    if($.cookie('view') == 'list'){ 
        // we dont use the "get_list" function here to avoid the animation
        $('.grid').removeClass('grid-active');
        $('.list').addClass('list-active');
        $('.prod-cnt').animate({opacity:0});
        $('.prod-cnt').removeClass('prod-box');
        $('.prod-cnt').addClass('prod-box-list');
        $('.prod-cnt').stop().animate({opacity:1}); 
    } 

    if($.cookie('view') == 'grid'){ 
        $('.list').removeClass('list-active');
        $('.grid').addClass('grid-active');
        $('.prod-cnt').animate({opacity:0});
            $('.prod-cnt').removeClass('prod-box-list');
            $('.prod-cnt').addClass('prod-box');
            $('.prod-cnt').stop().animate({opacity:1});
    }

    $('#list').click(function(){   
        $.cookie('view', 'list'); 
        get_list()
    });

    $('#grid').click(function(){ 
        $.cookie('view', 'grid'); 
        get_grid();
    });

    /* filter */
    $('.category-menu ul li').click(function(){
        var CategoryID = $(this).attr('category');
        $('.category-menu ul li').removeClass('cat-active');
        $(this).addClass('cat-active');
        
        $('.prod-cnt').each(function(){
            if(($(this).hasClass(CategoryID)) == false){
               $(this).css({'display':'none'});
            };
        });
        $('.'+CategoryID).fadeIn(); 
        
    });
});
</script>

    </head>
 
 

     


</body>
</html>