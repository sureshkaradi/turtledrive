<?php
if (session_id() == "")
{
   session_start();
}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form_name'] == 'logoutform')
{
   if (session_id() == "")
   {
      session_start();
   }
   unset($_SESSION['username']);
   unset($_SESSION['fullname']);
}
?>

<?php
if (isset($_SESSION['fullname']))
{
  $name=$_SESSION['fullname'];

}
else
{
  
}
?>

<style type="text/css">
   .row h4{
    text-transform: uppercase;
    font-size: 15px;
    text-align: left;
    font-family: bold;
   }
</style>


