<?php
if (($_SERVER['REQUEST_METHOD'] == 'POST') && isset($_POST['form_name']) && ($_POST['form_name'] == 'loginform')) 
{
   if (session_id() == "")
   {
      session_start();
   }
   unset($_SESSION['username']);
   unset($_SESSION['fullname']);
   header('Location: ./index.php');
   exit;
}
if (session_id() == "")
{
   session_start();
}
?>