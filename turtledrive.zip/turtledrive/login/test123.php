<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form_name'] == 'loginform')
{
   $success_page = '../training.php';
   $error_page = basename(__FILE__);
   $mysql_server = 'localhost';
   $mysql_username = 'turtllum_root';
   $mysql_password = 'turtledrive123';
   $mysql_database = 'turtllum_turtledrive';
   $mysql_table = 'users';
   $crypt_pass = md5($_POST['password']);
   $found = false;
   $fullname = '';
   $session_timeout = 600;
   $db = mysqli_connect($mysql_server, $mysql_username, $mysql_password);
   if (!$db)
   {
      die('Failed to connect to database server!<br>'.mysqli_error($db));
   }
   mysqli_select_db($db, $mysql_database) or die('Failed to select database<br>'.mysqli_error($db));
   $sql = "SELECT password, fullname, active FROM ".$mysql_table." WHERE username = '".mysqli_real_escape_string($db, $_POST['username'])."'";
   $result = mysqli_query($db, $sql);
   if ($data = mysqli_fetch_array($result))
   {
      if ($crypt_pass == $data['password'] && $data['active'] != 0)
      {
         $found = true;
         $fullname = $data['fullname'];
      }
   }
   mysqli_close($db);
   if($found == false)
   {
      header('Location: '.$error_page);
      exit;
   }
   else
   {
      if (session_id() == "")
      {
         session_start();
      }
      $_SESSION['username'] = $_POST['username'];
      $_SESSION['fullname'] = $fullname;
      $_SESSION['expires_by'] = time() + $session_timeout;
      $_SESSION['expires_timeout'] = $session_timeout;
      $rememberme = isset($_POST['rememberme']) ? true : false;
      if ($rememberme)
      {
         setcookie('username', $_POST['username'], time() + 3600*24*30);
         setcookie('password', $_POST['password'], time() + 3600*24*30);
      }
      header('Location: '.$success_page);
      exit;
   }
}
$username = isset($_COOKIE['username']) ? $_COOKIE['username'] : '';
$password = isset($_COOKIE['password']) ? $_COOKIE['password'] : '';
?>

<style type="text/css">
 .media .form-group .form-control {
    padding: 5px 12px;
    border-color: orange;
    box-shadow: none;
    width:100%;
    height: 50px;
    font-size: 20px;
    background-color: #F1F3F5;

}
.connect {
  margin-bottom: 25px;
  overflow: hidden;
}

.connect h3{
  margin-top: 0px;
  text-align:left;
} 
.connect p{
  margin-top: 5px;
  text-align:left;
} 

.connect i{
  font-size: 50px;
  height: 100px;
  width: 100px;
  margin: 5px;
  border-radius: 100%;
  line-height: 100px;
  text-align:center;
  background: #eee;
  color: #c52d2f;
  border: 3px solid #ffffff;
  box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-transition: 500ms;
  -moz-transition: 500ms;
  -o-transition: 500ms;
  transition: 500ms;
  float: left;
  margin-right: 25px;
}
.connect i:hover {
  background:#eee;
  color: blue;
  box-shadow: inset 0 0 0 5px #eee;
  -webkit-box-shadow: inset 0 0 0 1px orange;
  border: 1px solid orange;
}

  
   
</style>





 <?php include_once("template.php");?>
 <hr>
 <section id="services" class="service-item">
     <div class="container">
            

            <div class="row">

                <div class="col-sm-6 col-md-6">
                    <div class="media services-wrap wow fadeInDown">
                      <h4 class="media-heading">LOGIN</h4>
                        <form name="loginform" method="post" action="<?php echo basename(__FILE__); ?>" id="loginform">
                          <input type="hidden" name="form_name" value="loginform">
                          <div class="form-group">
                           <td class="label"><label for="username">User Name</label>
                          <input class="form-control" name="username" type="text" id="username" value="<?php echo $username; ?>">
                          </div>
                          <div class="form-group">
                          <label for="password">Password</label>
                          <input class="form-control" name="password" type="password" id="password" value="<?php echo $password; ?>">
                         </div>
                          <div class="checkbox">
                            <label><input id="rememberme" type="checkbox" name="rememberme"> Remember me</label>
                          </div>
                            <button type="submit" name="login" value="Log In" id="login" class="btn btn-warning" >LOG IN</button>
                        </form>
                         <h3 class="media-heading">Dont Have Account?<a href="register.php">Register</a> </h3><br>
                         <h3 class="media-heading">Forget Password?<a href="register.php">Cick here</a> </h3>

                          
                               <h3>OR CONNECT WITH  </h3>
                                <div class="connect">
                                <i class="fa fa-facebook"></i>
                                </div><!--/.col-md-4-->
                               </div>


                        </div>

            </div><!--/.row 4-->
        </div><!--/.container-->
    </section><!--/#services-->