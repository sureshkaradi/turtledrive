<?php 
// Check to see the URL variable is set and that it exists in the database
if (isset($_GET['c_id'])) {
  // Connect to the MySQL database  
    include "../storescripts/connect_to_mysql.php"; 
  $c_id = preg_replace('#[^0-9]#i', '', $_GET['c_id']); 
  // Use this var to check to see if this ID exists, if yes then get the product 
  // details, if no then exit this script and give message why
  $sql = mysql_query("SELECT * FROM cars WHERE c_id='$c_id' LIMIT 1");
  $productCount = mysql_num_rows($sql); // count the output amount
    if ($productCount > 0) {
    // get all the product details
    while($row = mysql_fetch_array($sql)){ 
       $c_id=$row["c_id"];
       $product_name = $row["product_name"];
       $car_price = $row["car_price"];
       $car_name = $row["car_name"];
       $address = $row["address"];
     
     
         }
     
  } else {
    echo "That item does not exist.";
      exit();
  }
    
} else {
  echo "Data to render this page is missing.";
  exit();
}

mysql_close();
?>