<?php
if(isset($_POST['submit'])){
if(preg_match("/[A-Z | a-z]+/", $_POST['name'])){
$car=$_POST['car'];
$name=$_POST['name'];
 $cars = "";
 
 include "connect.php"; 
 $sql = mysql_query("SELECT * FROM cars WHERE car_name='$car' AND category='$name' ");
  
 
  while($row = mysql_fetch_array($sql)){
    $car_price = $row["car_price"];
    $car_name = $row["car_name"];
    $address = $row["address"];
    $product_name = $row["product_name"];
    $category = $row["category"];
    $class = $row["class"];
    $c_id = $row["c_id"];
    $per = $row["per"];
    $review = $row["review"];
      $cars .= '<div class="team">
                  <div class="row clearfix">
                    <div class="col-md-12 col-sm-4"> 
                       <div class="single-profile-top wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
                          <div class="media">
                            <div class="pull-left">
                               <a href="#"><img class="media-object" src="inventory_images/cars/' . $car_name . '.jpg" alt=""></a>
                               <h4>' . $car_name . '</h4> 
                            </div>
                        <table width="50%">
                          <tr>
                           <td width="95%">    
                             <div class="media-body">
                               <a href="test.php?product_name=' . $product_name . '"><h4>' . $product_name . '</h4></a> 
                              
                             <ul class="social_icons">

                              <li> <div class="connect">
                                <img src="images/p.png" title="petrol">
                                </div></li> 

                               <li> <div class="connect">
                                <img src="images/m.png" title="male Instructor">
                                </div></li> 

                               <li> <div class="connect">
                                <img src="images/s.png" title="power stearing">
                                </div></li>

                                <li> <div class="connect">
                                <img src="images/d2.png" title="Pick & Drop Service Availaible">
                                </div></li>
                             </ul>
                              <p><img src="images/map.png" width="20px" height="20px">' . $address . '</p>
                             <h5>' . $class . ' days of training (1hr/day) </h5>
                            </div>
                          </td>
                          <td width="5%" align="pull-right" >
                           <div class="media-body">
                             
                             <h2><i class="fa fa-inr"></i>   ' . $car_price . '</h2>
                             <br>
                             <div class="progress">
                               <div class="progress-bar  color2" role="progressbar" aria-valuenow="40"
                               aria-valuemin="0" aria-valuemax="100" style="width: ' . $per . '%">
                                <span class="bar-width">' . $review . '</span>
                              </div>
                             </div> 
                            <h2><li class="btn"><a href="booking.php?c_id=' . $c_id . '">SELECT</a></li></h2>
                         </div>
                         </td>
                        </tr>
                       </table>
                      
                      </div><!--/.media -->
                  </div>
             </div><!--/.col-lg-4 -->
          </div> </br>';
       
     
   
  }
    
}
}
mysql_close();
  
  ?>