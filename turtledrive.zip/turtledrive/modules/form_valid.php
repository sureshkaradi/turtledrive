<script type="text/javascript">
function validateForm()
{
var x=document.forms["form"]["f_name"].value;
if (x==null || x=="")
  {
  alert("First Name must be filled out");
  return false;
  }
var y=document.forms["form"]["l_name"].value;
if (y==null || y=="")
  {
  alert("Last Name must be filled out");
  return false;
  }
var a=document.forms["form"]["address"].value;
if (a==null || a=="")
  {
  alert("Address must be filled out");
  return false;
  }
var a=document.forms["form"]["date"].value;
if (a==null || a=="")
  {
  alert("Preferred date must be filled out");
  return false;
  }
var a=document.forms["form"]["time"].value;
if (a==null || a=="")
  {
  alert("Preferred time must be filled out");
  return false;
  }
var a=document.forms["form"]["gender"].value;
if (a==null || a=="")
  {
  alert("please specify your gender");
  return false;
  }
  var a=document.forms["form"]["email"].value;
if (a==null || a=="")
  {
  alert("please enter your email address");
  return false;
  }
    var a=document.forms["form"]["phone"].value;
if (a==null || a=="")
  {
  alert("please enter your phone number");
  return false;
  }
    var a=document.forms["form"]["land"].value;
if (a==null || a=="")
  {
  alert("please enter your Landmark");
  return false;
  }
     var a=document.forms["form"]["city"].value;
if (a==null || a=="")
  {
  alert("please enter your city");
  return false;
  }
     var a=document.forms["form"]["state"].value;
if (a==null || a=="")
  {
  alert("please enter your state");
  return false;
  }
     var a=document.forms["form"]["zip"].value;
if (a==null || a=="")
  {
  alert("please enter your area zipcode");
  return false;
  }
}
</script>