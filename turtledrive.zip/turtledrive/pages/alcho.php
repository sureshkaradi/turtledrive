 <?php include_once("template.php");?>
 <style type="text/css">
.well a{
  color:#fff;
}
.well a:hover, a:focus {
  color: #d43133;
}
.active a {
  color: red;
}

</style>
  <hr>
    <div class="container">
    	<div class="row">
    		 <div class="col-lg-3">
             <form class="well form-horizontal" action=" " method="post"  id="contact_form">
               <fieldset>
                <ul>
                  <li ><h5><a href="mandatory.php">road signs</a></h5></li>
                  <li color="#fff"><h5><a href="ror.php">rules of the road</a></h5></li>
                  <li color="#fff"><h5><a href="agelimit.php">Age limit</a></h5></li>
                  <li class="active"><h5><a href="alcho.php">alchol limit</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">Tips For Driving Licence</a></h5></li>
                  <li color="#fff"><h5><a href="llr.php">how to get llr</a></h5></li>
                  <li color="#fff"><h5><a href="pdl.php">how to get permnent dl</a></h5></li>
                  <li color="#fff"><h5><a href="idl.php">how to get international dl</a></h5></li>
                  <li color="#fff"><h5><a href="tint.php">tinted glass</a></h5></li>
                  <li color="#fff"><h5><a href="noc.php">noc</a></h5></li>
                  <li color="#fff"><h5><a href="oop.php">offence of penalties</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">driving tips</a></h5></li>
                </ul>
               </fieldet>
              </form> 
            </div> 
             <div class="col-lg-9">
              <form class="well form-horizontal">
                <fieldset>
             	 <div id="services" class="service-item">
                    <div class="col-md-12">
                     <div class="media services-wrap wow fadeInDown">
                     	<div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/15.png" width="275px" height="200px"><br>
                            <img class="img-responsive" src="roadsigns/images/16.jpg" width="275px" height="200px"><br>
                            <img class="img-responsive" src="roadsigns/images/17.jpg" width="275px" height="200px">
                        </div>
                         <div class="media-body">
                           <h4 class="media-heading">Limit Of Alchohol</h4>
                           <p>
                            <ul>
                              <li>Impairment by alcohol is an important factor in causing accidents and in increasing the consequences of the same. From various studies conducted in low income countries, it has been found that alcohol was present in between 33% and 69% of fatally injured drivers, and in between 8% and 29% of drivers involved in crashes who were not fatally injured. Drivers and motor cyclists with any level of BAC greater than zero are at higher risk of a crash than those whose BAC is zero.</li>
                              <li>With increasing BAC levels, the risk being involved in a crash starts to rise significantly at a BAC of 40 mg for 100 ml of blood. In experience, young/adults with BAC above zero have 2.5 times the risk of crash compared with more experience drivers. 
                               </li>
                               <li>A study on drivers killed in road crashes has revealed that teenage drivers have more than 5 times the risk of a crash compared with drivers aged 30 and above, at all level of BAC. Drivers 22 to 29 years old were estimated to have 3 times the risk compared with drivers aged 30 years and above, at all BAC levels. </li>
                               <li>• Punished for the first offence with imprisonment for a term which may extend upto 6 months or a fine upto    Rs.2,000/- or both, and </li>
                               <li>• For a subsequent offence committed within 3 yeas of the previous offence, with imprisonment which may extend    to 2 years or fine upto Rs.3,000/- or both.</li>
                           </ul>
                          </p>
                        </div>
                     </div>
                    </div>
                    </div>  	
             	 </div>	
            </div> 
           </fieldset>
         </form>
    	 </div>	
    </div>	