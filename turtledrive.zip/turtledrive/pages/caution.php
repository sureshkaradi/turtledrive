 <?php include_once("template.php");?>
 <style type="text/css">
.well a{
  color:#fff;
}
.well a:hover, a:focus {
  color: #d43133;
}
.active a{
  color: red;
}
.media td {
 width:25%;
 padding: 2%;
}
.media  a{
  color:black;
  text-transform: uppercase;
}
.thumbnail{
  background-color: #6BA7FA;
  text-align: center;
  color: #fff;
}
.thumbnail img{
  background-color: transparent transparent;
  width:200px;
  height: 150px;
  color: #fff;
}
</style>
  <hr>
    <div class="container">
      <div class="row">
         <div class="col-lg-3">
              <form class="well form-horizontal" action=" " method="post"  id="contact_form">
               <fieldset>
                <ul>
                  <li class="active"><h5><a href="mandatory.php">road signs</a></h5></li>
                  <li color="#fff"><h5><a href="ror.php">rules of the road</a></h5></li>
                  <li><h5><a href="agelimit.php">Age limit</a></h5></li>
                  <li color="#fff"><h5><a href="alcho.php">alchol limit</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">Tips For Driving Licence</a></h5></li>
                  <li color="#fff"><h5><a href="llr.php">how to get llr</a></h5></li>
                  <li color="#fff"><h5><a href="pdl.php">how to get permnent dl</a></h5></li>
                  <li color="#fff"><h5><a href="idl.php">how to get international dl</a></h5></li>
                  <li color="#fff"><h5><a href="tint.php">tinted glass</a></h5></li>
                  <li color="#fff"><h5><a href="noc.php">noc</a></h5></li>
                  <li color="#fff"><h5><a href="oop.php">offence of penalties</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">driving tips</a></h5></li>
                </ul>
               </fieldet>
              </form> 
            </div> 
             <div class="col-lg-9">
              <form class="well form-horizontal">
                <fieldset>
               <div id="services" class="service-item">
                    <div class="col-md-12">
                     <div class="media services-wrap wow fadeInDown">
                         <div class="media-body">
                         <ul class="nav nav-pills">
          <li ><a href="mandatory.php">Mandatory Signs</a></li>
         <li class="active"><a href="caution.php">Cautionary signs</a></li>
         <li><a href="infosign.php">Informatory signs</a></li>
        </ul>

                           <h4 class="media-heading">Cautionary Signs</h4>
                           
                            <table  width="100%">
                             <tr>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/1.jpg"alt="">
                    <h5>RIGHT HAND CURVE</h5>
                </a></td>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/2.jpg" alt="">
                    <h5>LEFT HAND CURVE</h5>
                </a></td> 
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/4.jpg" alt="">
                    <h5>LEFT HAIR PIN BAND</h5>
                </a></td>
                               <td>  <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/5.jpg" alt="">
                    <h5>RIGHT REVERSE BAND</h5>
                </a></td>
                             </tr>
                             <tr>
                             <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/6.jpg" alt="">
                    <h5>LEFT REVERSE BAND</h5>
                </a></td>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/3.jpg" alt="">
                    <h5>RIGHT HAIR PIN BAND</h5>
                </a></td>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/8.jpg" alt="">
                    <h5>STEEP DESCENT</h5>
                </a></td>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/7.jpg" alt="">
                    <h5>STEEP ASCENT</h5>
                </a></td> 
                             </tr> 
                             <tr>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/10.jpg" alt="">
                    <h5>SLIPPERY ROAD</h5>
                </a></td>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/9.jpg" alt="">
                    <h5>NARROW ROAD AHEAD</h5>
                </a></td>
                             <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/12.jpg" alt="">
                    <h5>CYCLE CROSSING</h5>
                </a></td> 
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/11.jpg"  alt="">
                    <h5>LOOSE GRAVEL</h5>
                </a></td>
                             </tr> 
                             <tr>
                             <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/13.jpg"alt="">
                    <h5>PEDESTRIAN CROSSING</h5>
                </a></td>
                             <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/14.jpg" alt="">
                    <h5>SCHOOL AHEAD</h5>
                </a></td>     
                              <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/15.jpg" alt="">
                    <h5>MEN AT WORK</h5>
                </a></td>
                              <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/16.jpg" alt="">
                    <h5>CATTLE</h5>
                </a></td>
                             </tr> 
                             <tr>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/17.jpg" alt="">
                    <h5>FALLING ROCKS</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/18.jpg" alt="">
                    <h5>FERRY</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/19.jpg" alt="">
                    <h5>CROSS ROAD</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/20.jpg" alt="">
                    <h5>GAP IN MEDIAN</h5>
                </a></td>
                             </tr>  
                             <tr>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/21.jpg" alt="">
                    <h5>SIDE ROAD RIGHT</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/22.jpg" alt="">
                    <h5>SIDE-ROAD-LEFT</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/23.jpg"  alt="">
                    <h5>← Y - INTERSECTION →</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/24.jpg" alt="">
                    <h5>STAGGERED INTERSECTION</h5>
                </a></td>
                             </tr>
                             <tr>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/25.jpg"alt="">
                    <h5>T-INTERSECTION</h5>
                </a></td>
                               <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/26.jpg" alt="">
                    <h5>MAJOR ROAD AHEAD</h5>
                </a></td>
                               <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/27.jpg" alt="">
                    <h5>ROUND ABOUT</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/28.jpg" alt="">
                    <h5>DANGEROUS DIP</h5>
                </a></td>
                             </tr>
                             <tr>
                               <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/29.jpg" alt="">
                    <h5>HUMP OR ROUGH ROAD</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/30.jpg" alt="">
                    <h5>BARRIER AHEAD</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/31.jpg" alt="">
                    <h5>UNGUARDED LEVEL CROSSING</h5>
                </a></td>
                               <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/32.jpg" alt="">
                    <h5>UNGUARDED LEVEL CROSSING</h5>
                </a></td>
                             </tr>
                             <tr>
                               <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/cautionary/33.jpg" alt="">
                    <h5>GUARDED LEVEL CROSSING (200 METERS)</h5>
                </a></td>
                             </tr>

                            </table>
                        </div>
                     </div>
                    </div>
                    </div>    
               </div> 
            </div> 
           </fieldset>
         </form>
       </div> 
    </div>  