<?php include_once("template2.php");?>
<hr>