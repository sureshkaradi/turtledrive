 <?php include_once("template.php");?>
 <style type="text/css">
.well a{
  color:#fff;
}
.well a:hover, a:focus {
  color: #d43133;
}
.active a {
  color: red;
}

</style>
  <hr>
    <div class="container">
      <div class="row">
         <div class="col-lg-3">
           <form class="well form-horizontal" action=" " method="post"  id="contact_form">
               <fieldset>
                <ul>
                  <li color="#fff"><h5><a href="mandatory.php">road signs</a></h5></li>
                  <li color="#fff"><h5><a href="ror.php">rules of the road</a></h5></li>
                  <li color="#fff"><h5><a href="agelimit.php">Age limit</a></h5></li>
                  <li color="#fff"><h5><a href="alcho.php">alchol limit</a></h5></li>
                  <li class="active"><h5><a href="dl.php">Tips For Driving Licence</a></h5></li>
                  <li color="#fff"><h5><a href="llr.php">how to get llr</a></h5></li>
                  <li color="#fff"><h5><a href="pdl.php">how to get permnent dl</a></h5></li>
                  <li color="#fff"><h5><a href="idl.php">how to get international dl</a></h5></li>
                  <li color="#fff"><h5><a href="tint.php">tinted glass</a></h5></li>
                  <li color="#fff"><h5><a href="noc.php">noc</a></h5></li>
                  <li color="#fff"><h5><a href="oop.php">offence of penalties</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">driving tips</a></h5></li>
                </ul>
               </fieldet>
              </form> 
            </div> 
             <div class="col-lg-9">
              <form class="well form-horizontal">
                <fieldset>
               <div id="services" class="service-item">
                   <div class="center wow fadeInDown">
                     <h2>Tips For Driving Licence</h2>
                     <p class="lead"></p>
                  </div>
                    <div class="col-md-12">
                      <div class="media services-wrap wow fadeInDown">
                       <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/1.jpg" width="100px" height="100px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">1.Prepare for the Written Test</h4>
                            <p>
                              <ul>
                               <li>You'll learn the basic rules of the road, when to pull over for emergency vehicles (always a favorite on driving exams), speed limits in various zones (another favorite), how to handle accidents, and more.</li> 
                               <li>Read it chapter by chapter, make notes if that helps you remember, and have somebody quiz you after each chapter. If you can answer 80% of the questions, move on to the next chapter</li>
                               <li>At the end of the booklet, ask to be quizzed on the whole manual. Any chapters you don't do well on, revisit. If you go through the book three times in three weeks, your chances of passing—even acing—your test are very high.</li>
                              </ul>
                            </p>
                        </div>
                    </div>
                </div>
                 <div class="col-md-12">
                    <div class="media services-wrap wow fadeInDown">
                     <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/2.jpg" width="100px" height="100px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">2.Prepare for the Practical Test</h4>
                            <p>
                              <ul>
                               <li>Some states also make allowances for top students. While it won't directly help you pass your driving test, being a good student will often make it easier to meet the requirements.</li>
                               <li>Student drivers must have a licensed driver with them at all times. In some states, having a license is all your passenger needs. In some states there are age restrictions, or restrictions based on how long the person has been licensed. You will learn these rules and restrictions in the driver's manual that you're going to study.</li>
                              </ul>
                            </p>
                        </div>
                    </div>
                </div>
                 <div class="col-md-12">
                    <div class="media services-wrap wow fadeInDown">
                     <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/3.jpg" width="100px" height="100px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">3.Practice driving on the test routes.</h4>
                            <p>
                              <ul>
                              <li>Find out in advance where you will be taking the practical test (the actual driving part). While it may be illegal in your state (read the manual), unless you're following specific routes, there should be no problem driving in the general neighborhood.</li>
                              </ul>
                            </p>
                        </div>
                    </div>
                </div>
                 <div class="col-md-12">
                    <div class="media services-wrap wow fadeInDown">
                     <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/5.jpg" width="100px" height="100px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">4.Go for a drive with your parent.  </h4>
                            <p>
                              <ul>
                              <li> The morning before your test, ask them to watch you, and make sure that you check all your mirrors correctly and do all your maneuvers correctly. This will help you gain some confidence.</li>
                              </ul>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="media services-wrap wow fadeInDown">
                     <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/6.jpg" width="100px" height="100px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">5.Make sure your car is ready for the test. </h4>
                            <p>
                             Your registration and insurance should be easily accessible. Tires should be inflated properly and in good condition, lights will all need to be working, windshield wipers functional, with the washer reservoir filled, all instruments—especially the speedometer—working and accurate, and turn the radio off when you get there.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="media services-wrap wow fadeInDown">
                     <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/7.jpg" width="100px" height="100px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">6.Arrive at least 15 minutes prior to your appointment. </h4>
                            <p>
                             Bring your completed and signed Driver's Log, Drivers Ed certificate, driving time with an instructor certificate, your learners permit, and any other papers or certificates required, including your Social Security card and birth certificate for identification purposes.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="media services-wrap wow fadeInDown">
                     <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/8.jpg" width="100px" height="100px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">7.Get in the car with the driving examiner. </h4>
                            <p>
                             Relax, and be friendly. You won't lose points for being unpleasant—necessarily—but if your examiner needs to make a judgement call about your driving at some point, ask yourself: would you be easier on a nice person, or a jerk?
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="media services-wrap wow fadeInDown">
                     <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/9.jpg" width="100px" height="100px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">8.At all times drive at a safe speed. </h4>
                            <p>
                              Note that this does not necessarily mean the speed limit—conditions may warrant a slower speed. Under no circumstances exceed the speed limit.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="media services-wrap wow fadeInDown">
                     <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/10.jpg" width="100px" height="100px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">9.Practice situational awareness. </h4>
                            <p>
                             Check your mirrors regularly. Make this a little more exaggerated than normal, just so it is clear that you are doing it.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="media services-wrap wow fadeInDown">
                     <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/11.jpg" width="100px" height="100px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">10.Obey all signs. </h4>
                            <p>
                              <ul>
                              <li>Don't forget to signal all turns, lane changes, and any time your intent is to change direction</li>
                              </ul>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="media services-wrap wow fadeInDown">
                     <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/12.jpg" width="100px" height="100px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">11.Park confidently. </h4>
                            <p>
                              <ul>
                              <li>Practice with your driving instructor or parent before taking the test so that you can do a clean, confident job of parallel parking, backing up straight, and three- or four-point turns.</li>
                              </ul>
                            </p>
                        </div>
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="media services-wrap wow fadeInDown">
                     <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/13.jpg" width="100px" height="100px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">12.Congratulations, you passed! </h4>
                            <p>
                             If you read this tutorial, and studied the manual, you will almost certainly pass your driver's exam. Be safe out there!
                            </p>
                        </div>
                    </div>
                </div>

                    </div>
                    </div>    
               </div> 
            </div> 
           </fieldset>
         </form>
       </div> 
    </div>  