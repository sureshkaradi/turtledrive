 <?php include_once("template.php");?>
 <style type="text/css">
.well a{
  color:#fff;
}
.well a:hover, a:focus {
  color: #d43133;
}
.active a {
  color: red;
}

</style>
  <hr>
    <div class="container">
      <div class="row">
         <div class="col-lg-3">
            <form class="well form-horizontal" action=" " method="post"  id="contact_form">
               <fieldset>
                <ul>
                  <li color="#fff"><h5><a href="mandatory.php">road signs</a></h5></li>
                  <li color="#fff"><h5><a href="ror.php">rules of the road</a></h5></li>
                  <li color="#fff"><h5><a href="agelimit.php">Age limit</a></h5></li>
                  <li color="#fff"><h5><a href="alcho.php">alchol limit</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">Tips For Driving Licence</a></h5></li>
                  <li color="#fff"><h5><a href="llr.php">how to get llr</a></h5></li>
                  <li color="#fff"><h5><a href="pdl.php">how to get permnent dl</a></h5></li>
                  <li class="active"><h5><a href="idl.php">how to get international dl</a></h5></li>
                  <li color="#fff"><h5><a href="tint.php">tinted glass</a></h5></li>
                  <li color="#fff"><h5><a href="noc.php">noc</a></h5></li>
                  <li color="#fff"><h5><a href="oop.php">offence of penalties</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">driving tips</a></h5></li>
                </ul>
               </fieldet>
              </form> 
            </div> 
             <div class="col-lg-9">
              <form class="well form-horizontal">
                <fieldset>
               <div id="services" class="service-item">
                    <div class="col-md-12">
                     <div class="media services-wrap wow fadeInDown">
                      <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/20.jpg" width="275px" height="200px">
                        </div>
                         <div class="media-body">
                           <h4 class="media-heading">How to get International Driving Permit (IDP)?</h4>
                           <h5 class="media-heading">Requirements :</h5>
                           <ul>
                             <li>Application in Form 4 A.</li>
                             <li>Original & Photo Copies of Passport and Visa.</li>
                              <li>Indian driving Licence : Original & Photo Copy</li>  
                              <li>Applicant should be present in person though there would be no driving Test.</li>
                           </ul>
                           <p>Note : If the Driving Licence is not obtained from the same RTA where the application for 
                           	International Driving Permit is being made, Form – DDL along with address proof and a fee of Rs.315 
                           	may be made to obtain a Duplicate Driving Licence.</p>
                            
                        </div>
                     </div>
                    </div>
                    </div>    
               </div> 
            </div> 
           </fieldset>
         </form>
       </div> 
    </div>  