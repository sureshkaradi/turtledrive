 <?php include_once("template.php");?>
 <style type="text/css">
.well a{
  color:#fff;
}
.well a:hover, a:focus {
  color: #d43133;
}
.active a{
  color: red;
}
.media td {
 width:25%;
 padding: 2%;
}
.media  a{
  color:black;
  text-transform: uppercase;

}
.thumbnail{
  background-color:#6BA7FA;
  text-align: center;
  color: #fff;
}
.thumbnail img{
  background-color: transparent transparent;
  width:200px;
  height: 150px;
  color: #fff;
}

</style>
  <hr>
    <div class="container">
      <div class="row">
         <div class="col-lg-3">
              <form class="well form-horizontal" action=" " method="post"  id="contact_form">
               <fieldset>
                <ul>
                  <li class="active"><h5><a href="mandatory.php">road signs</a></h5></li>
                  <li color="#fff"><h5><a href="ror.php">rules of the road</a></h5></li>
                  <li><h5><a href="agelimit.php">Age limit</a></h5></li>
                  <li color="#fff"><h5><a href="alcho.php">alchol limit</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">Tips For Driving Licence</a></h5></li>
                  <li color="#fff"><h5><a href="llr.php">how to get llr</a></h5></li>
                  <li color="#fff"><h5><a href="pdl.php">how to get permnent dl</a></h5></li>
                  <li color="#fff"><h5><a href="idl.php">how to get international dl</a></h5></li>
                  <li color="#fff"><h5><a href="tint.php">tinted glass</a></h5></li>
                  <li color="#fff"><h5><a href="noc.php">noc</a></h5></li>
                  <li color="#fff"><h5><a href="oop.php">offence of penalties</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">driving tips</a></h5></li>
                </ul>
               </fieldet>
              </form> 
            </div> 
             <div class="col-lg-9 fixed-top">
              <form class="well form-horizontal">
                <fieldset>
               <div id="services" class="service-item">
                    <div class="col-md-12">
                     <div class="media services-wrap wow fadeInDown">
                         <div class="media-body">
                          <ul class="nav nav-pills">
          <li class="active"><a href="mandatory.php">Mandatory Signs</a></li>
         <li><a href="caution.php">Cautionary signs</a></li>
         <li><a href="infosign.php">Informatory signs</a></li>
       </ul>
                           <h4 class="media-heading">Mandatory Signs</h4>
                           
                            <table  width="100%">
                             <tr>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/1.jpg"alt="">
                    <h5>STOP</h5>
                </a></td>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/2.jpg" alt="">
                    <h5>GIVE WAY</h5>
                </a></td> 
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/3.jpg" alt="">
                    <h5>NO ENTRY</h5>
                </a></td>
                               <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/12.jpg" alt="">
                   <h5>HAND CART PROHIBITED</h5>
                </a></td>
                             </tr>
                             <tr>
                             <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/4.jpg" alt="">
                    <h5>ONE WAY</h5>
                </a></td>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/5.jpg" alt="">
                    <h5>ONE WAY</h5>
                </a></td>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/6.jpg" alt="">
                    <h5>PROHIBITED IN BOTH DIRECTIONS</h5>
                </a></td>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/7.jpg" alt="">
                    <h5>ALL MOTOR VEHICLES PROHIBITED</h5>
                </a></td> 
                             </tr> 
                             <tr>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/8.jpg" alt="">
                    <h5>TRUCK PROHIBITED</h5>
                </a></td>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/9.jpg" alt="">
                     <h5>BULLOCK/HAND CART PROHIBITED</h5>
                </a></td>
                             <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/10.jpg" alt="">
                   <h5>BULLOCK CART PROHIBITED</h5>
                </a></td> 
                             <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/11.jpg"  alt="">
                     <h5>TONGAS PROHIBITED</h5>
                </a></td>
                             </tr> 
                             <tr>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/13.jpg"alt="">
                    <h5>CYCLE PROHIBITED</h5>
                </a></td>
                             <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/14.jpg" alt="">
                    <h5>PEDESTRIANS PROHIBITED</h5>
                </a></td>     
                              <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/15.jpg" alt="">
                    <h5>RIGHT TURN PROHIBITED</h5>
                </a></td>
                              <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/16.jpg" alt="">
                    <h5>LEFT TURN PROHIBITED</h5>
                </a></td>
                             </tr> 
                             <tr>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/17.jpg" alt="">
                    <h5>U-TURN PROHIBITED</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/18.jpg" alt="">
                    <h5>OVERTAKING PROHIBITED</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/19.jpg" alt="">
                    <h5>HORN PROHIBITED</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/20.jpg" alt="">
                    <h5>NO PARKING</h5>
                </a></td>
                             </tr>  
                             <tr>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/21.jpg" alt="">
                    <h5>NO STOPPING OR STANDING</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/22.jpg" alt="">
                    <h5>SPEED LIMIT</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/23.jpg"  alt="">
                    <h5>WIDTH LIMIT</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/24.jpg" alt="">
                    <h5>HEIGHT LIMIT</h5>
                </a></td>
                             </tr>
                             <tr>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/25.jpg"alt="">
                    <h5>LENGTH LIMIT</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/26.jpg" alt="">
                    <h5>LOAD LIMIT</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/27.jpg" alt="">
                    <h5>AXLE LOAD LIMIT</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/28.jpg" alt="">
                    <h5>RESTRICTION ENDS SIGN</h5>
                </a></td>
                             </tr>
                             <tr>
                               <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/29.jpg" alt="">
                    <h5>COMPULSORY TURN LEFT</h5>
                </a></td>
                               <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/30.jpg" alt="">
                    <h5>COMPULSORY AHEAD</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/31.jpg" alt="">
                    <h5>COMPULSORY TURN RIGHT</h5>
                </a></td>
                               <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/32.jpg" alt="">
                    <h5>COMPULSORY AHEAD OR TURN RIGHT</h5>
                </a></td>
                             </tr>
                             <tr>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/33.jpg" alt="">
                    <h5>COMPULSORY AHEAD/TURN LEFT</h5>
                </a></td>
                               <td> <a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/34.jpg" alt="">
                    <h5>COMPULSORY KEEP LEFT</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/35.jpg"  alt="">
                    <h5>COMPULSORY CYCLE TRACK</h5>
                </a></td>
                               <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/36.jpg" alt="">
                    <h5>COMPULSORY SOUND HORN</h5>
                </a></td>
                             </tr>
                             <tr>
                              <td><a class="thumbnail" href="#">
                    <img class="img-responsive" src="roadsigns/mandatory/37.jpg" alt="">
                    <h5>COMPULSORY BUS STOP</h5>
                </a></td>
                             </tr>

                            </table>
                        </div>
                     </div>
                    </div>
                    </div>    
               </div> 
            </div> 
           </fieldset>
         </form>
       </div> 
    </div>  