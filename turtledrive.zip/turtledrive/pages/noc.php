 <?php include_once("template.php");?>
 <style type="text/css">
.well a{
  color:#fff;
}
.well a:hover, a:focus {
  color: #d43133;
}
.active a {
  color: red;
}

</style>
  <hr>
    <div class="container">
      <div class="row">
         <div class="col-lg-3">
            <form class="well form-horizontal" action=" " method="post"  id="contact_form">
               <fieldset>
                <ul>
                  <li color="#fff"><h5><a href="mandatory.php">road signs</a></h5></li>
                  <li color="#fff"><h5><a href="ror.php">rules of the road</a></h5></li>
                  <li color="#fff"><h5><a href="agelimit.php">Age limit</a></h5></li>
                  <li color="#fff"><h5><a href="alcho.php">alchol limit</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">Tips For Driving Licence</a></h5></li>
                  <li color="#fff"><h5><a href="llr.php">how to get llr</a></h5></li>
                  <li color="#fff"><h5><a href="pdl.php">how to get permnent dl</a></h5></li>
                  <li color="#fff"><h5><a href="idl.php">how to get international dl</a></h5></li>
                  <li color="#fff"><h5><a href="tint.php">tinted glass</a></h5></li>
                  <li class="active"><h5><a href="noc.php">noc</a></h5></li>
                  <li color="#fff"><h5><a href="oop.php">offence of penalties</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">driving tips</a></h5></li>
                </ul>
               </fieldet>
              </form> 
            </div> 
             <div class="col-lg-9">
              <form class="well form-horizontal">
                <fieldset>
               <div id="services" class="service-item">
                    <div class="col-md-12">
                     <div class="media services-wrap wow fadeInDown">
                     <h4 class="media-heading"> WHY N.O.C IS REQUIRED ?</h4>
                     <p>Who ever wants to shift his vehicle from one state to other state needs a ‘ No Objection Certificate ’ for getting his Vehicle and Registration Certificate transferred to other states. As per the rules, R.T.Authority insists on N.O.C before issuing clearance to the candidate.</p>
                     <h4 class="media-heading"> WHOM TO APPLY FOR NOC ? </h4>
                     <p>To obtain N.O.C one has to apply to Dy. Commissioner of Police, Traffic Branch, Police Control Room, to obtain N.O.C in respect of Traffic violations and also apply to Dy. Commissioner of Police, Detective Department, Central Crime Station, Police Control Room, Lal Bahadur Stadium, Hyderabad in respect of criminal records.</p>
                     <h4 class="media-heading"> WHAT IS PROCEDURE FOR APPLYING FOR NOC ?</h4>
                     <p>
                      <ol>
                       <li>To obtain N.O.C for the vehicle for no dues in traffic violations one should apply to the Dy.Commissioner of Police, Traffic Branch, Hyderabad by giving an application </li>
                       <li>The person should also apply for N.O.C from crime point of view to the Dy.Commissioner of Police, Detective Department, Hyderabad in writing and enclose Xerox copy of R.C. Book of vehicle and receipt of Rs.100/- e’ challan. His personal appearance is required here. </li>
                       <li>Candidate should produce the original R.C book of the vehicle at the time of obtaining the N.O.C.</li>
                       <li> After obtaining the N.O.C he/she should submit the same in concerned R.T.A office along with relevant form to get the vehicle transferred to other state of his/her choice.</li>
                      </ol>
                     </p>
                     </div>
                    </div>
                    </div>    
               </div> 
            </div> 
           </fieldset>
         </form>
       </div> 
    </div>  