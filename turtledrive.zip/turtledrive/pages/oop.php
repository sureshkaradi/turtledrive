 <?php include_once("template.php");?>
 <style type="text/css">
.well a{
  color:#fff;
}
.well a:hover, a:focus {
  color: #d43133;
}
.active a {
  color: red;
}

</style>
  <hr>
    <div class="container">
      <div class="row">
         <div class="col-lg-3">
              <form class="well form-horizontal" action=" " method="post"  id="contact_form">
               <fieldset>
                <ul>
                  <li color="#fff"><h5><a href="mandatory.php">road signs</a></h5></li>
                  <li color="#fff"><h5><a href="ror.php">rules of the road</a></h5></li>
                  <li color="#fff"><h5><a href="agelimit.php">Age limit</a></h5></li>
                  <li color="#fff"><h5><a href="alcho.php">alchol limit</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">Tips For Driving Licence</a></h5></li>
                  <li color="#fff"><h5><a href="llr.php">how to get llr</a></h5></li>
                  <li color="#fff"><h5><a href="pdl.php">how to get permnent dl</a></h5></li>
                  <li color="#fff"><h5><a href="idl.php">how to get international dl</a></h5></li>
                  <li color="#fff"><h5><a href="tint.php">tinted glass</a></h5></li>
                  <li color="#fff"><h5><a href="noc.php">noc</a></h5></li>
                  <li class="active"><h5><a href="oop.php">offence of penalties</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">driving tips</a></h5></li>
                </ul>
               </fieldet>
              </form> 
            </div> 
             <div class="col-lg-9">
              <form class="well form-horizontal">
                <fieldset>
               <div id="services" class="service-item">
                    <div class="col-md-12">
                     <div class="media services-wrap wow fadeInDown">
                     
                         <div class="media-body">
                           <h4 class="media-heading">Offence and Penal Sections</h4>
                           <table border="1px"align="center" width="100%">
  
  <tr>
    
   <th width="20%"></th>
    <th width="50%">Offence Description</th>
    <th width="15%">Penal section</th>
    <th width="15%">Amount</th>
  </tr>
  
  <tr>

  
    
    <td> <img class="img-responsive" src="roadsigns/offence/1.jpg" width="100px" height="100px"></td>
    <td>Red Light Jumping</a></td>
    <td>  119/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/2.jpg" width="100px" height="100px"></td>
    <td>Driving Left Hand Drive without Indicator</a></td>
    <td>  120/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/3.jpg" width="100px" height="100px"></td>
    <td>  Improper and Obstructive Parking</a></td>
    <td>  122/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/4.jpg" width="100px" height="100px"></td>
    <td>  Travelling on Running Board (Driver)</a></td>
    <td>  123(1)/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/5.jpg" width="100px" height="100px"></td>
    <td>Travelling on Running Board (Passenger)</a></td>
    <td>  123(2)/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/6.jpg" width="100px" height="100px"></td>
    <td>  Triple Riding</a></td>
    <td> 128/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
  
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/7.jpg" width="100px" height="100px"></td>
    <td>Driving without Helmet</a></td>
    <td>  129/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/8.jpg" width="100px" height="100px"></td>
    <td>  Not Displaying Number Plate</a></td>
    <td>  50/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/9.jpg" width="100px" height="100px"></td>
    <td>  Misbehaviour by KSRTC/BMTC/Taxi Drive</a></td>
    <td>  11.3/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/10.jpg" width="100px" height="100px"></td>
    <td>Over Charging by KSRTC/BMTC/Taxi</a></td>
    <td>  11.8/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/11.jpg" width="100px" height="100px"></td>
    <td>  Driving without Horn</a></td>
    <td>  119(1)/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/12.jpg" width="100px" height="100px"></td>
    <td>  Driving without Silencer</a></td>
    <td>  120/190(2) MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/13.jpg" width="100px" height="100px"></td>
    <td>Driving with a Defective Number Plate </a></td>
    <td>  50/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/14.jpg" width="100px" height="100px"></td>
    <td>with a Defective Number Plate</a></td>
    <td>  113/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/15.jpg" width="100px" height="100px"></td>
    <td>Disobeying Lawful Directions</a></td>
    <td>132/179 MVA</td>
    <td>Rs. 1000</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/16.jpg" width="100px" height="100px"></td>
    <td>Allowing unauthorised person to drive</a></td>
    <td>  5/180 MVA</td>
    <td>Rs. 1000</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/17.jpg" width="100px" height="100px"></td>
    <td>Driving without Licence</a></td>
    <td>  3/181 MVA</td>
    <td>Rs. 500</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/18.jpg" width="100px" height="100px"></td>
    <td>Driving by Minors</a></td>
    <td>4/181 MVA</td>
    <td>Rs. 500</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/19.jpg" width="100px" height="100px"></td>
    <td>Over Speeding (1st Offence)</a></td>
    <td>  112/183(1) MVA</td>
    <td>Rs. 400</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/20.jpg" width="100px" height="100px"></td>
    <td>  Abetment of Over Speeding</a></td>
    <td>112/183(2) MVA</td>
    <td>Rs. 300</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/21.jpg" width="100px" height="100px"></td>
    <td>Over Speeding (Subsequent Offence</a></td>
    <td>  112/183(1) MVA</td>
    <td>Rs. 300</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/22.jpg" width="100px" height="100px"></td>
    <td>  Driving Dangerously (1st Offence)</a></td>
    <td>184 MVA</td>
    <td>Rs. 1000</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/23.jpg" width="100px" height="100px"></td>
    <td>  Driving Dangerously (2nd Offence)</a></td>
    <td>184 (2) MVA</td>
    <td></td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/24.jpg" width="100px" height="100px"></td>
    <td>Using `Unregistered Vehicles' or Displaying "Applied for"</a></td>
    <td>  39/192 MVA</td>
    <td>Rs. 2000</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/25.jpg" width="100px" height="100px"></td>
    <td>Violation of Restriction of Time on HTV's/Care on Various Roads</a></td>
    <td>  115/194 MVA</td>
    <td>Rs. 2000</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/26.jpg"width="100px" height="100px"></td>
    <td>  Violation of mandatory signs (One Way No Right Turn, No Left Turn, No Horn</a></td>
    <td>  119/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/27.jpg" width="100px" height="100px"></td>
    <td>  Excess Smoke</a></td>
    <td>99(1)(a)/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/28.jpg" width="100px" height="100px"></td>
    <td>  Blowing of Pressure Horn</a></td>
    <td>96(1)/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/29.jpg" width="100px" height="100px"></td>
    <td>Conductor without Uniform</a></td>
    <td>  23(1)/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/30.jpg" width="100px" height="100px"></td>
    <td>Driver without Uniform</a></td>
    <td>7/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/31.jpg" width="100px" height="100px"></td>
    <td>  Carrying Passengers on Goods Vehicles</a></td>
    <td>  84(2)/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/32.jpg" width="100px" height="100px"></td>
    <td>  Carrying Goods on Passengers Vehicle</a></td>
    <td>84(3)/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/33.jpg" width="100px" height="100px"></td>
    <td>Use of Coloured Light on Motor Vehicle</a></td>
    <td>  97(2)/177 MVA</td>
    <td>Rs. 100</td>
  </tr>
   <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/34.jpg" width="100px" height="100px"></td>
    <td>  Using Mobile Phone while Driving</a></td>
    <td>  184 MVA</td>
    <td>Rs. 1000</td>
  </tr>
 <tr>
    
  
    
    <td> <img class="img-responsive" src="roadsigns/offence/35.jpg" width="100px" height="100px"></td>
    <td>  Wrong Overtaking</a></td>
    <td>  6(1)RRR/177 MVA</td>
    <td>Rs. 100</td>
  </tr>

</table>
  Note:MVA   Motor Vehicle Act, 1988<br>
       CMVR  Central Motor Velhicles Rules, 1989<br>
       KMVR   Karnataka Motor Vehicles Rules, 1989<br>
       RRR  Rules of Road Regulation, 1989

                        </div>
                     </div>
                    </div>
                    </div>    
               </div> 
            </div> 
           </fieldset>
         </form>
       </div> 
    </div>  
     <?php include_once("footer.php");?>  