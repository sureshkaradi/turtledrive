<?php include_once("template.php");?> 
<hr>
<body>
<section id="services" class="service-item">
	   <div class="container">
            <div class="center wow fadeInDown">
                <h2>Resources</h2>
                <p class="lead"></p>
            </div>

            <div class="row">

                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">
                      <a href="mandatory.php"> <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/resources/1.png" width="75px" height="75px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">Road Signs</h4>
                            <p></p>
                        </div>
                        </a> 
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">
                       <a href="dl.php"> <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/resources/2.png" width="75px" height="75px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">Tips For Driving Licence</h4>
                            <p></p>
                        </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">
                       <a href="ror.php"> <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/resources/3.png" width="75px" height="75px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">Rules Of The Road</h4>
                            <p></p>
                        </div>
                        </a>
                    </div>
                </div>  
                
               

                                                          
            </div><!--/.row  1-->
             <div class="row">

                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">
                     <a href="agelimit.php">   <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/resources/4.png" width="75px" height="75px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">Age Limit For Obtaining DL</h4>
                            <p></p>
                        </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">
                       <a href="llr.php"> <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/resources/5.png" width="130px" height="130px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">How Get LLR</h4>
                            <p></p>
                        </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">
                       <a href="pdl.php"> <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/resources/6.png" width="75px" height="75px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">How Get permenent DL</h4>
                            <p></p>
                        </div>
                        </a>
                    </div>
                </div>  
                
               

                                                          
            </div><!--/.row 2-->
             <div class="row">

                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">
                      <a href="idl.php">  <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/resources/7.png" width="75px" height="75px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">How To Get Intenational DL</h4>
                            <p></p>
                        </div>
                        </a> 
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">
                      <a href="tint.php"> <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/resources/8.jpg" width="130px" height="130px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">Tinted Glass</h4>
                            <p></p>
                        </div>
                        </a> 
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">
                       <a href="alcho.php"> <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/resources/9.jpg" width="75px" height="75px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">Limit Of Alchohol</h4>
                            <p></p>
                        </div>
                     </a>
                    </div>
                </div>  
                
               

                                                          
            </div><!--/.row 3-->
             <div class="row">

                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">
                       <a href="noc.php"> <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/resources/10.png" width="75px" height="75px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">NOC</h4>
                            <p></p>
                        </div>
                        </a> 
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">
                       <a href="oop.php"> <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/resources/11.png" width="75px" height="75px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">Offence Of Penalties</h4>
                            <p></p>
                        </div>
                        </a>
                    </div>
                </div>

                <div class="col-sm-6 col-md-4">
                    <div class="media services-wrap wow fadeInDown">
                       <a href="dl.php"> <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/resources/12.jpg" width="50px" height="50px">
                        </div>
                        <div class="media-body">
                            <h4 class="media-heading">Driving Tips</h4>
                            <p></p>
                        </div>
                        </a>
                    </div>
                </div>  
                
               

                                                          
            </div><!--/.row 4-->
        </div><!--/.container-->
    </section><!--/#services-->
     <?php include_once("footer.php");?>    
