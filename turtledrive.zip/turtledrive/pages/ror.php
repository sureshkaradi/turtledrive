 <?php include_once("template.php");?>
 <style type="text/css">
.well a{
  color:#fff;
}
.well a:hover, a:focus {
  color: #d43133;
}
.active a {
  color: red;
}

</style>
  <hr>
    <div class="container">
      <div class="row">
         <div class="col-lg-3">
             <form class="well form-horizontal" action=" " method="post"  id="contact_form">
               <fieldset>
                <ul>
                  <li color="#fff"><h5><a href="mandatory.php">road signs</a></h5></li>
                  <li class="active"><h5><a href="ror.php">rules of the road</a></h5></li>
                  <li color="#fff"><h5><a href="agelimit.php">Age limit</a></h5></li>
                  <li color="#fff"><h5><a href="alcho.php">alchol limit</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">Tips For Driving Licence</a></h5></li>
                  <li color="#fff"><h5><a href="llr.php">how to get llr</a></h5></li>
                  <li color="#fff"><h5><a href="pdl.php">how to get permnent dl</a></h5></li>
                  <li color="#fff"><h5><a href="idl.php">how to get international dl</a></h5></li>
                  <li color="#fff"><h5><a href="tint.php">tinted glass</a></h5></li>
                  <li color="#fff"><h5><a href="noc.php">noc</a></h5></li>
                  <li color="#fff"><h5><a href="oop.php">offence of penalties</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">driving tips</a></h5></li>
                </ul>
               </fieldet>
              </form> 
            </div> 
             <div class="col-lg-9">
              <form class="well form-horizontal">
                <fieldset>
               <div id="services" class="service-item">
                    <div class="col-md-12">
                     <div class="media services-wrap wow fadeInDown">
                     	<h4 class="media-heading">Rules Of The Road</h4>
                     <table border="1px"align="center" width="100%">
                     	 <tr>
    
                           <th width="20%"></th>
                           <th width="80%">Rules</th>
   
                          </tr>
  
                            <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/36.png" width="100px" height="100px"></td>
                              <td>Traffic signals and Road Signs should be strictly followed.</td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/37.png" width="100px" height="100px"></td>
                              <td>	Keep Left while driving on a Two-Way Road.</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/38.png" width="100px" height="100px"></td>
                              <td>Keep to the left side of the road if you are taking a turn to the left and enter the road from the left of the road. When turning 
                              	Right move to the center of the road you are leaving and join the center of the entering road.</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/39.png" width="100px" height="100px"></td>
                              <td>Slow down at Road Junctions, Intersections, Pedestrian Crossings and Road Corners
                               and Wait till you get clear view of the passage ahead.</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/40.jpg" width="100px" height="100px"></td>
                              <td>Give way to vehicles coming from your right side..</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/41.jpg" width="100px" height="100px"></td>
                              <td>Hand signals should also be used along with Direction Indicators.</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/42.jpg" width="100px" height="100px"></td>
                              <td>Park your vehicle at the place meant for parking. Do not park your vehicle at or near Road Crossing, on the Footpaths or
                               at Hilltops, too near to Traffic Signals, near a Pedestrian Crossing,
                               on a Main Road, in Front of or Opposite to another Parked Vehicle, near a Bus Stop or near a School or a Hospital.</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/43.jpg" width="100px" height="100px"></td>
                              <td>Ensure Correctness of the Registration Mark on the Vehicle and make sure, Brakes, Tail Lights, Brake Lights and
                               Indicators are functioning correctly.</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/44.jpg" width="100px" height="100px"></td>
                              <td>Ensure that you are carrying your Driving Licence (DL) and other important documents of the Vehicle.</td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/45.jpg" width="100px" height="100px"></td>
                              <td>Do not Cross the Road when Yellow Light is ON.</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/46.jpg" width="100px" height="100px"></td>
                              <td>Do not Cross the STOP Line.</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/47.jpg" width="100px" height="100px"></td>
                              <td>Use the Horn of your vehicle only when necessary. Do not use Loud, Harsh or Multi Toned or Shrill sounding Horns. At turnings,
                               slow down and check for Vehicles instead of using your Vehicle Horn.</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/48.jpg" width="100px" height="100px"></td>
                              <td>	Maintain the 2 Sec Rule (GAP) or a reasonable distance with the Vehicle in Front of you</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/49.jpg" width="100px" height="100px"></td>
                              <td>Do not apply Sudden Brakes</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/50.jpg" width="100px" height="100px"></td>
                              <td>Vehicles coming Up Hill must be given Right of Way by the Vehicles coming Down Hill.</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/51.jpg" width="100px" height="100px"></td>
                              <td>Always give way to Pedestrians.</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/52.jpg" width="100px" height="100px"></td>
                              <td>Never indulge in Zig Zag Driving as it may not only cause accidents but also inconvenience to 
                              	other road users. Always Drive in Straight Line.</a></td>
                            </tr>
                             <tr>
                              <td> <img class="img-responsive" src="roadsigns/offence/53.jpg" width="100px" height="100px"></td>
                              <td>Do not Overtake another Vehicle which is stopped at a Pedestrian Crossing or at a School Crossing.</a></td>
                            </tr>
                            
                     </table>	
                     </div>
                    </div>
                    </div>    
               </div> 
            </div> 
           </fieldset>
         </form>
       </div> 
    </div> 
     <?php include_once("footer.php");?>   