
<?php include_once("template1.php");?> 

<style type="text/css">
.well a{
  color:#fff;
}
.well a:hover, a:focus {
  color: #d43133;
}
.active a {
  color: red;
}

</style>
 <hr>
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
            <form class="well form-horizontal" action=" " method="post"  id="contact_form">
               <fieldset>
                <ul>
                  <li color="#fff"><h5><a href="mandatory.php">road signs</a></h5></li>
                  <li color="#fff"><h5><a href="ror.php">rules of the road</a></h5></li>
                  <li color="#fff"><h5><a href="agelimit.php">Age limit</a></h5></li>
                  <li color="#fff"><h5><a href="alcho.php">alchol limit</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">Tips For Driving Licence</a></h5></li>
                  <li color="#fff"><h5><a href="llr.php">how to get llr</a></h5></li>
                  <li color="#fff"><h5><a href="pdl.php">how to get permnent dl</a></h5></li>
                  <li><h5><a href="idl.php">how to get international dl</a></h5></li>
                  <li color="#fff"><h5><a href="tint.php">tinted glass</a></h5></li>
                  <li color="#fff"><h5><a href="noc.php">noc</a></h5></li>
                  <li color="#fff"><h5><a href="oop.php">offence of penalties</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">driving tips</a></h5></li>
                </ul>
               </fieldet>
              </form> 
            </div> 
            <div class="col-lg-9">
               <h3><span> Application forms for Driving Licence/Conductor Licence/International Driving Permit</span></h3>

<table class="responstable">
  
  <tr>
    
    
    <th width="80%">SERVICES</th>
    <th width="20%">FORM NO</th>
  </tr>
  
  <tr>
  
    
    <td>Issue of Learner’s licence</td>
    <td><a href="rto/form2.pdf">CMV-2</a></td>
  </tr>
  
  <tr>
   
 
    <td>Duplicate Learner’s licence</td>
    <td><a href="rto/kmv1a.pdf">KMV-1A</a></td>
  </tr>
  
  <tr>
   
   
    <td>Permanent Driving Licence</td>
    <td><a href="rto/form4.pdf">CMV-4</a></td>
  </tr>
   <tr>
   
   
    <td>Renewal of Driving Licence</td>
   <td><a href="rto/cmv9.pdf">CMV-9</a></td>
  </tr>
  
  <tr>
   
   
    <td>Addition of new class of vehicle to a driving licence</td>
    <td><a href="rto/cmv8.pdf">CMV-8</a></td>
  </tr>
   <tr>
   
   
    <td>Duplicate Driving Licence</td>
    <td><a href="rto/kmv1a.pdf">kMV-1</a></td>
  </tr>
   <tr>
    <td>Change of Address in Learners’ licence/Driving Licence</td>
     <td>plain paper</td>
  </tr>
   <tr>
    <td>International Driving Permit</td>
    <td><a href="rto/International Driving Permit.pdf">Form 4A</a></td>
  </tr>
   <tr>
    <td>Issue of Conductor licence</td>
    <td><a href="rto/kmv12.pdf">KMV-12</a> <br>
         <a href="rto/kmv13.pdf">KMV-13</a></td>
  </tr>
  <tr>
    <td>Renewal of Conductor licence</td>
      <td><a href="rto/kmv13.pdf">KMV-13</a> <br>
         <a href="rto/kmv15.pdf">KMV-15</a></td>
  </tr>
    <tr>
    <td>Medical Forms</td>
    <td><a href="rto/medical forms.pdf">CMV Form 1 & CMV Form 1A</a></td>
  </tr>

</table>
 <h3><span>Application forms for Vehicle Registration and related services</h3></span>
 <table class="responstable">
  
  <tr>
    
    
    <th width="80%">SERVICES</th>
    <th width="20%">FORM NO</th>
  </tr>
  
  <tr>
  
    
    <td>Temporary Registration</td>
    <td><a href="rto/cmv18.pdf">KMV-18</a></td>
  </tr>
  
  <tr>
   
 
    <td>Permanent Registration</td>
    <td><a href="rto/form20.pdf">CMV-20</a></td>
  </tr>
  
  <tr>
   
   
    <td>Transfer of Ownership</td>
    <td>
      <a href="rto/cmv29.pdf">CMV-29(in duplicate)</a><br>
      <a href="rto/cmv30.pdf">CMV-30</a></td>
  </tr>
   <tr>
   
   
    <td>  
Transfer of Ownership in case of death of registered owner
</td>
   <td><a href="rto/FORM31(1).pdf">CMV-31</a></td>
  </tr>
  
  <tr>
   
   
    <td>Noting of Hire Purchase/Lease/Hypothecation

</td>
    <td><a href="rto/cmv34.pdf">CMV-34</a></td>
  </tr>
   <tr>
   
   
    <td>Termination of Hire Purchase/Lease/Hypothecation

</td>
    <td><a href="rto/cmv35.pdf">CMV-35</a></td>
  </tr>
   <tr>
    <td>Change of Address

 </td>
     <td><a href="rto/cmv33.pdf">CMV-33</a>
<a href="rto/KMV 27.pdf">KMV-27 (in case of other state vehicle)</a>
<a href="rto/CMV 27[1].pdf">CMV 27 </a>
<a href="rto/cmv 27 kannada[1].pdf">(for Re-Registration) Kannada CMV27</a></td>
  </tr>
   <tr>
    <td>Issue of No-Objection Certificate (NOC)</td>
    <td><a href="rto/cmv28.pdf">CMV-28 (in quadruplicate)</a></td>
  </tr>
   <tr>
    <td>Payment of Tax</td>
    <td><a href="rto/kmvt-14.pdf">KMVT-14</a></td>
  </tr>
  <tr>
    <td>Renewal of Registration Certificate</td>
      <td><a href="rto/cmv25.pdf">CMV 25</a></td>
  </tr>
    <tr>
    <td>Issue/Renewal of Fitness Certificate</td>
    <td><a href="rto/kmv20.pdf">KMV 20</a></td>
  </tr>
  <tr>
    <td>Application for Refund of Tax</td>
     <td><a href="rto/Form_16.pdf">Form 16</a> </td>
  
  </tr>
  <tr>
    <td>Application For Transfer Of Ownership In The Name Of The Person Succeeding To The Possession Of The Vehicle</td>
     <td><a href="rto/FORM31.pdf">Form 31</a> </td>
  
  </tr>
  <tr>
    <td>Application for the issue of Duplicate Certificate of Registration</td>
     <td><a href="rto/FORM26.pdf">Form 26</a> </td>
  
  </tr>

</table>
            </div> 
              

                  
       </div>
    </div>    

<?php include_once("footer.php");?>  