<style type="text/css">
@import url(https://fonts.googleapis.com/css?family=Quicksand:400,300);
body{
    font-family: 'Quicksand', sans-serif;
}
.team1 {
   
   border-color: red;
   
}
.team p{
   
    text-align: justify;
}
h6.description{
	font-weight: bold;
	letter-spacing: 2px;
	color: #565656;
	border-bottom: 1px solid rgba(0, 0, 0,0.1);
	padding-bottom: 5px;
	font-size: 20px;
	text-align: center;
}
.profile{
	margin-top: 25px;
}
.profile h1{
	font-weight: normal;
	font-size: 20px;
	margin:10px 0 0 0;
}
.team .profile h2{
	font-size: 14px;
	font-weight: lighter;
	margin-top: 5px;
	text-align: left;
}
.profile .img-box{
	opacity: 1;
	display: block;
	position: relative;
    border-radius: 50%;
}
.img-responsive{
	border-radius: 5px;
}
 .img-box{
	opacity: 1;
	display: block;
	position: relative;
    border-radius: 50%;
}
.profile .img-box:after{
	content:"";
	opacity: 0;
	background-color: rgba(0, 0, 0, 0.75);
	position: absolute;
	right: 0;
	left: 0;
	top: 0;
	bottom: 0;
}
.img-box ul{
	position: absolute;
	z-index: 2;
	bottom: 50px;
	text-align: center;
	width: 100%;
	padding-left: 0px;
	height: 0px;
	margin:0px;
	opacity: 0;
}
.profile .img-box:after, .img-box ul, .img-box ul li{
	-webkit-transition: all 0.5s ease-in-out 0s;
    -moz-transition: all 0.5s ease-in-out 0s;
    transition: all 0.5s ease-in-out 0s;
}
.img-box ul i{
	font-size: 20px;
	letter-spacing: 10px;
}
.img-box ul li{
	width: 30px;
    height: 30px;
    text-align: center;
    border: 1px solid #88C425;
    margin: 2px;
    padding: 5px;
	display: inline-block;
}
.img-box a{
	color:#fff;
}
.img-box:hover:after{
	opacity: 1;
}
.img-box:hover ul{
	opacity: 1;
}
.img-box ul a{
	-webkit-transition: all 0.3s ease-in-out 0s;
	-moz-transition: all 0.3s ease-in-out 0s;
	transition: all 0.3s ease-in-out 0s;
}
.img-box a:hover li{
	border-color: #fff;
	color: #88C425;
}
a{
    color:#88C425;
}
a:hover{
    text-decoration:none;
    color:#519548;
}
i.red{
    color:#BC0213;
}
.goal h3{
	text-align: justify;
	font-family: sans-serif;
	font-size: 25px;
	word-spacing: 2px;
	text-align: center;
}
 .center-block{
  width: 50%;
  margin-top: 20px; 
}
.content p{
 text-align: justify;
 font-size: 16px;
}
.growth{
	margin-top: 100px;
	text-align: center;
	font-size: 25px;
	color:#565656;
	font-family: 'Roboto', arial, helvetica, ;
	font-weight: 300px;
}
.cs{
	opacity: 0.4;
}
.gt{
	font-family: sans-serif;
	font-weight: 300px;
	font-size: 16px;
	color :#ED8A37;
}
</style>
<?php include_once("template2.php");?>
<hr>
 <section>
  <div class="container">
  	<div class="row">
  		<div class="goal">
  			<div class="col-md-12">
  				<h3>“Our Goal is to create safe drivers to reduce the number of accidents on the road”</h3>
  		    </div>
  		    <div class="goal-cont">
  		    	<div class="center-block">
                    <div class="content">
                    	<p>TurtleDrive is an Online driving classes booking platform with using the technology to link all ts functions and provide the customer a seamless awesome experience</p>
                    </div> 
  		    	</div>	
  		    </div>		
  	    </div> 
  	    <div class="growth">
  	    	<div class="growth-title">Our Growth Story</div>
  			<div class="col-sm-3 col-md-4">
  				<img src="../images/gallery/one.png" width="150px" height="150px"><br>
  				<p class="gt"> March 2016<p>

                 <p class="gt">Begin the Journey<p>
  		    </div>
  		    <div class="col-sm-3 col-md-4">
  		    	<img class="cs" src="../images/gallery/cs.png" width="150px" height="150px">
  		    </div>
  		    <div class="col-sm-3 col-md-4">
  		    	<img class="cs" src="../images/gallery/cs.png" width="150px" height="150px">
  		    </div>		
  	    </div>		
    </div> 		
  </div>
 </section>
 <section class="team">
  <div class="container">
    <div class="row">
      <div class="col-md-10 col-md-offset-1">
        <div class="col-lg-12">
         <div class="team1">
          <h6 class="description">Our Team</h6>
          <div class="row pt-md">
            <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 profile">
              <div class="img-box">
                <img src="../images/man.jpg" class="img-responsive">
                <ul class="text-center">
                  <a href="#"><li><i class="fa fa-facebook"></i></li></a>
                  <a href="#"><li><i class="fa fa-twitter"></i></li></a>
                  <a href="#"><li><i class="fa fa-linkedin"></i></li></a>
                </ul>
              </div>
              <h1>Mithun Kumar Muddan</h1>
              <h2>Co-founder & Chief Executive Officer</h2>
              <p>An Entrepreneur, A Change is Within .A tech Guy, Crazy Open Source Contributor,
               He push things beyond limit where he finds his Happyness, GitHub's Greatest Fan, 
               He Says Ruby is Future, Future is Here.For him Startup is life, 
               Four years of experience building successful IT serviced based company in bangalore.</p>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 profile">
              <div class="img-box">
                <img src="../images/man2.jpg" class="img-responsive">
                <ul class="text-center">
                  <a href="#"><li><i class="fa fa-facebook"></i></li></a>
                  <a href="#"><li><i class="fa fa-twitter"></i></li></a>
                  <a href="#"><li><i class="fa fa-linkedin"></i></li></a>
                </ul>
              </div>
              <h1>Deanish M A</h1>
              <h2>Co-founder & Chief Technology Officer</h2>
              <p>Rails 4 Guy, Software Hacker, Open Source Contributor, Gamer, Smiles aLot, Sleeps @ 11pm, Google's Biggest Fan, The Cool Stuff Guy He loves to break things fast and great adapabity.</p>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 profile">
              <div class="img-box">
                <img src="../images/man3.jpg" class="img-responsive">
                <ul class="text-center">
                  <a href="#"><li><i class="fa fa-facebook"></i></li></a>
                  <a href="#"><li><i class="fa fa-twitter"></i></li></a>
                  <a href="#"><li><i class="fa fa-linkedin"></i></li></a>
                </ul>
              </div>
              <h1>Suresh K</h1>
              <h2>Platform Engineer</h2>
              <p>Kool guy headed with 24*7 never ending works,Contributed from early days of TurtleDrive from field trials and ability to solve bigger porblems when comes to code. Ability to work on multiple platform</p>
            </div>
            <div class="col-lg-3 col-md-3 col-sm-4 col-xs-12 profile">
              <div class="img-box">
                <img src="../images/man4.jpg" class="img-responsive">
                <ul class="text-center">
                  <a href="#"><li><i class="fa fa-facebook"></i></li></a>
                  <a href="#"><li><i class="fa fa-twitter"></i></li></a>
                  <a href="#"><li><i class="fa fa-linkedin"></i></li></a>
                </ul>
              </div>
              <h1>Priyadarshan M P</h1>
              <h2>Programmer</h2>
              <p>Tech freak guy and loves to do programming and across any platform Code breaker !!<br>
              #INDIA #ಕನ್ನಡ #Creativity</p>
            </div>
            
            
           
            
         </div>    
           
      </div>
    </div>
  </div>
</section>
   <?php include_once("../template_footer.php");?>