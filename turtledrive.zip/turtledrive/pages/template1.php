 <?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | Turtle Drive</title>
  
  <!-- core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/animate.min.css" rel="stylesheet">
    <link href="../css/prettyPhoto.css" rel="stylesheet">
    <link href="../css/main.css" rel="stylesheet">
    <link href="../css/responsive.css" rel="stylesheet">
     <link href="../css/test.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="../images/favi.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="../images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->
<style type="text/css">
body {
  padding-top: 100px;
  background-color: #fff;
}
.dropdown-menu h4{
  font-size: 12px;
  color: #fff;
}
</style>



<body class="homepage">
        <header id="header">
         <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html"><img src="../images/logo.png" alt="logo"></a>
                </div>
                <div class="collapse navbar-collapse navbar-right">
                 <ul class="nav navbar-nav">
                   <li><a href="../index.php"><i class="fa fa-home"></i>&nbsp Home</a></li> 
                   <li><a href="../training.php"><i class="fa fa-cog"></i>&nbsp Training</a></li>
                   <li><a href="resource.php"><i class="fa fa-eye"></i>&nbspResources</a></li>
                   <li  class="active"><a href="rtoforms.php"><i class="fa fa-road"></i>&nbspRTO Forms</a></li>
                   <li><a href="contact.php"><i class="fa fa-group"></i>&nbspContact Us</a></li> 
                   <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
                      <i class="fa fa-group"></i>&nbspAbout us
                      <i class="fa fa-angle-down"></i>
                    </a> 
                    <ul class="dropdown-menu">
                      <li><a href="team.php"><i class="fa fa-group"></i>&nbsp Team</a></li>
                      <li><a href=""><i class="fa fa-home"></i>&nbsp Company</a></li> 
                      <li><a href=""><i class="fa fa-search"></i>&nbsp We Are Hiring</a></li>
                    </ul>
                  </li>
                  <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
                      <i class="fa fa-lock"></i>&nbsp <?php
if (isset($_SESSION['fullname']))
{
   echo 'logout';
}
else
{
   echo 'Login';
}
?>
                      <i class="fa fa-angle-down"></i>
                    </a> 
                    <ul class="dropdown-menu">
                      <li><h4><i class="glyphicon glyphicon-user"></i><?php
if (isset($_SESSION['fullname']))
{
   echo $_SESSION['fullname'];
}
else
{
   echo 'Not logged in';
}
?></h4></li>
                     <li>
                        <form name="logoutform" method="post" action="../login/session.php" id="logoutform">
                      <input type="hidden" name="form_name" value="logoutform">
                 <button type="submit" class="btn btn-warning" name="logout" value="Logout" id="Logout1"> <?php
if (isset($_SESSION['fullname']))
{
   echo 'LOG OUT';
}
else
{
   echo 'LOG IN';
}
?></button>
                     </form>
                     </li>
                    </ul>
                  </li>
                  
                  
                 </ul>   
                </div>    
            </div><!--/.container-->
 
        </nav><!--/nav-->
    
    </header><!--/header-->
   
  
 </body>
</html>
