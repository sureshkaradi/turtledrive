 <?php include_once("template.php");?>
 <style type="text/css">
.well a{
  color:#fff;
}
.well a:hover, a:focus {
  color: #d43133;
}
.active a {
  color: red;
}

</style>
  <hr>
    <div class="container">
      <div class="row">
         <div class="col-lg-3">
            <form class="well form-horizontal" action=" " method="post"  id="contact_form">
               <fieldset>
                <ul>
                  <li color="#fff"><h5><a href="mandatory.php">road signs</a></h5></li>
                  <li color="#fff"><h5><a href="ror.php">rules of the road</a></h5></li>
                  <li color="#fff"><h5><a href="agelimit.php">Age limit</a></h5></li>
                  <li color="#fff"><h5><a href="alcho.php">alchol limit</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">Tips For Driving Licence</a></h5></li>
                  <li color="#fff"><h5><a href="llr.php">how to get llr</a></h5></li>
                  <li color="#fff"><h5><a href="pdl.php">how to get permnent dl</a></h5></li>
                  <li color="#fff"><h5><a href="idl.php">how to get international dl</a></h5></li>
                  <li class="active"><h5><a href="tint.php">tinted glass</a></h5></li>
                  <li color="#fff"><h5><a href="noc.php">noc</a></h5></li>
                  <li color="#fff"><h5><a href="oop.php">offence of penalties</a></h5></li>
                  <li color="#fff"><h5><a href="dl.php">driving tips</a></h5></li>
                </ul>
               </fieldet>
              </form> 
            </div> 
             <div class="col-lg-9">
              <form class="well form-horizontal">
                <fieldset>
               <div id="services" class="service-item">
                    <div class="col-md-12">
                     <div class="media services-wrap wow fadeInDown">
                      <div class="pull-left">
                            <img class="img-responsive" src="roadsigns/images/14.jpg" width="275px" height="200px">
                        </div>
                         <div class="media-body">
                           <h4 class="media-heading">Tinted glass</h4>
                            <p>
                             Use of dark, black or reflective glasses in vehicles is not permitted as per law. As provided in Rule 100 of Central Motor Vehicle Rules 1989, the glass of windscreen and rear window of motor vehicles should have a visibility of at least 70% and that of side windows a minimum visibility of 50%. The specification of glass should conform to Indian Standards [ IS:2553 - Part 2 - 1992 ]. The front windscreen shall be of laminated safety glass, whose pieces do not fly in the event of a crash and edges would be less jagged than in case of ordinary glass. 
                            </p>
                        </div>
                     </div>
                    </div>
                    </div>    
               </div> 
            </div> 
           </fieldset>
         </form>
       </div> 
    </div> 
     <?php include_once("footer.php");?>   