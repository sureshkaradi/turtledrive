<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form_name'] == 'logoutform')
{
   if (session_id() == "")
   {
      session_start();
   }
   unset($_SESSION['username']);
   unset($_SESSION['fullname']);
   header('Location: ../index.php');
   exit;
}
if (session_id() == "")
{
   session_start();
}
?>
<style type="text/css">
 .row h3{
    text-transform: uppercase;
    font-size: 15px;
    text-align: left;
    font-family: bold;
   }
</style>

<?php include_once("template.php");?>
<hr>
<div class="container">
  <div class="row">
            <div class="col-lg-12">
             <div class="alert alert-success" role="alert" id="success_message"> 
              <div class="row">
                 <div class="col-md-10">
                  <h3> <i class="glyphicon glyphicon-user"> &nbsp </i>WEL COME &nbsp <?php
if (isset($_SESSION['fullname']))
{
   echo $_SESSION['fullname'];
}
else
{
   echo 'Not logged in';
}
?>	</h3>
                 </div>	

                 <div class="col-md-2">
                 	<form name="logoutform" method="post" action="<?php echo basename(__FILE__); ?>" id="logoutform">
                      <input type="hidden" name="form_name" value="logoutform">
                 <button type="submit" class="btn btn-warning" name="logout" value="Logout" id="Logout1">LOG OUT</button>
                     </form>
                 </div>	
              </div>
             </div>   

        </div>	
  </div>  
   <?php include_once("footer.php");?>          


