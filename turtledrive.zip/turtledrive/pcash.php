  <?php

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("projectx", $con);
$ref_no=$_POST['rname'];

$sql= "INSERT INTO booking_confirm (bc_id, ref_no)

 VALUES ('',  '$ref_no')";

 if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }
 
 
mysql_close($con)
?>