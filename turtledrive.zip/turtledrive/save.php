

<?php
 include "storescripts/connect_to_mysql.php";
// The length we want the unique reference number to be  
$unique_ref_length = 8;  
  
// A true/false variable that lets us know if we've  
// found a unique reference number or not  
$unique_ref_found = false;  
  
 
$possible_chars = "23456789BCDFGHJKMNPQRSTVWXYZ";  
  
// Until we find a unique reference, keep generating new ones  
while (!$unique_ref_found) {  
  
    // Start with a blank reference number  
    $unique_ref = "";  
      
    // Set up a counter to keep track of how many characters have   
    // currently been added  
    $i = 0;  
      
    // Add random characters from $possible_chars to $unique_ref   
    // until $unique_ref_length is reached  
    while ($i < $unique_ref_length) {  
      
        // Pick a random character from the $possible_chars list  
        $char = substr($possible_chars, mt_rand(0, strlen($possible_chars)-1), 1);  
          
        $unique_ref .= $char;  
          
        $i++;  
      
    }  
      
    // Our new unique reference number is generated.  
    // Lets check if it exists or not  
    $query = "SELECT `ref_no` FROM `booking_info` 
              WHERE `ref_no`='".$unique_ref."'";  
    $result = mysql_query($query) or die(mysql_error().' '.$query);  
    if (mysql_num_rows($result)==0) {  
      
        // We've found a unique number. Lets set the $unique_ref_found  
        // variable to true and exit the while loop  
        $unique_ref_found = true;  
      
    }  
  
}  
  echo 'your Booking reference number is: '.$unique_ref; 
  ?>


  <?php

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("projectx", $con);
$e=$_POST["email"];

$sql= "INSERT INTO booking_info (b_id, ref_no, school_name, car, s_address, price, service, p_date, p_time, f_name, l_name, dob, gender, email, phone, 
  address, city, zip, state, land_mark,pd,status)

 VALUES ('', '$unique_ref', '$_POST[s_name]', '$_POST[car]', '$_POST[s_address]', '$_POST[price]', '$_POST[ser]', '$_POST[date]', '$_POST[time]', '$_POST[f_name]', '$_POST[l_name]',
  '$_POST[dob]', '$_POST[gender]', '$_POST[email]', '$_POST[phone]', '$_POST[address]', '$_POST[city]', '$_POST[zip]', '$_POST[state]',
  '$_POST[land]','$_POST[pd]', '0')";

 if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }

 mail($e, subject, message);
mysql_close($con)
?>


<?php 
// Check to see the URL variable is set and that it exists in the database

  // Connect to the MySQL database  
    include "storescripts/connect_to_mysql.php"; 
  
  // Use this var to check to see if this ID exists, if yes then get the product 
  // details, if no then exit this script and give message why
  $sql = mysql_query("SELECT * FROM booking_info WHERE ref_no='$unique_ref' LIMIT 1");
  $productCount = mysql_num_rows($sql); // count the output amount
    if ($productCount > 0) {
    // get all the product details
    while($row = mysql_fetch_array($sql)){ 
       $b_id = $row["b_id"];
        
         }
     
  } else {
    echo "That item does not exist.";
      exit();
  }
    

header("location: confirm.php?b_id=$b_id");
mysql_close();
?>
 









 




