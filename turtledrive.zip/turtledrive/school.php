<style type="text/css">
.connect {
  font-size: 50px;
  height: 32px;
  width: 32px;
  margin: 5px;
  border-radius: 50%;
  line-height: 32px;
  text-align:center;
  background: orange;
  color: #c52d2f;
  border: 1px solid red;
  box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-transition: 500ms;
  -moz-transition: 500ms;
  -o-transition: 500ms;
  transition: 500ms;
  float: left;
  margin-right: 25px;
}
.connect img{
  height: 30px;
  width: 30px;
  margin: 0px;
  border-radius: 50%;
  line-height: 30px;
  text-align:center;
  background: #eee;
  color: #c52d2f;
  border: 3px solid #ffffff;
  box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-transition: 500ms;
  -moz-transition: 500ms;
  -o-transition: 500ms;
  transition: 500ms;
  float: left;
  margin-right: 25px;
}
.connect img:hover {
  background:orange;
  color: blue;
  box-shadow: inset 0 0 0 5px red;
  -webkit-box-shadow: inset 0 0 0 1px orange;
  border: 1px solid orange;
}
</style>


<?php
if(isset($_POST['submit'])){
if(preg_match("/[A-Z | a-z]+/", $_POST['name'])){

$name=$_POST['name'];
 $cars = "";
 include "storescripts/connect_to_mysql.php"; 
 $sql = mysql_query("SELECT * FROM cars WHERE category='$name' AND training='Training' AND car_name='Alto'");
  
 
  while($row = mysql_fetch_array($sql)){
    $car_price = $row["car_price"];
    $car_name = $row["car_name"];
    $address = $row["address"];
    $product_name = $row["product_name"];
    $category = $row["category"];
    $c_id = $row["c_id"];
    $per = $row["per"];
    $class = $row["class"];
    $review = $row["review"];
    $training = $row["training"];
    $sn = $row["school_no"];
 $cars .='<div class="team">
                <div class="row clearfix">
                    <div class="col-md-12 col-sm-4"> 
                       <div class="single-profile-top wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
                          <div class="media">
                            <div class="pull-left">
                              <a href="#"><img class="media-object" src="inventory_images/cars/' . $car_name . '.jpg" alt=""></a>
                               <h4>' . $car_name . '(' . $training . ')</h4> 
                            </div>
                             <table width="50%">
                             <tr>
                             <td width="95%"> 
                              <div class="media-body">
                                <a href="schools.php?school_no=' . $sn . '"><h4>' . $product_name . '</h4></a> 
                                  <ul class="social_icons">

                              <li> <div class="connect">
                                <img src="images/p.png" title="petrol">
                                </div></li> 

                               <li> <div class="connect">
                                <img src="images/m.png" title="male Instructor">
                                </div></li> 

                               <li> <div class="connect">
                                <img src="images/s.png" title="power stearing">
                                </div></li>

                                <li> <div class="connect">
                                <img src="images/d2.png" title="Pick & Drop Service Availaible">
                                </div></li>
                             </ul>
                              <p><img src="images/map.png" width="20px" height="20px">' . $address . '</p>
                             <h5>' . $class . '</h5>
                            </div>
                           </td>
                           <td width="5%" class="pull-right" >
                           <div class="media-body">
                              
                             <h2><i class="fa fa-inr"></i>   ' . $car_price . '</h2>

                             <br>
                             <div class="progress">
                               <div class="progress-bar  color2" role="progressbar" aria-valuenow="40"
                               aria-valuemin="0" aria-valuemax="100" style="width: ' . $per . '%">
                                <span class="bar-width">' . $review . '</span>
                              </div>
                             </div> 
                            <h2><li class="btn"><a href="booking.php?c_id=' . $c_id . '">SELECT</a></li></h2>
                         </div>
                         </td>
                        </tr>
                       </table>
                              </div>
                          </div>
                        </div>
                       </div>
                    </div> ';
         }
     
  } else {
    echo "That item does not exist.";
      exit();
  }
    
}
     
else {
    echo "That item does not exist.";
      exit();
   }  
?>





 
   <!DOCTYPE html>
    <html lang="en">

   <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Home | Turtle Drive</title>
   

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/jQuery-ui.min.css" rel="stylesheet">
    <link href="css/jQuery-ui.css" rel="stylesheet">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
     <script src="admin/argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
    <script src="admin/js/application.js" type="text/javascript" charset="utf-8"></script>
     <script src="js/jquery.js"></script>
    <script src="js/jquery-ui.custom.js"></script>
    <script src="js/jQRangeSlider-min.js"></script>
  <script src="//code.jquery.com/jquery-1.10.2.js"></script>
  <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
  <link rel="stylesheet" href="/resources/demos/style.css">


    <!-- Custom CSS -->
    <link href="css/1-col-portfolio.css" rel="stylesheet">

    <script type="text/javascript">
  
  $(function() {
  $('#flat-slider').slider({
  orientation: 'horizontal',
  range:       true,
  values:      [17,67]
});
  </script>
 

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>
 <?php include_once("template1.php");?>
    <hr>
    <br>
   
    <!-- Page Content -->
    <div class="container">
        <div class="row">
          <div class="col-lg-3"> 
                         <form class="well form-horizontal" action="car.php" method="post"  id="contact_form">
              <fieldset>
          <div class="form-group"> 
 
            
          <div class="col-md-12 selectContainer">
           <h5> LOCATION</h5>
          <div class="input-group">

          <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"></i></span>
          <select name="name" class="form-control selectpicker" >
          <option><?php echo  stripslashes($name);  ?></option>
             <?php
include('storescripts/connect_to_mysql.php');// connection to database 
$q=mysql_query("select * from products ");
while($n=mysql_fetch_array($q)){
echo "<option value=".$n['category'].">".$n['category']."</option>";
}
?>
      
           </select>
           </div>
           </div>
           </div>
           <div class="form-group"> 
 
 
          <div class="col-md-12 selectContainer">
           <h5> VEHICLE GROUP</h5> 
          <div class="input-group">
          <span class="input-group-addon"><i class="fa fa-cog"></i></span>
          <select name="car" id="filter" class="form-control selectpicker" >
           <?php
                          include('storescripts/connect_to_mysql.php');// connection to database 
                          $q=mysql_query("select * from car_names ");
                           while($n=mysql_fetch_array($q)){
                           echo "<option value=".$n['car_name'].">".$n['car_name']."</option>";
                             }
                           ?>
      
           </select>
           </div>
           </div>
           </div>
           <div class="form-group"> 
 
 
          <div class="col-md-12 selectContainer">
           <h5> CLASS</h5> 
          <div class="input-group">
          <span class="input-group-addon"><i class="fa fa-inr"></i></span>
          <select name="trai" id="filter" class="form-control selectpicker" >
            <option value="Training">Training</option>
            <option value="Training + DL">Training + DL</option>
           </select>
           </div>
           </div>
           </div>

        <div class="form-group">
         <div class="col-md-12 selectContainer">
          <div class="input-group">
           <br>
           <h5>VEHICLE TYPE </h5>

               <div>
                <input type="radio" name="filter" value="" id="filter" value="Santro">&nbsp &nbsp Power Stearing<br/>
                <input type="radio" name="filter" value="" id="filter" value="Alto">&nbsp &nbsp Manuval Stearing
                
               </div>

           </div>
           <br>
           </div>

             <div class="form-group">
                 <label class="col-md-4 control-label"></label>
                  <div class="col-md-4">
                 <button type="submit"  name="submit" class="btn btn-warning" >SEARCH <span class="glyphicon glyphicon-send"></span></button>
                 </div>
            </div>
        </fieldset>
       </form>
          </div>
          <div class="col-md-8">
             <?php echo $cars; ?>  
          </div>
        </div>
    </div>
  </br>
   <?php include_once("template_footer.php");?> 
