<?php
	include('../storescripts/connect_to_mysql.php');
	$roomid = $_POST['roomid'];
	$status=$_POST['status'];
	mysql_query("UPDATE booking_info SET status='$status' WHERE b_id='$roomid' ");
	
?>