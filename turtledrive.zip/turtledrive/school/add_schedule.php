<?php

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("projectx", $con);


$sql= "INSERT INTO schedule (sc_id, time, date, student_name, car_select, instructot, class, pay, remarks, added, school_name, contact)
VALUES ('', '$_POST[time]',  '$_POST[date]', '$_POST[f_name]', '$_POST[car]', '$_POST[instr]', 
  '$_POST[class]', '$_POST[price]', '', '', '$_POST[s_name]', '$_POST[phone]')";

 if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }

 header("location: schedule.php");
mysql_close($con)
?>

