<?php
	include('../storescripts/connect_to_mysql.php');
	$roomid = $_POST['roomid'];
	$status=$_POST['status'];
	mysql_query("UPDATE schedule SET remarks='$status' WHERE sc_id='$roomid' ");
	header("location: schedule.php");
?>