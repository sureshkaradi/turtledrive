  <?php

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("projectx", $con);


$sql= "INSERT INTO instructor ( insrutor_name, school_name, contact_number, e_contact_no, address)
VALUES ('$_POST[iname]',  '$_POST[sname]', '$_POST[cno]', '$_POST[ecno]', '$_POST[sadd]')";

 if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }

 header("location: instructor.php");
mysql_close($con)
?>