<?php
	include('../storescripts/connect_to_mysql.php');
	$roomid = $_POST['roomid'];
	$status=$_POST['status'];
	mysql_query("UPDATE booking_info SET status='$status' WHERE b_id='$roomid' ");
	
?>

<?php echo $roomid ?>

<?php 
   include('../storescripts/connect_to_mysql.php');
                     $result = mysql_query("SELECT * FROM booking_info WHERE b_id = '$roomid'" );
                     while($row = mysql_fetch_array($result))
                        {
                          echo $b_id=$row['b_id'];
                        }
                       header("location: alertclass.php?b_id=$b_id");

?>
