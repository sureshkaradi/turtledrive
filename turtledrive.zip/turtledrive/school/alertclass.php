
<style type="text/css">
<!--
.ed{
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
margin-bottom: 4px;
}
button, input, select, textarea {
    margin: 0;
    font-family: inherit;
    font-size: 100%;
    width: 100%;
}    
#button1{
text-align:center;
font-family:Arial, Helvetica, sans-serif;
border-style:solid;
border-width:thin;
border-color:#00CCFF;
padding:5px;
background-color:#00CCFF;
height: 34px;
}
.nav-side-menu {
 overflow: auto;
  font-family: verdana;
  font-size: 12px;
  font-weight: 200;
  background-color: #fff;
  width: 100%;
  height: auto;
  color: #ffffff;
}
.test1 {
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    font-size: 14px;
    line-height: 1.428571429;
    color: #333;
    background-image: url("img/bg.jpg");
    margin-top: 3%;
}
</style>

<?php include_once("template.php");?>

<?php 
$b_id=$_GET["b_id"]; 

?>

 <?php
                     include('../storescripts/connect_to_mysql.php');
                     $result = mysql_query("SELECT * FROM booking_info WHERE b_id = '$b_id'" );
                     while($row = mysql_fetch_array($result))
                        {
                          $status=$row['status'];
                          $f_name=$row['f_name'];
                          $phone=$row['phone'];
                          $address=$row['address'];
                          $school_name=$row['school_name'];
                          $car =$row['car'];
                          $price =$row['price'];
                          $p_d=$row['p_date'];
                          $p_t=$row['p_time'];
                        }

                     ?>
<body  class="test1">                    
<div class="container">
      <div class="row">
        
             <div class="col-lg-12">
               <div class="nav-side-menu">
                <div class="brand">add class</div>
                  <table class="responstable" width="100%"  align="center" border="1px">
                     <thead>
                     <tr>
                        <th  style="border-left: 1px solid #C1DAD7"> Student Name </th>
                        <th width="10%"> Phone </th>
                        <th width="10%"> Class </th>
                        <th width="10%">P_Date</th>
                        <th width="10%">p_Time</th>
                        <th width="10%">Instructor_Name</th>
                        <th width="10%">Instructor_Gender</th>
                        <th width="10%">Action</th>
                     </tr>
                     <tr>
                      <td><?php echo $f_name;?></td>
                      <td><?php echo $phone;?> </td>
                      <td>Previous class :<?php echo $status;?> </br></br>
                         <form action="alert.php" method="post">
                  <input type="hidden" name="roomid" value="<?php echo $b_id=$_GET['b_id'] ?>">
                 <select name="status" class="ed">
                <option>Select Class</option>
         <?php
include('../storescripts/connect_to_mysql.php');// connection to database 
$q=mysql_query("select * from classes ");
while($n=mysql_fetch_array($q)){
echo "<option value=".$n['class'].">".$n['class']."</option>";
}
?>

             </select>
            <br>
            <input type="submit" value="update" id="button1"><br>
           </form>
                      </td>
                     <form action="add_schedule.php" method="post"> 
                      <td>
                        <input type="hidden" name="class" value="<?php echo $status;?>">
                        <input type="hidden" name="f_name" value="<?php echo $f_name;?>">
                        <input type="hidden" name="phone" value="<?php echo $phone;?>">
                        <input type="hidden" name="s_name" value="<?php echo $school_name;?>">
                        <input type="hidden" name="car" value="<?php echo $car;?>">
                        <input type="hidden" name="price" value="<?php echo $price;?>">
                        <input type="text" name="date" id="date" class="ed" placeholder="date">
                        
                      </td>
                      <td>
                        <input type="text" name="time" id="date" class="ed" placeholder="time 12:00pm">
                         
                      </td>
                      <td>
                      
                        <input type="text" name="instr" id="date" class="ed" placeholder="Instructor name">
                      </td>
                      <td>
                        <select name="status" class="ed">
                        <option>Male</option>
                        <option>FeMale</option>
                     </select>
                      </td>
                      <td>
                         <input type="submit" value="update" id="button1">
                      </td>
                    </form>  
                 </tr>
                  </thead>
                  <tbody>
                </table>  
               </div> 
             </div> 
          </div> 
      </div>   


        <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
     <script src="js/bootstrap.min.js"></script>
      <script src="js/form.js"></script>

    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js"></script>
    `<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>

  <script>
  $(function() {
    var dates = $( "#date" ).datepicker({
      defaultDate: "+1w",
      changeMonth: true,
      numberOfMonths: 1,
      dateFormat: 'dd-mm-yy',
      onSelect: function( selectedDate ) {
        var option = this.id == "date" ? "minDate" : "maxDate",
          instance = $( this ).data( "datepicker" ),
          date = $.datepicker.parseDate(
            instance.settings.dateFormat ||
            $.datepicker._defaults.dateFormat,
            selectedDate, instance.settings );
        dates.not( this ).datepicker( "option", option, date );
      }
    });
  });
  </script>
</body> 