

<?php include_once("template.php");?>

<style type="text/css">

.test1 {

    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;

    font-size: 14px;

    line-height: 1.428571429;

    color: #333;

    background-image: url("img/bg.jpg");

    margin-top: 3%;

}
.btn-primary1 {
    color: #fff;
    background-color: #428bca;
    border-color: #357ebd;
    font-size: 200%;
    margin-left: 0;
}
.car{
  background-color: transparent;
}

</style>

<body class="test1">

 <div class="container">

    <div class="row">

       <div class="col-lg-12">

          

          </div>

          <div class="col-lg-12">

          <h3><a href="newcar.php">ADD NEW CAR</a></h3>

<?php
include('../storescripts/connect_to_mysql.php');// connection to database  booking.php?c_id=' . $c_id . '

$q=mysql_query("select * from cars WHERE school_no = '$sn' ");

while($n=mysql_fetch_array($q)){

   $c_id = $n['c_id'];

   $car_name = $n['car_name'];

   $car_price = $n['car_price'];

   $class = $n['class'];

echo '<div class = "col-sm-6 col-md-3">
       <div class="car">
      <h4>'.$car_name.'  <i class = "fa fa-inr" ></i>  '.$car_price.'</h4>

      <a href="#" class = "thumbnail">

         <img class="media-object" src="../inventory_images/cars/' . $car_name . '.jpg" alt="' . $car_name . '">

      </a>
        <h4>No Of Classes:'. $class.'</h4>
      <a href="editcar.php?c_id='.$c_id.'"><button class="btn btn-primary">EDIT</button></a>       <a href="cardelete.php?c_id='.$c_id.' "><button class="btn btn-danger">DELETE</button></a>

    </div>
   </div>';

}



?>



      </div>

    </div>

  </div>  

</body>