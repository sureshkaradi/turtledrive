<?php

// This is a sample code in case you wish to check the username from a mysql db table
include('../storescripts/connect_to_mysql.php');
if($_GET['c_id'])
{
$c_id=$_GET['c_id'];
 mysql_query("DELETE from cars where c_id='$c_id'");
 header("location: car.php"); 
}
?>