<style type="text/css">
.nav-side-menu {
 overflow: auto;
  font-family: verdana;
  font-size: 12px;
  font-weight: 200;
  background-color: #fff;
  
  width: 100%;
  height: 90%;
  color: #ffffff;
}
.test1 {
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    font-size: 14px;
    line-height: 1.428571429;
    color: #333;
    background-image: url("img/bg.jpg");
    margin-top: 3%;
}

</style>

<?php include_once("searchform.php");?>
<?php include_once("template.php");?>
<body class="test1">
 <div class="container">
    <div class="row">
    	 <div class="col-lg-12">
               <div class="nav-side-menu ">
                <div class="brand">
                  <form action="search.php" method="post">
                   
                   <div id="custom-search-input">
                     <div class="input-group col-md-7">
                    <input type="text" name="filter" value="" id="filter" placeholder="search" />
                     <span class="input-group-btn">
                        <button class="btn btn-info btn-lg" type="button" value="submit">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>

                    </span>
                      &nbsp&nbsp  &nbsp&nbsp TODAY JOBS   
                </div>
                     
            </div>
           
         </form>
                     
      </div>
                <table class="responstable" width="100%"  align="center" border="1px">
                     <thead>
                     <tr>
                        <th  style="border-left: 1px solid #C1DAD7"> Date </th>
                        <th width="10%"> Time </th>
                        <th width="10%"> Name </th>
                        <th width="10%"> Contact </th>
                        <th width="10%"> Instructor </th>
                        <th width="10%"> Car </th>
                        <th width="10%"> Amount </th>
                        <th width="10%"> Class </th>
                        <th width="10%"> Remark </th>
                     </tr>
                  </thead>
                  <tbody>
                  <?php
                     $d = date("d-m-Y");
                     include('../storescripts/connect_to_mysql.php');
                     $result = mysql_query("SELECT * FROM schedule WHERE school_name = '$name' AND date = '$d' " );
                     while($row = mysql_fetch_array($result))
                        {
                           echo '<tr class="record" width="100%">';
                           echo '<td>'.$row['date'].'</td>';
                           echo '<td><div>'.$row['time'].'</div></td>';
                          
                           echo '<td><div>'.$row['student_name'].'</div></td>';
                           echo '<td><div>'.$row['contact'].'</div></td>';
                           echo '<td><div>'.$row['instructot'].'</div></td>';
                           echo '<td><div>'.$row['car_select'].'</div></td>';
                           echo '<td><div>'.$row['pay'].'</div></td>';
                           echo '<td><div>'.$row['class'].'</div></td>';
                           echo '<td><div>'.$row['remarks'].'</div></td>';            
                        }

                     ?> 
                  </tbody>
               </table>
            </div> 
    </div>
</div>
</div>
</body>
        <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
     <script src="js/bootstrap.min.js"></script>
      <script src="js/form.js"></script>

    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js"></script>
    `<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>

  <script>
  $(function() {
    var dates = $( "#date" ).datepicker({
      defaultDate: "+1w",
      changeMonth: true,
      numberOfMonths: 1,
      dateFormat: 'dd-mm-yy',
      onSelect: function( selectedDate ) {
        var option = this.id == "date" ? "minDate" : "maxDate",
          instance = $( this ).data( "datepicker" ),
          date = $.datepicker.parseDate(
            instance.settings.dateFormat ||
            $.datepicker._defaults.dateFormat,
            selectedDate, instance.settings );
        dates.not( this ).datepicker( "option", option, date );
      }
    });
  });
  </script>