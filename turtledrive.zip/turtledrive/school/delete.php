<?php

// This is a sample code in case you wish to check the username from a mysql db table
include('../storescripts/connect_to_mysql.php');
if($_GET['sc_id'])
{
$sc_id=$_GET['sc_id'];
 mysql_query("DELETE from schedule where sc_id='$sc_id'");
 header("location: schedule.php"); 
}
?>