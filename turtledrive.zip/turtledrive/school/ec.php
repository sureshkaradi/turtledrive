<?php 
 $c_id=$_GET['c_id'] 
 ?>

<?php
	include('../storescripts/connect_to_mysql.php');
	$roomid = $_POST['roomid'];
	$t=$_POST['trai'];
	$p=$_POST['price'];
	$c=$_POST['sclass'];
	mysql_query("UPDATE cars SET car_price='$p', class='$c', training='$t' WHERE c_id='$c_id' ");
	header("location: car.php");
	
?>
