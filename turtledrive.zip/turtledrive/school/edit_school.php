<?php include_once("template.php");?>

<?php
  include "../storescripts/connect_to_mysql.php"; 
 $query = "SELECT `product_name` FROM `products` 
              WHERE `product_name`='".$name."'";  
    $result = mysql_query($query) or die(mysql_error().' '.$query);  
    if (mysql_num_rows($result)==1) {  
      
        // We've found a unique number. Lets set the $unique_ref_found  
        // variable to true and exit the while loop  
       echo ' your has already School Register';  
      
    }  
  else{

    echo 'Register your School'; 
  }  
  
  ?>
<style type="text/css">
 .test1 {
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    font-size: 14px;
    line-height: 1.428571429;
    color: #333;
    background-image: url("img/bg.jpg");
    margin-top: 3%;
}
.nav-side-menu {
  overflow: auto;
  font-family: verdana;
  font-size: 12px;
  font-weight: 200;
  background-color: #fff;
  
  width: 100%;
  height: relative;
  color: #e1ffff;
  box-shadow: inset 0 0 10px #000000;
}
</style>
<body class="test1">
 <div class="container">
    <div class="row">
    	 <div class="col-lg-12">
            
          </div>
          <div class="col-lg-12">
 
        

<!-- Form Name -->
<div class="nav-side-menu">
 <div class="brand">EDIT SCHOOL DETAILS</div>
  <form action="eschool.php" method="post"> 
  <table width="100%">
    <tr>
     <td width="20%" align="center"><i class="fa fa-home"></i></td>
    <td width="30%" align="left"><h5>School Name:</h5></td>
    <td width="50" align="left"><h5><?php echo $name; ?></h5>
    <input type="hidden" name="sname" value="<?php echo $name;?> "></td>
    </tr>
    <tr>
    <td width="20%" align="center"><h5><i class="fa fa-map-marker"></h5></i></td>
    <td width="30%" align="left"><h5>Address:</h5></td>
    <td width="50" align="left"> <input class="form-control" name="Add" type="textarea" id="add"></td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-envelop"></h5></i></td>
    <td width="30%" align="left"> <h5> Details: </h5></td>
    <td width="50" align="left">
    <input class="form-control" name="Details" type="textarea" id="details" row="5"></td>
    </tr>
    <tr>
     <td width="20%" align="center"> <h5> <i class="fa fa-phone"></h5></i></td>
    <td width="30%" align="left"> <h5> Contact Details: </h5></td>
    <td width="50" align="left"> <h5> <input class="form-control" name="contact" type="textarea" id="adetails"></td>
    </tr>
    <tr>
     <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Area: </h5></td>
    <td width="50" align="left"> <input class="form-control" name="area" type="text" id="area"></td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Established: </h5></td>
    <td width="50" align="left"> <input class="form-control" name="e" type="text" id="area"></td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Jobs Done: </h5></td>
    <td width="50" align="left"> <input class="form-control" name="j" type="text" id="area"></td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Pick $ Drop Service Charges: </h5></td>
    <td width="50" align="left"> <input class="form-control" name="pds" type="text" id="area"></td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Total Classes: </h5></td>
    <td width="50" align="left"> <input class="form-control" name="tc" type="text" id="area"></td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Last Edit: </h5></td>
    <td width="50" align="left"><h5></h5> 
    <input type="hidden" name="date" value="<?php echo date("d/m/y");?> "></td>
    </tr>
    <td></td>
    <td></td>
    <td><input type="submit" value="Save" id="button1"></td>>
    </tr>
  </table>
  </form> 
</div>

  
   
        



         
          </div>	
     </div>
  </div>          
  </body>