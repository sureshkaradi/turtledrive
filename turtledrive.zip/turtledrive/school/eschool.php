<?php include_once("template.php");?>



 
?>

<?php
 include "../storescripts/connect_to_mysql.php";
// The length we want the unique reference number to be  
$unique_ref_length = 6;  
  
// A true/false variable that lets us know if we've  
// found a unique reference number or not  
$unique_ref_found = false;  
  
 
$possible_chars = "23456789";  
  
// Until we find a unique reference, keep generating new ones  
while (!$unique_ref_found) {  
  
    // Start with a blank reference number  
    $unique_ref = "";  
      
    // Set up a counter to keep track of how many characters have   
    // currently been added  
    $i = 0;  
      
    // Add random characters from $possible_chars to $unique_ref   
    // until $unique_ref_length is reached  
    while ($i < $unique_ref_length) {  
      
        // Pick a random character from the $possible_chars list  
        $char = substr($possible_chars, mt_rand(0, strlen($possible_chars)-1), 1);  
          
        $unique_ref .= $char;  
          
        $i++;  
      
    }  
      
    // Our new unique reference number is generated.  
    // Lets check if it exists or not  
    $query = "SELECT `school_no` FROM `products` 
              WHERE `school_no`='".$unique_ref."'";  
    $result = mysql_query($query) or die(mysql_error().' '.$query);  
    if (mysql_num_rows($result)==0) {  
      
        // We've found a unique number. Lets set the $unique_ref_found  
        // variable to true and exit the while loop  
        $unique_ref_found = true;  
      
    }  
  
}  
  echo 'your Booking reference number is: '.$unique_ref; 
  ?>

  <?php

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("projectx", $con);


$sql= "INSERT INTO products (id, school_no, product_name, details, contact_details, category, date_added, adderss, class_trail, since, 	jobs, p_d_service)
VALUES ('', '$unique_ref', '$_POST[sname]',  '$_POST[Details]', '$_POST[contact]', '$_POST[area]', '$_POST[date]',
  '$_POST[Add]', '$_POST[tc]' , 
  '$_POST[e]', '$_POST[j]', '$_POST[pds]')";

 if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }

 header("location: school.php");
mysql_close($con)
?>