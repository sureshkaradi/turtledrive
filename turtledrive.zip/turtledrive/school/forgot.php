<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form_name'] == 'forgotpasswordform')
{
   $email = isset($_POST['email']) ? addslashes($_POST['email']) : '';
   $success_page = '';
   $error_page = basename(__FILE__);
   $mysql_server = 'localhost';
   $mysql_username = 'root';
   $mysql_password = '';
   $mysql_database = 'projectx';
   $mysql_table = 'school_user';
   $db = mysqli_connect($mysql_server, $mysql_username, $mysql_password);
   if (!$db)
   {
      die('Failed to connect to database server!<br>'.mysqli_error($db));
   }
   mysqli_select_db($db, $mysql_database) or die('Failed to select database<br>'.mysqli_error($db));
   $sql = "SELECT * FROM ".$mysql_table." WHERE email = '".mysqli_real_escape_string($db, $email)."'";
   $result = mysqli_query($db, $sql);
   if ($data = mysqli_fetch_array($result))
   {
      $alphanum = array('a','b','c','d','e','f','g','h','i','j','k','m','n','o','p','q','r','s','t','u','v','x','y','z','A','B','C','D','E','F','G','H','I','J','K','M','N','P','Q','R','S','T','U','V','W','X','Y','Z','2','3','4','5','6','7','8','9');
      $chars = sizeof($alphanum);
      $a = time();
      mt_srand($a);
      for ($i=0; $i < 6; $i++)
      {
         $randnum = intval(mt_rand(0,55));
         $newpassword .= $alphanum[$randnum];
      }
      $crypt_pass = md5($newpassword);
      $sql = "UPDATE `".$mysql_table."` SET `password` = '$crypt_pass' WHERE `email` = '$email'";
      mysqli_query($db, $sql);
      $mailto = $_POST['email'];
      $subject = 'New password';
      $message = 'Your new password for http://www.turtledrive.com/ is:';
      $message .= $newpassword;
      $header  = "From: pdarshan14992@turtledrive.com"."\r\n";
      $header .= "Reply-To: support@turtledrive.com"."\r\n";
      $header .= "MIME-Version: 1.0"."\r\n";
      $header .= "Content-Type: text/plain; charset=utf-8"."\r\n";
      $header .= "Content-Transfer-Encoding: 8bit"."\r\n";
      $header .= "X-Mailer: PHP v".phpversion();
      mail($mailto, $subject, $message, $header);
      header('Location: '.$success_page);
   }
   else
   {
      header('Location: '.$error_page);
   }
   mysqli_close($db);
   exit;
}
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>forgot</title>
<meta name="generator" content="WYSIWYG Web Builder 10 Trial Version - http://www.wysiwygwebbuilder.com">
<link href="Untitled1.css" rel="stylesheet">
<link href="forgot1.css" rel="stylesheet">
</head>
<body>
<a href="http://www.wysiwygwebbuilder.com" target="_blank"><img src="images/builtwithwwb10.png" alt="WYSIWYG Web Builder" style="position:absolute;left:441px;top:967px;border-width:0;z-index:250"></a>
<div id="wb_PasswordRecovery1" style="position:absolute;left:271px;top:140px;width:392px;height:109px;text-align:right;z-index:1;">
<form name="forgotpasswordform" method="post" action="<?php echo basename(__FILE__); ?>" id="forgotpasswordform">
<input type="hidden" name="form_name" value="forgotpasswordform">
<table id="PasswordRecovery1">
<tr>
   <td class="PasswordRecovery1_header" colspan="2" style="height:20px;">Forgot your password?</td>
</tr>
<tr>
   <td style="height:20px;width:158px">Email:</td>
   <td style="text-align:left"><input class="PasswordRecovery1_input" name="email" type="text" id="email"></td>
</tr>
<tr>
   <td>&nbsp;</td><td style="text-align:left;vertical-align:bottom"><input class="PasswordRecovery1_button" type="submit" name="submit" value="Submit" id="submit"></td>
</tr>
</table>
</form>
</div>
</body>
</html>