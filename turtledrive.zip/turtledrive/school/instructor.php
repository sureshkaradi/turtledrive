
<?php include_once("template.php");?>
                            <?php  
 
  include "../storescripts/connect_to_mysql.php";
  $sql = mysql_query("SELECT * FROM products WHERE product_name = '$name'" );
 
    if($sql === FALSE) { 
    die(mysql_error()); // TODO: better error handling
}
    // get all the product details
    while($row = mysql_fetch_array($sql)){
       $id = $row["id"];
       $ca = $row["category"];
       $product_name = $row["product_name"];

  } 
?>
<hr>
 <div class="container">
    <div class="row">
    	 <div class="col-lg-12">
             	
          </div>
          <div class="col-lg-12">
             <h3><a href="addins.php">ADD NEW INSTRUCTOR</a></h3>
                <table class="responstable" width="100%"  align="center" border="1px">
                     <thead>
                     <tr>
                        <th></th>
                        <th width="10%"> Name </th>
                        <th width="10%"> Contact No </th>
                        <th width="10%"> Emergency Contact No </th>
                        <th width="10%"> Address </th>
                     </tr>
                  </thead>
                  <tbody>
                    <tr>
                  <?php
                     include('../storescripts/connect_to_mysql.php');
                     $result = mysql_query("SELECT * FROM instructor WHERE school_name = '$product_name'" );
                     while($row = mysql_fetch_array($result))
                        {
                        
                           echo '<td><img src="img/ins.jpg" width="100px" height="100px"></td>' ;
                           echo '<td style="border-left: 1px solid #C1DAD7;">'.$row['insrutor_name'].'</td>';
                           echo '<td><div align="right">'.$row['contact_number'].'</div></td>';
                          
                           echo '<td><div align="right">'.$row['e_contact_no'].'</div></td>';
                           echo '<td><div align="right">'.$row['address'].'</div></td>';
                          

                        }

                     ?> 
                     </tr>
                  </tbody>
               </table>
              
            </div> 
    </div> 