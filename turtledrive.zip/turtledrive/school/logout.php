<style type="text/css">
   .row h3{
    text-transform: uppercase;
    font-size: 15px;
    text-align: left;
    font-family: bold;
    color: orange;
   }
</style>

<div class="container">
  <div class="row">
            <div class="col-lg-12">
             <div class="alert alert-success" role="alert" id="success_message"> 
              <div class="row">
                 <div class="col-md-9">
                  <h3> <i class="glyphicon glyphicon-user"> &nbsp </i>WEL COME &nbsp <?php
if (isset($_SESSION['fullname']))
{
   echo $_SESSION['fullname'];
}
else
{
   echo 'Not logged in';
}
?>  </h3>
                 </div> 
                 <div class="col-md-2">
                    <form name="logoutform" method="post" action="session.php" id="logoutform">
                      <input type="hidden" name="form_name" value="logoutform">
                 <button type="submit" class="btn btn-warning" name="logout" value="Logout" id="Logout1"> <?php
if (isset($_SESSION['fullname']))
{
   echo 'LOG OUT';
}
else
{
   echo 'LOG IN';
}
?></button>
                     </form>
                 </div> 
              </div>
             </div>   

        </div>  
  </div>        