<style type="text/css">

form_main {
    width: 100%;
}
.form_main h4 {
    font-family: roboto;
    font-size: 20px;
    font-weight: 300;
    margin-bottom: 15px;
    margin-top: 20px;
    text-transform: uppercase;
}
.heading {
    border-bottom: 1px solid #fcab0e;
    padding-bottom: 9px;
    position: relative;
}
.heading span {
    background: #9e6600 none repeat scroll 0 0;
    bottom: -2px;
    height: 3px;
    left: 0;
    position: absolute;
    width: 75px;
}   
.form {
    border-radius: 7px;
    padding: 6px;
}
.txt[type="text"] {
    border: 1px solid #ccc;
    margin: 10px 0;
    padding: 10px 0 10px 5px;
    width: 100%;
}
.txt_3[type="text"] {
    margin: 10px 0 0;
    padding: 10px 0 10px 5px;
    width: 100%;
}
.txt2[type="submit"] {
    background: #242424 none repeat scroll 0 0;
    border: 1px solid #4f5c04;
    border-radius: 25px;
    color: #fff;
    font-size: 16px;
    font-style: normal;
    line-height: 35px;
    margin: 10px 0;
    padding: 0;
    text-transform: uppercase;
    width: 30%;
}
.txt2:hover {
    background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
    color: #5793ef;
    transition: all 0.5s ease 0s;
}
.carimage{
  height: 50%;
  width: 50%;
  margin-top: 10%;
  margin-left: 25%;
background-color: rgba(138, 109, 59, 0.62);
border-radius: 50%;
text-align: center;
}

</style>


<?php include_once("template.php");?>
<body class="test">
<div class="container">
    <div class="row">
       <div class="col-lg-12">
                                  
                          <?php  
 
  include "../storescripts/connect_to_mysql.php";
  $sql = mysql_query("SELECT * FROM products WHERE school_no = '$sn'" );
 
    if($sql === FALSE) { 
    die(mysql_error()); // TODO: better error handling
}
    // get all the product details
    while($row = mysql_fetch_array($sql)){
       $id = $row["id"];
       $ca = $row["category"];
       $product_name = $row["product_name"];
       $detail = $row["details"];
       $cd = $row["contact_details"];
       $ad = $row["adderss"];
       $dod = $row["date_added"];

  } 
?>
          </div>
           <div class="col-lg-6 col-sm-6 col-md-6">
              <div class="form_main">
                
                <h4 class="heading"><strong>ADD CAR</strong><span></span></h4>
                <div class="form">
                <form action="es.php" method="post" id="contactFrm" name="contactFrm">
                  <input type="hidden" name="sname" value="<?php echo $product_name;?>  ">
                  <input type="hidden" name="sadd" value="<?php echo $ad;?> ">
                  <input type="hidden" name="location" value="<?php echo $ca;?> ">
                        <input type="hidden" name="sn" value="<?php echo $sn;?> ">  
                  <select name="cname" class="form-control txt">
                        <?php
                          include('../storescripts/connect_to_mysql.php');// connection to database 
                          $q=mysql_query("select * from car_names ");
                           while($n=mysql_fetch_array($q)){
                           echo "<option value=".$n['car_name'].">".$n['car_name']."</option>";
                             }
                           ?>
                  </select>
                </br>
                   <select name="trai" class="form-control txt" >
            
                   <option value="Training">Training</option>
                   <option value="Training + DL">Training + DL</option>
                  </select>
                  </br>
                    <input type="text" required="" placeholder="Enter Car Price" value="" name="price" class="form-control txt"></br>
                    <input type="text" required="" placeholder="classes " value="" name="sclass" class="form-control txt"></br>
                     <input type="submit" value="submit" name="submit" class="txt2">
                </form>
            </div>
          </div>
        </div>
       <div class="col-lg-6 col-sm-6 col-md-6">
          <div class="carimage">
             <img src="img/car.png">
          </div> 
       </div>
     </div>
 </div>         
</body>
