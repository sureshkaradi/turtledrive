
 <style type="text/css">
.test1 {
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    font-size: 14px;
    line-height: 1.428571429;
    color: #333;
    background-image: url("img/bg.jpg");
    margin-top: 3%;
}
.nav-side-menu {
 overflow: auto;
  font-family: verdana;
  font-size: 12px;
  font-weight: 200;
  background-color: #fff;
  
  width: 100%;
  height: 90%;
  color: #ffffff;
}


</style>

<?php include_once("template.php");?> 
<?php include_once("searchform.php");?>
<body class="test1">
<div class="container">
      <div class="col-lg-12">
               <div class="nav-side-menu ">
                <div class="brand">
                  <form action="search.php" method="post">
                   
                   <div id="custom-search-input">
                     <div class="input-group col-md-7">
                    <input type="text" name="filter" value="" id="filter" placeholder="Search" />
                     <span class="input-group-btn">
                        <button class="btn btn-info btn-lg" type="button" value="submit">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>

                    </span>
                      &nbsp&nbsp  &nbsp&nbsp Bookings   
                </div>
                     
            </div>
           
         </form>
                     
      </div>
                <table class="responstable" width="100%"  align="center" border="1px">
                     <thead>
                     <tr>
                        <th widt="5%">Booking_ID</th>
                        <th width="15%"> Name </th>
                        <th width="15%"> Phone </th>
                        <th width="15%"> Email </th>
                        <th width="15%"> Address </th>
                        <th width="5%"> Car </th>
                        <th width="10%"> P_Time </th>
                        <th width="10%"> p_date </th>
                        <th width="5%"> Amount </th>
                        <th width="5%"> Action </th>
                     </tr>
                  </thead>
                  <tbody>
                  <?php
                     include('../storescripts/connect_to_mysql.php');
                     $result = mysql_query("SELECT * FROM booking_info WHERE school_name = '$name'" );
                     while($row = mysql_fetch_array($result))
                        {
                           echo '<tr class="record" width="100%">';
                           echo '<td>'.$row['ref_no'].'</td>';
                           echo '<td><div>'.$row['f_name'].'</div></td>';
                          
                           echo '<td><div>'.$row['phone'].'</div></td>';
                           echo '<td><div>'.$row['email'].'</div></td>';
                           echo '<td><div>'.$row['address'].'</div></td>';
                           echo '<td><div>'.$row['car'].'</div></td>';
                           echo '<td><div>'.$row['p_time'].'</div></td>';
                           echo '<td><div>'.$row['p_date'].'</div></td>';
                           echo '<td><div>'.$row['price'].'</div></td>';
                           echo '<td><div><a rel="facebox" href="alertclass.php?b_id='.$row['b_id'].'">Add Class</a> 
                            </div></td>';

                        }

                     ?> 
                  </tbody>
               </table>
              
            </div> 
    </div>  
  </div>
  </body>