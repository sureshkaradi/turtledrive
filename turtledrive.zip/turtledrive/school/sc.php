<?php
	include('../storescripts/connect_to_mysql.php');
	$roomid = $_POST['roomid'];
	$status=$_POST['status'];
	$date=$_POST['date'];
	$time=$_POST['time'];
	$instr=$_POST['instr'];
	mysql_query("UPDATE schedule SET class='$status', date='$date', time='$time', instructot='$instr' WHERE sc_id='$roomid' ");
	header("location: schedule.php");
	
?>

