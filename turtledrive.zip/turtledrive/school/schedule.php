
 <style type="text/css">
.well a{
  color:#fff;
}
.well a:hover, a:focus {
  color: #d43133;
}
.active a{
  color: red;
}
.responstable{
    width:100%;
}
.nav-side-menu {
 overflow: auto;
  font-family: verdana;
  font-size: 12px;
  font-weight: 200;
  background-color: #fff;
  width: 100%;
  height: 90%;
  color: #ffffff;
}
.test1 {
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    font-size: 14px;
    line-height: 1.428571429;
    color: #333;
    background-image: url("img/bg.jpg");
    margin-top: 3%;
}

</style>

<?php include_once("template.php");?> 
<?php include_once("searchform.php");?>
<body class="test1">
<div class="container">
      <div class="row">
        
             <div class="col-lg-12">
               <div class="nav-side-menu">
                <div class="brand">
                  <form action="search.php" method="post">
                   
                   <div id="custom-search-input">
                     <div class="input-group col-md-8">
                    <input type="text" name="filter" value="" id="filter" placeholder="search" />
                     <span class="input-group-btn">
                        <button class="btn btn-info btn-lg" type="button" value="submit">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>

                    </span>
                      &nbsp&nbsp  &nbsp&nbsp schedule students   
                </div>
                     
            </div>
           
         </form>
                     
                    </div>
                <table class="responstable" width="100%"  align="center" border="1px">
                     <thead>
                     <tr>
                        <th width="15%"> Date </th>
                        <th width="10%"> Time </th>
                        <th width="15%"> Name </th>
                        <th width="15%"> Contact </th>
                        <th width="15%">Instructor </th>
                        <th width="5%"> Car </th>
                       
                        <th width="5%"> Class </th>
                        <th width="10%"> Remark </th>
                        <th width="5%"> Action </th>
                        <th width="5%"> Update_Class</th>
                        <th width="5%"> Delete</th>
                     </tr>
                  </thead>
                  <tbody>
                  <?php
                     include('../storescripts/connect_to_mysql.php');
                     $result = mysql_query("SELECT * FROM schedule WHERE school_name = '$name'" );
                     while($row = mysql_fetch_array($result))
                        {
                           echo '<tr class="record" width="100%">';
                           echo '<td>'.$row['date'].'</td>';
                           echo '<td><div>'.$row['time'].'</div></td>';
                          
                           echo '<td><div>'.$row['student_name'].'</div></td>';
                           echo '<td><div>'.$row['contact'].'</div></td>';
                           echo '<td><div>'.$row['instructot'].'</div></td>';
                           echo '<td><div>'.$row['car_select'].'</div></td>';
                          
                           echo '<td><div>'.$row['class'].'</div></td>';
                           echo '<td><div>'.$row['remarks'].'</div></td>';
                           echo '<td><div><a rel="facebox" href="remark.php?sc_id='.$row['sc_id'].'">Add remark</a> 
                            </div></td>';
                          
                          
                          echo '<td><div align="center"><a rel="facebox" href="schedule_class.php?sc_id='.$row['sc_id'].'">Add Class</a> 
                            </div></td>';
                         echo '<td><div><a rel="facebox" href="delete.php?sc_id='.$row['sc_id'].'">Delete</a></div>
                                   
                                </td>';


                        }

                     ?>

                  </tbody>
               </table>
              
            </div> 
    </div>  
</div>
</div>
 <body>