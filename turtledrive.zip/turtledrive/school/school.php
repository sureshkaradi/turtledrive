
<?php include_once("template.php");?>
<style type="text/css">
 .test1 {
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    font-size: 14px;
    line-height: 1.428571429;
    color: #333;
    background-image: url("img/bg.jpg");
    margin-top: 3%;
}
.nav-side-menu {
  overflow: auto;
  font-family: verdana;
  font-size: 12px;
  font-weight: 200;
  background-color: #fff;
  
  width: 100%;
  height: 65%;
  color: #e1ffff;
  box-shadow: inset 0 0 10px #000000;
}
</style>
<body class="test1">
 <div class="container">
    <div class="row">
    	 <div class="col-lg-12">
            
          </div>
          <div class="col-lg-12">
          	<?php  
 
  include "../storescripts/connect_to_mysql.php";
  $sql = mysql_query("SELECT * FROM products WHERE product_name = '$name'" );
 
   
    // get all the product details
    while($row = mysql_fetch_array($sql)){
       $id = $row["id"];
       $ca = $row["category"];
       $product_name = $row["product_name"];
       $detail = $row["details"];
       $cd = $row["contact_details"];
       $ad = $row["adderss"];
       $dod = $row["date_added"];

  } 
?>
        

<!-- Form Name -->
<div class="nav-side-menu">
 <div class="brand">SCHOOL DETAILS</div>

  <table width="100%">
    <tr>

    <td width="20%" align="center"><i class="fa fa-home"></i></td>
    <td width="30%" align="left"><h5>School Name:</h5></td>
    <td width="50" align="left"><h5><?php echo $name; ?></h5></td>

    </tr>
     <tr>
    <td width="20%" align="center"><h5><i class="fa fa-map-marker"></h5></i></td>
    <td width="30%" align="left"><h5>Address:</h5></td>
    <td width="50" align="left"> <h5><?php echo $ad; ?></h5></td>
    </tr>
     <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-envelop"></h5></i></td>
    <td width="30%" align="left"> <h5> Details: </h5></td>
    <td width="50" align="left"> <h5><?php echo $detail ?></h5> </td>
    </tr>
     <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-phone"></h5></i></td>
    <td width="30%" align="left"> <h5> Contact Details: </h5></td>
    <td width="50" align="left"> <h5><?php echo $ca; ?></h5> </td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Area: </h5></td>
    <td width="50" align="left"> <h5><?php echo $ca; ?></h5> </td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Date Added: </h5></td>
    <td width="50" align="left"> <h5><?php echo $dod; ?></h5> </td>
    </tr>
     <tr>
    <td></td>
    <td></td>
    <td><a href=""><button class="btn btn-primary">EDIT</button></a></td>
    </tr>
  </table>
   
</div>

  
   
        



         
          </div>	
     </div>
  </div>          
  </body>