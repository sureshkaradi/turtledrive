
<?php include_once("session_start.php");?>
<?php include_once("searchform.php");?>
<?php include_once("template.php");?>
<hr>
 <div class="container">
    <div class="row">
    	 <div class="col-lg-12">
             	<?php include_once("logout.php");?>
             </div>
        <div class="col-md-6">
         <form action="#" method="post">
            <h3>Search Jobs</h3>
            <div id="custom-search-input">
                <div class="input-group col-md-12">
                    <input type="hidden" name="name" value="<?php echo $name;?>">
                    <input type="text" class="form-control input-lg" name="date" id="date" placeholder="Enter today date" />
                    <span class="input-group-btn">
                        <button class="btn btn-info btn-lg" type="button" value="submit">
                            <i class="glyphicon glyphicon-search"></i>
                        </button>
                    </span>
                </div>
            </div>
         </form>
        </div><!-- <div class="col-md-6">-->
        <div class="col-lg-12">
                <table class="responstable" width="100%"  align="center" border="1px">
                     <thead>
                     <tr>
                        <th  style="border-left: 1px solid #C1DAD7"> Date </th>
                        <th width="10%"> Time </th>
                        <th width="10%"> Name </th>
                        <th width="10%"> Contact </th>
                        <th width="10%"> Alerted Instructor </th>
                        <th width="10%"> Alerted Car </th>
                        <th width="10%"> Amount </th>
                        <th width="10%"> Class </th>
                        <th width="10%"> Remark </th>
                     </tr>
                  </thead>
                  <tbody>
                  <?php
                     if(isset($_POST['submit'])){
                     if(preg_match("/[A-Z | a-z]+/", $_POST['name'])){
                      $date=$_POST['date'];
                      $name=$_POST['name'];
                     include('../storescripts/connect_to_mysql.php');
                     $result = mysql_query("SELECT * FROM schedule WHERE school_name = '$name' AND date = '$date' " );
                     while($row = mysql_fetch_array($result))
                        {
                           echo '<tr class="record" width="100%">';
                           echo '<td style="border-left: 1px solid #C1DAD7;">'.$row['date'].'</td>';
                           echo '<td><div align="right">'.$row['time'].'</div></td>';
                          
                           echo '<td><div align="right">'.$row['student_name'].'</div></td>';
                           echo '<td><div align="right">'.$row['contact'].'</div></td>';
                           echo '<td><div align="right">'.$row['instructot'].'</div></td>';
                           echo '<td><div align="right">'.$row['car_select'].'</div></td>';
                           echo '<td><div align="right">'.$row['pay'].'</div></td>';
                           echo '<td><div align="right">'.$row['class'].'</div></td>';
                           echo '<td><div align="right">'.$row['remarks'].'</div></td>';            
                        }
                       }
                     }
                      mysql_close(); 

                     ?> 
                  </tbody>
               </table>
              
            </div> 
    </div>
</div>
        <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
     <script src="js/bootstrap.min.js"></script>
      <script src="js/form.js"></script>

    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.16/jquery-ui.min.js"></script>
    `<link href="http://ajax.googleapis.com/ajax/libs/jqueryui/1.8/themes/base/jquery-ui.css" rel="stylesheet" type="text/css"/>

  <script>
  $(function() {
    var dates = $( "#date" ).datepicker({
      defaultDate: "+1w",
      changeMonth: true,
      numberOfMonths: 1,
      dateFormat: 'dd-mm-yy',
      onSelect: function( selectedDate ) {
        var option = this.id == "date" ? "minDate" : "maxDate",
          instance = $( this ).data( "datepicker" ),
          date = $.datepicker.parseDate(
            instance.settings.dateFormat ||
            $.datepicker._defaults.dateFormat,
            selectedDate, instance.settings );
        dates.not( this ).datepicker( "option", option, date );
      }
    });
  });
  </script>