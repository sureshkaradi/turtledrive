<link href="admin/css/style.css" rel="stylesheet" type="text/css" />
<link rel="../admin/stylesheet" href="febe/style.css" type="text/css" media="screen" charset="utf-8">
<script src="../admin/argiepolicarpio.js" type="text/javascript" charset="utf-8"></script>
<script src="../admin/js/application.js" type="text/javascript" charset="utf-8"></script>    
<!--sa poip up-->
<link href="../admin/src/facebox.css" media="screen" rel="stylesheet" type="text/css" />

<style type="text/css">
#custom-search-input{
    padding: 3px;
    border: transparent;
    border-radius: 6px;
    background-color: transparent;
    height: 50px;
    margin-top: 0px;
}

#custom-search-input input{
    border: 0;
    box-shadow: none;
    background-color: #fff;
    text-decoration: #fff;
    border-radius: 20px;
    width: 80%;
    height: 30px;
    text-align: center;
   margin-top: 10px;
}
input, button, select, textarea {
    font-family: sans-serif;
    font-size: 18px;
    line-height: 40px;
    color: #000;
}
#custom-search-input button{
    margin: 2px 0 0 0;
    background: none;
    box-shadow: none;
    border: 0;
    color: #fff;
    padding: 0 8px 0 10px;
    border-left: solid 1px #ccc;
}

#custom-search-input button:hover{
    border: 0;
    
    border-left: solid 1px #ccc;
}

#custom-search-input .glyphicon-search{
    font-size: 23px;
}
</style>

