<?php 
// This file is www.developphp.com curriculum material
// Written by Adam Khoury January 01, 2011
// http://www.youtube.com/view_play_list?p=442E340A42191003
session_start();
if (!isset($_SESSION["fullname"])) {
    header("location: ../index.php"); 
    exit();
}
?>

<?php
if (session_id() == "")
{
   session_start();

}
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form_name'] == 'logoutform')
{
   if (session_id() == "")
   {
      session_start();
   }
   unset($_SESSION['username']);
   unset($_SESSION['fullname']);
}
?>

<?php
if (isset($_SESSION['fullname']))
{
  $name=$_SESSION['fullname'];

}
else
{
   echo 'Not logged in';
}
?>

<?php 
  include "../storescripts/connect_to_mysql.php";
  $sql = mysql_query("SELECT * FROM products WHERE product_name = '$name'" );
      if($sql === FALSE) { 
    die(mysql_error()); // TODO: better error handling
}
    // get all the product details
    while($row = mysql_fetch_array($sql)){
       $id = $row["id"];
       $sn = $row["school_no"];

  } 
?>
