  <?php

$con = mysql_connect("localhost","root","");
if (!$con)
  {
  die('Could not connect: ' . mysql_error());
  }
 
mysql_select_db("projectx", $con);


$sql= "INSERT INTO products (id, school_no, product_name, details, contact_details, category, date_added, adderss, class_trail, since,  jobs, p_d_service)
VALUES ('', '$unique_ref', '$_POST[sname]',  '$_POST[Details]', '$_POST[contact]', '$_POST[area]', '$_POST[date]',
  '$_POST[Add]', '$_POST[tc]' , 
  '$_POST[e]', '$_POST[j]', '$_POST[pds]')";

 if (!mysql_query($sql,$con))
  {
  die('Error: ' . mysql_error());
  }

 header("location: school.php");
mysql_close($con)
?>