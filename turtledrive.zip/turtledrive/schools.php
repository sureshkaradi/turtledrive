<?php include('counter.inc.php'); ?>

<?php 
// Check to see the URL variable is set and that it exists in the database
if (isset($_GET['school_no'])) {
  // Connect to the MySQL database  
    include "storescripts/connect_to_mysql.php";

  $sn = $_GET['school_no'];

  $sql = mysql_query("SELECT * FROM products WHERE school_no='$sn' LIMIT 1");
  $productCount = mysql_num_rows($sql); // count the output amount
    if ($productCount > 0) {
    // get all the product details
    while($row = mysql_fetch_array($sql)){ 
       $product_name = $row["product_name"];
     
       $details = $row["details"];
       $category = $row["category"];
       $s = $row["since"];
       $j = $row["jobs"];
      
       $date_added = strftime("%b %d, %Y", strtotime($row["date_added"]));
       $adderss = $row["adderss"];
         }
     
  } else {
    echo "That item does not exist.";
      exit();
  }
    
}
     
else {
    echo "That item does not exist.";
      exit();
   }  
?>

<?php  
 
  include "storescripts/connect_to_mysql.php";
  $sql = mysql_query("SELECT * FROM cars WHERE product_name = '$product_name'" );
 
    if($sql === FALSE) { 
    die(mysql_error()); // TODO: better error handling
}
    // get all the product details
    while($row = mysql_fetch_array($sql)){
       $category = $row["category"];
       $car_name = $row["car_name"];
      
       $cars = '<table width="100%">
                  <tr>
                  <td><h4>' . $car_name . '</h4></td> 
                  <td><h4>' . $category . '</h4></td>
                  </tr>
                </table>';
     
  } 
    

      
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>school</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/1-col-portfolio.css" rel="stylesheet">
<style type="text/css">
 .media h3{
  text-transform: uppercase;
  font-size: 25px;
  font-family: bold;
 }
  .thumbnail h3{
  text-transform: uppercase;
  font-size: 25px;
  font-family: bold;
  text-align: center;
  color: red;
 }
 .thumbnail h5{
  text-align: center;
 }
 .media p{
  text-align:left;
  font-size: 18px;
  font-family: bold;
 }
 .title{
  margin-left: 20px;
 }
</style>

</head>

<body>
 <?php include_once("template1.php");?>
 <hr>
  <section id="services" class="service-item">
     <div class="container">
            

            <div class="row">

                <div class="col-sm-12 col-md-12">
                    <div class="media services-wrap wow fadeInDown">
                      <div class="row">  
                        <div class="col-md-3">
                          <img src="images/service/1.png" width="100px" height="100px">
                        </div>
                        <div class="col-md-6">
                          <h3><?php echo $product_name; ?></h3>
                         <p><i class="fa fa-map-marker"></i>&nbsp<?php echo $adderss; ?></p>
                        
                        </div> 
                        <div class="col-md-3">
                         <p>
                            <span class="glyphicon glyphicon-star"></span>
                            <span class="glyphicon glyphicon-star"></span>
                            <span class="glyphicon glyphicon-star"></span>
                            <span class="glyphicon glyphicon-star"></span>
                            <span class="glyphicon glyphicon-star-empty"></span>
                        </p>
                        </div>
                     </div>
                     <hr>
                     <br>
                     <div class="row">  
                        <div class="col-md-12">  
                         <table width="100%">
                           <tr>
                             <td align="center">
                              <div>
                                <div class="feature-wrap" >
                                 <i class="fa fa-info"></i><br><br>
                                 <h3>Since</h3>
                                 <p><?php echo $s; ?></p>   
                               </div>
                             </div>
                             </td>
                              <td align="center" >
                                <div class="feature-wrap">
                                 <i class="fa fa-book"></i><br><br>
                                 <h3>Jobs Done</h3>
                                 <p><?php echo $j; ?></p>    
                               </div>
                             </td>
                              <td align="center">
                                <div class="feature-wrap">
                                 <i class="fa fa-eye"></i><br><br>
                                 <h3>VIEWS</h3><br>
                                 <p><?php echo $visits; ?> visits.</p>    
                               </div>
                             </td>
                           </tr>
                         </table>    
                        </div>
                     </div><!--/.row 4-->
                     <br>
                     <div class="row">
                       <div class="col-md-4">
                       <img src="inventory_images/schools/1.jpg">
                       </div>
                       <div class="col-md-6">
                        <h3>DETAILS</h3>
                        <p><?php echo $details; ?></p>
                       </div>
                     </div>
                     <br>
                     <br>
                     <div class="row">
                      <div class="col-md-12">
                       <h3 class="title"> AVAILABLE CARS</h3>
                       <hr>
                       </div>
                      </div>
                      <br>  
                    <div class="row">
                      <div class="col-md-12">
                         <?php
include('storescripts/connect_to_mysql.php');// connection to database 
$q=mysql_query("select * from cars WHERE school_no = '$sn' ");
while($n=mysql_fetch_array($q)){
   $c_id = $n['c_id'];
   $car_name = $n['car_name'];
   $car_price = $n['car_price'];
   $tr = $n['training'];
   $class = $n['class'];
echo '<div class = "col-sm-6 col-md-3">
      <h5>'.$car_name.'  <i class = "fa fa-inr" ></i>  '.$car_price.'('.$tr.')</h5>
      <a href="booking.php?c_id=' . $c_id . '" class = "thumbnail">
         <img class="media-object" src="inventory_images/cars/' . $car_name . '.jpg" alt="' . $car_name . '">
          
          <h5>' . $class . ' days of training(1hr/day)</h5> 
          <h3>Select</h3>
      </a>

   </div>';
}

?>


                       </div>  
                    </div>  
            <hr>
        </div><!--/.container-->
    </section><!--/#services-->
    <?php include_once("template_footer.php");?>
     
