<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<title>Search Contacts</title>
<style type="text/css" media="screen">
ul li{
  list-style-type:none;
}
</style>
</head>

<body>
<h3>search school</h3>
<p> search by location</p>
<form method="post" action="search.php?go" id="searchform" >
<input type="text" name="name">
<input type="submit" name="submit" value="Search">
</form>

<?php

if(isset($_POST['submit'])){
if(isset($_GET['go'])){
if(preg_match("/[A-Z | a-z]+/", $_POST['name'])){
$name=$_POST['name'];

include "storescripts/connect_to_mysql.php"; 

//-query the database table
$sql="SELECT id, product_name, price FROM products WHERE category LIKE '%" . $name . "%' OR price LIKE '%" . $name ."%'";

//-run the query against the mysql query function
$result=mysql_query($sql);

//-count results

$numrows=mysql_num_rows($result);

echo "<p>" .$numrows . " results found for " . stripslashes($name) . "</p>"; 

//-create while loop and loop through result set
while($row=mysql_fetch_array($result)){

    $product_name =$row['product_name'];
    $price=$row['price'];
    $id=$row['id'];
        
//-display the result of the array

echo "<ul>\n"; 
echo "<li>" . "<a href=\"product.php?id=$id\">"  .$product_name . " " . $price . "</a></li>\n";
echo "</ul>";
}
}
else{
echo "<p>Please enter a search query</p>";
}
}
}

if(isset($_GET['by'])){
$letter=$_GET['by'];

include "storescripts/connect_to_mysql.php"; 

//-query the database table
$sql="SELECT id, product_name, price FROM products WHERE category LIKE '%" . $letter . "%' OR price LIKE '%" . $letter ."%'";


//-run the query against the mysql query function
$result=mysql_query($sql); 

//-count results
$numrows=mysql_num_rows($result);

echo "<p>" .$numrows . " results found for " . $letter . "</p>"; 

//-create while loop and loop through result set
while($row=mysql_fetch_array($result)){

$product_name =$row['product_name'];
    $price=$row['price'];
    $id=$row['id'];
    
//-display the result of the array

echo "<ul>\n"; 
echo "<li>" . "<a href=\"search.php?id=$id\">"  .$product_name . " " . $price . "</a></li>\n";
echo "</ul>";
}
}

if(isset($_GET['id'])){
$contactid=$_GET['id'];

include "storescripts/connect_to_mysql.php"; 

//-query the database table
$sql="SELECT * FROM products WHERE ID=" . $id;


//-run the query against the mysql query function
$result=mysql_query($sql); 

//-create while loop and loop through result set
while($row=mysql_fetch_array($result)){

  $product_name =$row['product_name'];
    $price=$row['price'];
    $catagory=$row['category'];
    $subcatagory=$row['subcategory'];

//-display the result of the array

echo "<ul>\n"; 
echo "<li>" . $product_name . " " . $price . "</li>\n";
echo "<li>" . $category . "</li>\n";

echo "</ul>";
}
}

?>
</body>
</html>
