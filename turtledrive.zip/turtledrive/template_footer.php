<html>
<body>
    <style type="text/css">
    .tf{
        margin-top: 40px;
        
    }
      
    </style>
 <section id="bottom">
        <div class="container wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
            <div class="row">
                <div class="col-md-4 col-sm-6">
                    <div class="widget">
                        <img src="images/services/c1.png"></br>
                       
                    </div>    
                </div>
                 <div class="col-md-8 col-sm-6">
                    <div class="widget">
                       <table class="tf" align="center" width="100%">
                        <tr>
                          <td><h3><a href="#">About us</a></h3></td>
                          <td><h3><a href="#">We are hiring</a></h3></td>
                          <td><h3><a href="#">Meet the team</a></h3></td>
                          <td><h3><a href="#">Terms of use</a></h3></td>
                          <td><h3><a href="#">Privacy policy</a></h3></td>
                          <td><h3><a href="#">Contact us</a></h3></td>
                        </tr>
                       </table>
                    </div>    
                </div>
            </div>
            <div class="row">
              <div class="col-md-12">
                    <div class="copy">
                      <table width="100%">
                       <tr>
                         <td><img src="images/services/output/1.gif" width="100px" height="60x"><br>
                          <p>&copy; 2016 SL Web Internet Pvt Ltd. All Rights Reserved</p> 
                         </td>
                       </tr>
                      </table>  
                    </div>
               </div>       
            </div>  
        </div>
    </section>
    <script src="js/jquery.js"></script>
    <script type="text/javascript">
        $('.carousel').carousel()
    </script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
</body>
</html>