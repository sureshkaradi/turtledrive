<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | Turtle Drive</title>
	
	<!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/p.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
<style type="text/css">
body {
  padding-top: 60px;
  background-color: #e3e3e3;
}
h3{
  color: #fff;
  font-family: bold;
}
.connect {
  font-size: 50px;
  height: 50px;
  width: 50px;
  margin: 5px;
  border-radius: 50%;
  line-height: 50px;
  text-align:center;
  background: orange;
  color: #c52d2f;
  border: #fff
  box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-transition: 500ms;
  -moz-transition: 500ms;
  -o-transition: 500ms;
  transition: 500ms;
  float: center;
  margin-right: 25px;
}
.connect img{
  height: 50px;
  width: 50px;
  margin: 0px;
  border-radius: 50%;
  line-height: 50px;
  text-align:center;
  background: #eee;
  color: #c52d2f;
  border: 3px solid #ffffff;
  box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-box-shadow: inset 0 0 0 5px #f2f2f2;
  -webkit-transition: 500ms;
  -moz-transition: 500ms;
  -o-transition: 500ms;
  transition: 500ms;
  float: left;
  margin-right: 25px;
}
.connect img:hover {
  background:orange;
  color: blue;
  box-shadow: inset 0 0 0 5px red;
  -webkit-box-shadow: inset 0 0 0 1px orange;
  border: 1px solid orange;
} 
.carousel {
  height: 550px;
  margin-bottom: 60px;
}
.carousel .item {
  height: 550px;
  background-color: #777;
}
.carousel-inner > .item > img {
  position: absolute;
  top: 0;
  left: 0;
  min-width: 100%;
  height: 550px;
}
.search {
  margin-top: -25%;
}
.search .form-section{
 background: rgba(0, 0, 0, 0.22);
    border: 2px solid #414141;
    border-radius: 5px;
    padding: 10px;
}

}

</style>
<style type="text/css">

.dropdown-menu h4{
  font-size: 12px;
  color: #fff;
}
</style>
</head><!--/head-->

<body class="homepage">

    <header id="header">
         <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.html"><img src="images/logo.png" alt="logo"></a>
                </div>
                <div class="collapse navbar-collapse navbar-right">
                 <ul class="nav navbar-nav">
                   <li class="active"><a href="index.php"><i class="fa fa-home"></i>&nbsp Home</a></li> 
                   <li><a href="training"><i class="fa fa-cog"></i>&nbsp Training</a></li>
                   <li><a href="pages/resources"><i class="fa fa-eye"></i>&nbspResources</a></li>
                   <li><a href="pages/rtoforms"><i class="fa fa-road"></i>&nbspRTO Forms</a></li>
                   <li><a href="pages/contact"><i class="fa fa-group"></i>&nbspContact Us</a></li> 
                   <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
                      <i class="fa fa-group"></i>&nbspAbout us
                      <i class="fa fa-angle-down"></i>
                    </a> 
                    <ul class="dropdown-menu">
                      <li><a href="pages/about"><i class="fa fa-group"></i>&nbsp Team</a></li>
                      <li><a href=""><i class="fa fa-home"></i>&nbsp Company</a></li> 
                      <li><a href=""><i class="fa fa-search"></i>&nbsp We Are Hiring</a></li>
                    </ul>
                  </li>
                  <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"> 
                      <i class="fa fa-lock"></i>&nbsp<?php
if (isset($_SESSION['fullname']))
{
   echo 'LOGOUT';
}
else
{
   echo 'Login';
}
?>
                      <i class="fa fa-angle-down"></i>
                    </a> 
                    <ul class="dropdown-menu">
                       <li><h4><i class="glyphicon glyphicon-user"></i><?php
if (isset($_SESSION['fullname']))
{
   echo $_SESSION['fullname'];
}
else
{
   echo 'Not logged in';
}
?></h4></li>
                     <li>
                        <form name="logoutform" method="post" action="login/session.php" id="logoutform">
                      <input type="hidden" name="form_name" value="logoutform">
                 <button type="submit" class="btn btn-warning" name="logout" value="Logout" id="Logout1"> <?php
if (isset($_SESSION['fullname']))
{
   echo 'LOG OUT';
}
else
{
   echo 'LOG IN';
}
?></button>
                     </form>
                     </li>
                    </ul>
                  </li>
                  
                  
                 </ul>   
                </div>    
            </div><!--/.container-->
        </nav><!--/nav-->
		
    </header><!--/header-->
   
   <div id="myCarousel" class="carousel slide" data-ride="carousel">
      <div class="carousel-inner">
        <div class="item active">
          <img src="images/slide1.jpg" alt="First slide">          
        </div>
        <div class="item">
          <img src="images/slide2.jpg" alt="Second slide">
        </div>
        <div class="item">
          <img src="images/slide3.jpg" alt="Third slide">
        </div>
      </div>
      <a class="left carousel-control" href="#myCarousel" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
      <a class="right carousel-control" href="#myCarousel" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>

    </div>

    <div class="search">

        <div class="container">
          <div class="row">
            <div class="col-md-10 col-md-offset-1">
                  <h3>LEARN DRIVING</h3>
                 <h3>ANYWHERE & EVERYWHERE</h3>
              <div class="form-section">
                <div class="row">
                  <form action="drivingschools" method="post" >
                      <div class="col-md-10">
                        <div class="form-group">
                          <label class="sr-only" for="location">Location</label>
                          <select id="guest" name="name" class="form-control">
                               <option>Select Your nearest location</option>
                                        <?php
include('storescripts/connect_to_mysql.php');// connection to database 
$q=mysql_query("select * from products ");
while($n=mysql_fetch_array($q)){
echo "<option value='".$n['category']."'>$n[category]</option>";
}
?>
                          </select>
                        </div>
                      </div>
                     
                      <div class="col-md-2">
                        <button type="submit" name="submit" class="btn btn-default btn-primary">Search</button>
                      </div>
                    </form>
                </div>
              </div>
               <ul class="social_icons">

                              <li> <div class="connect">
                                <img src="inventory_images/service/1.png" title="Learn">
                                </div></li> 

                               <li> <div class="connect">
                                <img src="inventory_images/service/5.png" title="Follow Traffic Rules">
                                </div></li> 

                               <li> <div class="connect">
                                <img src="inventory_images/service/3.png" title="Always Drive Slow :Your Home Is Waiting For You ">
                                </div></li>

                                <li> <div class="connect">
                                <img src="inventory_images/service/4.png" title="Best Of Luck">
                                </div></li>
                             </ul>
            </div>
          </div>
        </div>
      </div>
        </body>
        </html>




 