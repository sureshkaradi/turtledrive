    <section id="feature" >
        <div class="container">
           <div class="center wow fadeInDown">
                <p class="lead"></p>
                <h2>HOW IT WORKS</h2>
                
            </div>

            <div class="row">
                <div class="Features">
                    <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="feature-wrap">
                            <i class="fa fa-search"></i>
                            <h3>SEARCH</h3>
                            <p>Search Driving Schools nearby location, filter the results based upon your specific requirements.</p>
                              
   

                        </div>
                    </div><!--/.col-md-4-->

                    <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="feature-wrap">
                            <i class="fa fa-check-square"></i>
                            <h3>SELECT</h3>
                            <p>Select particular driving school based reviews </p>
                            
                        </div>
                    </div><!--/.col-md-4-->

                    <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="feature-wrap">
                            <i class="fa fa-book"></i>
                            <h3>BOOK</h3>
                            <p>Book a Slot to book, Provide your preferred date and time with contact details</p>
                           
                        </div>
                    </div><!--/.col-md-4-->
                
                    <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="feature-wrap">
                            <i class="fa fa-money"></i>
                            <h3>PAY</h3>
                            <p>Choose payment method, pay online instantly and confirm your booking</p>
                            
                        </div>

                    </div><!--/.col-md-4-->

                    <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="feature-wrap">
                  <i class="fa fa-cog"></i>
                            <h3>TAKE TRAIL</h3>
                            <p>Enjoy your learning session and have a  safe and fun driving</p>
                             
  
                        </div>
                    </div><!--/.col-md-4-->

                    <div class="col-md-4 col-sm-6 wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
                        <div class="feature-wrap">
                            <i class="fa fa-thumbs-up"></i>
                            <h3>GET DL</h3>
                            <p>Enjoy your Driving session and have a  safe and fun driving</p>
                        </div>
                    </div><!--/.col-md-4-->
                </div><!--/.services-->
            </div><!--/.row-->    
        </div><!--/.container-->
    </section><!--/#feature-->