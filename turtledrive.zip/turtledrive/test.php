<tr>

    <td width="20%" align="center"><i class="fa fa-home"></i></td>
    <td width="30%" align="left"><h5>School Name:</h5></td>
    <td width="50" align="left"><h5><?php echo $name; ?></h5>
    <input type="hidden" name="sname" value="<?php echo $name;?> "></td>

    </tr>
     <tr>
    <td width="20%" align="center"><h5><i class="fa fa-map-marker"></h5></i></td>
    <td width="30%" align="left"><h5>Address:</h5></td>
    <td width="50" align="left"> <input class="form-control" name="Add" type="textarea" id="add"></td>
    </tr>
     <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-envelop"></h5></i></td>
    <td width="30%" align="left"> <h5> Details: </h5></td>
    <td width="50" align="left">
    <input class="form-control" name="Details" type="textarea" id="details" row="5"></td>
    </tr>
     <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-phone"></h5></i></td>
    <td width="30%" align="left"> <h5> Contact Details: </h5></td>
    <td width="50" align="left"> <h5> <input class="form-control" name="contact" type="textarea" id="adetails"></td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Area: </h5></td>
    <td width="50" align="left"> <input class="form-control" name="area" type="text" id="area"></td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Established: </h5></td>
    <td width="50" align="left"> <input class="form-control" name="e" type="text" id="area"></td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Jobs Done: </h5></td>
    <td width="50" align="left"> <input class="form-control" name="j" type="text" id="area"></td>
    </tr>
   
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Pick $ Drop Service Charges: </h5></td>
    <td width="50" align="left"> <input class="form-control" name="pds" type="text" id="area"></td>
    </tr>
    
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Total Classes: </h5></td>
    <td width="50" align="left"> <input class="form-control" name="tc" type="text" id="area"></td>
    </tr>
    <tr>
    <td width="20%" align="center"> <h5> <i class="fa fa-email"></h5></i></td>
    <td width="30%" align="left"> <h5> Last Edit: </h5></td>
    <td width="50" align="left"><h5></h5> 
    <input type="hidden" name="date" value="<?php echo date("d/m/y");?> "></td>
    </tr>
     <tr>
    <td></td>
    <td></td>
    <td><input type="submit" value="update" id="button1"></td>>
    </tr>