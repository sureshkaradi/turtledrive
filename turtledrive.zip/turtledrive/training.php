

<style type="text/css">
 .row h3{
    text-transform: uppercase;
    font-size: 15px;
    text-align: left;
    font-family: bold;
   }
</style>

<?php include_once("template1.php");?>
<hr>
 <div class="container">  
        <div class="row">
           <div class="col-lg-3">
              <form class="well form-horizontal" action="car.php" method="post"  id="contact_form">
              <fieldset>
          <div class="form-group"> 
 
            
          <div class="col-md-12 selectContainer">
           <h5> LOCATION</h5>
          <div class="input-group">

          <span class="input-group-addon"><i class="glyphicon glyphicon-map-marker"></i></span>
          <select name="name" class="form-control selectpicker" >
             <?php
include('storescripts/connect_to_mysql.php');// connection to database 
$q=mysql_query("select * from products ");
while($n=mysql_fetch_array($q)){
echo "<option value=".$n['category'].">".$n['category']."</option>";
}
?>
      
           </select>
           </div>
           </div>
           </div>
           <div class="form-group"> 
 
 
          <div class="col-md-12 selectContainer">
           <h5> VEHICLE GROUP</h5> 
          <div class="input-group">
          <span class="input-group-addon"><i class="fa fa-cog"></i></span>
          <select name="car" id="filter" class="form-control selectpicker" >

           <?php
                          include('storescripts/connect_to_mysql.php');// connection to database 
                          $q=mysql_query("select * from car_names ");
                           while($n=mysql_fetch_array($q)){
                           echo "<option value=".$n['car_name'].">".$n['car_name']."</option>";
                             }
                           ?>
      
           </select>
           </div>
           </div>
           </div>
           <div class="form-group"> 
 
 
          <div class="col-md-12 selectContainer">
           <h5> PRICE</h5> 
          <div class="input-group">
          <span class="input-group-addon"><i class="fa fa-inr"></i></span>
          <select name="" id="filter" class="form-control selectpicker" >
            <option>2500</option>
            <option>2500-3000</option>
            <option>3000-4000</option>
            <option>4000-5000</option>
            <option>5000 Above </option>
           </select>
           </div>
           </div>
           </div>

        <div class="form-group">
         <div class="col-md-12 selectContainer">
          <div class="input-group">
           <br>
           <h5>VEHICLE TYPE </h5>

               <div>
                <input type="radio" name="filter" value="" id="filter" value="Santro">&nbsp &nbsp Power Stearing<br/>
                <input type="radio" name="filter" value="" id="filter" value="Alto">&nbsp &nbsp Manuval Stearing
                
               </div>

           </div>
           <br>
           </div>

             <div class="form-group">
                 <label class="col-md-4 control-label"></label>
                  <div class="col-md-4">
                 <button type="submit"  name="submit" class="btn btn-warning" >SEARCH <span class="glyphicon glyphicon-send"></span></button>
                 </div>
            </div>
        </fieldset>
       </form>
      
       
   </div> 
   <!-- car search-->
            <div class="col-md-8">
                                      <?php
include('storescripts/connect_to_mysql.php');// connection to database 
$q=mysql_query("select * from car_names ");
while($n=mysql_fetch_array($q)){
   $car_id = $n['car_id'];
   $car_name = $n['car_name'];
echo '<div class = "col-sm-6 col-md-6">
      <h4>'.$car_name.'</h4>
      <a href="cars.php?car_name=' . $car_name . '" class = "thumbnail">
         <img class="media-object" src="inventory_images/cars/' . $car_name . '.jpg" alt="' . $car_name . '">
           
          <h3>Select</h3>
      </a>

   </div>';
}

?> 
            </div>
        </div>
    </div>
     </br>
   <?php include_once("template_footer.php");?> 
