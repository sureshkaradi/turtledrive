<?php include_once("template.php");?>
<style type="text/css">


 td{
	text-align: center;
	color: #ffffff
}
 p{
  margin-top: 20px;
  font-size: 12px;
  text-align: center;
 }
 .nav-side-menu3 img{
	width:60px;
	height: 60px;
	text-align: center;
  color: #fff;
  opacity: 1;
  margin-top:10%;

}

.nav-side-menu {
  overflow: auto;
  font-family: verdana;
  font-size: 12px;
  font-weight: 200;
  background-color: #fff;
  
  width: 100%;
  height: 65%;
  color: #e1ffff;
  box-shadow: inset 0 0 10px #000000;
}
.nav-side-menu3 {
  overflow: auto;
  font-family: sans-serif;
  font-size: 12px;
  font-weight: 200;
  background-color: #fff;
   margin-top: 10px;
  width: 100%;
  height: 30%;
  color: #000;
  text-align: center;
  box-shadow: inset 0 0 10px blue;
  border-radius: 10px;
}
.nav-side-menu3 a :hover  {
  background-color: black;
}

.nav-side-menu1 {
  overflow: auto;
  font-family: verdana;
  font-size: 12px;
  font-weight: 200;
  background-color: #013058;
   margin-top: 10px;
  width: 100%;
  height: 80%;
  color: #fff;
  margin-left: 10px;
  border-radius: 5px;
}
.nav-side-menu1 h4{
  font-family: sans-serif;
  font-size: 20px;
  color: #ffffff;
  text-align: center;
 }
.nav-side-menu2 {
  border-radius: 5px;
  margin-top: 10px;
  overflow: auto;
  font-family: verdana;
  font-size: 12px;
  font-weight: 200;
  background-color: #CCC;
  width: 100%;
  height: 80%;
  color: #e1ffff;
  margin-right: 20px;
}
.nav-side-menu .toggle-btn {
  display: none;
}
.nav-side-menu ul,
.nav-side-menu li {
  list-style: none;
  padding: 1px;
  margin: 0px;
  line-height: 35px;
  cursor: pointer;
  color: rgba(255,255,255,0.15);;
  /*    
    .collapsed{
       .arrow:before{
                 font-family: FontAwesome;
                 content: "\f053";
                 display: inline-block;
                 padding-left:10px;
                 padding-right: 10px;
                 vertical-align: middle;
                 float:right;
            }
     }
*/
}
.nav-side-menu ul :not(collapsed) .arrow:before,
.nav-side-menu li :not(collapsed) .arrow:before {
  font-family: FontAwesome;
  content: "\f078";
  display: inline-block;
  padding-left: 10px;
  padding-right: 10px;
  vertical-align: middle;
  float: right;
}
.nav-side-menu ul .active,
.nav-side-menu li .active {
  border-left: 3px solid #d19b3d;
  background-color: #4f5b69;
}
.nav-side-menu ul .sub-menu li.active,
.nav-side-menu li .sub-menu li.active {
  color: #d19b3d;
}
.nav-side-menu ul .sub-menu li.active a,
.nav-side-menu li .sub-menu li.active a {
  color: #d19b3d;
}
.nav-side-menu ul .sub-menu li,
.nav-side-menu li .sub-menu li {
  background-color: #181c20;
  border: none;
  line-height: 28px;
  border-bottom: 1px solid #23282e;
  margin-left: 0px;
}
.nav-side-menu ul .sub-menu li:hover,
.nav-side-menu li .sub-menu li:hover {
  background-color: #020203;
}
.nav-side-menu ul .sub-menu li:before,
.nav-side-menu li .sub-menu li:before {
  font-family: FontAwesome;
  content: "\f105";
  display: inline-block;
  padding-left: 10px;
  padding-right: 10px;
  vertical-align: middle;
}
.nav-side-menu li {
  padding-left: 0px;
  border-left: 3px solid ;
  border-bottom: 1px solid ;
}
.nav-side-menu li a {
  text-decoration: none;
  color: rgba(8, 8, 8, 0.67);
}
.nav-side-menu li a i {
  padding-left: 10px;
  width: 20px;
  padding-right: 20px;
}
.nav-side-menu li:hover {
  border-left: 3px solid orange;
  background-color: #6F4F0D;
  -webkit-transition: all 1s ease;
  -moz-transition: all 1s ease;
  -o-transition: all 1s ease;
  -ms-transition: all 1s ease;
  transition: all 1s ease;
}
@media (max-width: 767px) {
  .nav-side-menu {
    position: relative;
    width: 100%;
    margin-bottom: 10px;
  }
  .nav-side-menu .toggle-btn {
    display: block;
    cursor: pointer;
    position: absolute;
    right: 10px;
    top: 10px;
    z-index: 10 !important;
    padding: 3px;
    background-color: #ffffff;
    color: #000;
    width: 40px;
    text-align: center;
  }
  .brand {
    text-align: left !important;
    font-size: 22px;
    padding-left: 20px;
    line-height: 50px !important;
  }
}
@media (min-width: 767px) {
  .nav-side-menu .menu-list .menu-content {
    display: block;
  }
}
body {
  margin: 0px;
  padding: 0px;
  background-color: #eee;
}
.image {
  margin-top: 100px;
}
.image1 {
  margin-top: 20px;
}

</style>


<body class="test">
<div class="container">
      <div class="row">
             <div class="col-lg-12">
             

              <?php
                     include('../storescripts/connect_to_mysql.php');
                     $result = mysql_query("SELECT * FROM products");
                     $n=mysql_num_rows($result);
                     
               ?> 
               <?php
                     include('../storescripts/connect_to_mysql.php');
                     $result = mysql_query("SELECT * FROM car_names");
                     $n1=mysql_num_rows($result);
                ?> 
                <?php
                     $d = date("d-m-Y");
                     include('../storescripts/connect_to_mysql.php');
                     $result = mysql_query("SELECT * FROM Booking_info " );
                     $n2=mysql_num_rows($result);
                ?>  

   

             </div>
    <div class="container">
      <div class="row">
        <div class="col-lg-3">
        <div class="nav-side-menu">
           <div class="brand">Inbox</div>
    <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
  
        <div class="menu-list">
  
            <ul id="menu-content" class="menu-content collapse out">
                <li>
                  <a href="home.php">
                  <i class="fa fa-dashboard fa-lg"></i> Dashboard
                  </a>
                </li>

                 <li>
                  <a href="profile.php">
                  <i class="fa fa-book fa-lg"></i>schools(<?php echo $n; ?>)
                  </a>
                  </li>


               <li>
                  <a href="schedule.php">
                  <i class="fa fa-calendar fa-lg"></i> Cars(<?php echo $n1; ?>)
                  </a>
                  </li>


                <li>
                  <a href="daily.php">
                  <i class="fa fa-clock-o fa-lg"></i>Bookings(<?php echo $n2; ?>)
                  </a>
                  </li>


                 <li>
                  <a href="#">
                  <i class="fa fa-user fa-lg"></i> Profile
                  </a>
                  </li>

                 <li>
                  <a href="#">
                  <i class="fa fa-users fa-lg"></i>Students(<?php echo $n; ?>)
                  </a>
                </li>
            </ul>
     </div>

        </div>
      </div>
        
             <div class="col-lg-9">
               <div class="nav-side-menu">
                <div class="brand">admin</div>
                
                   <div class="col-lg-4">
                     <div class="nav-side-menu1">
                      <table>
                        <tr>
                           <td><h4>Welcome to Turtledrive</h4></td>
                        </tr>
                        <tr>
                          <td>
                            <p>This Is Your Admin Dashboard Where You Can Easily Access Your Booking Details</p>
                          </td> 
                        </tr>
                        <tr>
                          <td>
                          <div class="image">  
                       <div class="col-md-12">
                          <img src="img/home.png" width="100px" height="100px">
                      </div> 
                      </div>
                      
                          </td>
                        </tr>
                      </table> 
                      
                     </div>
                   </div>
                   <div class="col-lg-8">
                     <div class="nav-side-menu2">
                    
                      <div class="col-xs-6 col-sm-4">
                        
                        <div class="nav-side-menu3">
                          <a href="profile.php"><img src="img/1.png"></a></br>
                          Schools
                         </div>
                      
                      </div>
                   
                      <div class="col-xs-6 col-sm-4">
                         <div class="nav-side-menu3">
                          <a href="schedule.php"><img src="img/2.png"></a><br>
                          Cars
                         </div>
                       </div>
                      <div class="col-xs-6 col-sm-4">
                        <div class="nav-side-menu3">
                          <a href="daily.php"><img src="img/3.png"></a></br>
                            Add New school
                         </div>
                       </div>
                       <div class="col-xs-6 col-sm-4">
                        <div class="nav-side-menu3">
                          <a href="profile.php"><img src="img/4.png"></a></br>
                            Add new Car
                         </div> 
                      </div>
                      <div class="col-xs-6 col-sm-4">
                         <div class="nav-side-menu3">
                          <a href="instructor.php"><img src="img/5.png"></a><br>
                          Add New Location
                         </div>
                       </div>
                      <div class="col-xs-6 col-sm-4">
                        <div class="nav-side-menu3">
                          <a href="car.php"><img src="img/6.png"></a><br>
                            Manage Ads
                        </div>
                       </div>
                       <div class="col-xs-6 col-sm-4">
                        <div class="nav-side-menu3">
                          <a href="school.php"><img src="img/7.png"></a><br>
                              Ohters
                        </div>
                       </div>
                     </div>
                   
                 </div>
               </div>
             </div>
       <div>
          	  </div>
       <div>
         <div>

    </body>      
   