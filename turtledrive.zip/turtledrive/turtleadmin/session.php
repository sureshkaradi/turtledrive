

<?php
error_reporting(1);
session_start();
$name=$_SESSION['id'];
if($_REQUEST['log']=='out')
{
session_destroy();
header("location:index.php");
}
else if($name=="")
{
header("location:index.php");
}
?>