<?php 
// This file is www.developphp.com curriculum material
// Written by Adam Khoury January 01, 2011
// http://www.youtube.com/view_play_list?p=442E340A42191003
session_start();
if (!isset($_SESSION["id"])) {
    header("location: index.php"); 
    exit();
}
?>

<style type="text/css">
.navbar-inverse .navbar-nav>li>a {
    color: #333;
}
.test {
    font-family: "Helvetica Neue",Helvetica,Arial,sans-serif;
    font-size: 14px;
    line-height: 1.428571429;
    color: #333;
    background-image: url("img/bg.jpg");
    margin-top: 10%;
}
.nav-side-menu .brand {
  background-color: #62BF62;
  line-height: 50px;
  display: block;
  text-align: center;
  font-size: 14px;
  text-transform: uppercase;

}
</style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Admin | Turtle Drive</title>
  
  <!-- core CSS -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/font-awesome.min.css" rel="stylesheet">
    <link href="../css/animate.min.css" rel="stylesheet">
    <link href="../css/prettyPhoto.css" rel="stylesheet">
    
    <link href="../css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="../images/f.png">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="../images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="../images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="../images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="../images/ico/apple-touch-icon-57-precomposed.png">
    <?php include_once("../school/table.php");?> 
    <?php include_once("../school/tcss.php");?> 
    <?php include_once("../school/t.php");?>

</head><!--/head-->

<body>

        <div class="navbar-more-overlay"></div>
    <nav class="navbar navbar-inverse navbar-fixed-top animate">
        <div class="container">
            <div class="navbar-header hidden-xs">
                <a class="navbar-brand" href="home.php"><img class="img" src="img/logo1.png"></a>
            </div>

            <ul class="nav navbar-nav navbar-right mobile-bar">
                <li>
                   <a href="home.php">
                      <i class="glyphicon glyphicon-home"></i>
                      <span id="lblLogout" class="hidden-inline-xs">HOME</span>
                   </a>
                </li>
                <li>
                   <a href="profile.php">
                      <i class="glyphicon glyphicon-book"></i>
                      <span id="lblLogout" class="hidden-inline-xs">BOOKINGS</span>
                   </a>
                </li>
                <li>
                   <a href="schedule.php">
                      <i class="fa fa-calendar fa-lg"></i>
                      <span id="lblLogout" class="hidden-inline-xs">SCHEDULE</span>
                   </a>
                </li>
                <li>
                   <a href="daily.php">
                      <i class="fa fa-clock-o fa-lg"></i>
                      <span id="lblLogout" class="hidden-inline-xs">JOBS</span>
                   </a>
                </li>
                <li>
                   <a href="car.php">
                      <i class="glyphicon glyphicon-cars"></i>
                      <span id="lblLogout" class="hidden-inline-xs">CARS</span>
                   </a>
                </li>
                <li>
                   <a href="school.php">
                      <i class="glyphicon glyphicon-home"></i>
                      <span id="lblLogout" class="hidden-inline-xs">SCHOOL</span>
                   </a>
                </li>

                <li class="hidden-xs">
                 <a class="alightred" href="../index.php">Logout</a>                 
                </li>
                
                <li class="visible-xs">
                    <a href="#navbar-more-show">
                        <span class="menu-icon fa fa-bars"></span>
                        More
                    </a>
                </li>
            </ul>
        </div>
    </nav>
        </body>
        </html>
